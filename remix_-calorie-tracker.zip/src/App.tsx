import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  LogEntry, UserProfile, FoodItem, MealType, WeightLog, WaterLog, 
  SubscriptionTier, UserAccount, CustomNutrient
} from "./types";
import Navbar from "./components/Navbar";
import Dashboard from "./components/Dashboard";
import FoodSearch from "./components/FoodSearch";
import Analytics from "./components/Analytics";
import SettingsComponent from "./components/Settings";
import AiGuide from "./components/AiGuide";
import Pricing from "./components/Pricing";
import BillingDashboard from "./components/BillingDashboard";
import AdminDashboard from "./components/AdminDashboard";
import Auth from "./components/Auth";
import PrivacyPolicy from "./components/PrivacyPolicy";
import CheckoutModal from "./components/CheckoutModal";
import { initializeDb, getUsers, saveUsers, logEmail } from "./mockDatabase";
import { Key, ShieldAlert, Award, Lock, Sparkles, AlertCircle } from "lucide-react";

// Standard default user profile
const DEFAULT_PROFILE: UserProfile = {
  age: 28,
  gender: "male",
  height: 175,
  weight: 75,
  activityLevel: "moderate",
  calorieGoal: 2100,
  proteinGoal: 150,
  carbsGoal: 215,
  fatGoal: 70,
  weightGoal: 70,
};

export default function App() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);

  // Authentication State
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => {
    const saved = localStorage.getItem("calorie_tracker_user");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed) return parsed;
      } catch (e) {
        // Fallback
      }
    }
    // Pre-logged in active premium expert account for Distanta Khanal
    const defaultUser: UserAccount = {
      id: "usr_2",
      email: "khanaldistanta@gmail.com",
      name: "Distanta Khanal",
      role: "user",
      createdAt: "2026-07-08",
      trialStart: Date.now() - 4 * 24 * 60 * 60 * 1000,
      trialEnd: Date.now() + 30 * 24 * 60 * 60 * 1000,
      tier: "expert",
      status: "active",
      isAutoRenew: true,
      nextBillingDate: "2026-08-12",
      invoices: [
        { id: "inv_dk1", date: "2026-07-08", amount: 50, status: "paid", plan: "Expert Plan" }
      ]
    };
    localStorage.setItem("calorie_tracker_user", JSON.stringify(defaultUser));
    return defaultUser;
  });

  // Checkout modal helper state
  const [checkoutPlan, setCheckoutPlan] = useState<SubscriptionTier | null>(null);

  // Core calorie logging states
  const [profile, setProfile] = useState<UserProfile>(() => {
    const saved = localStorage.getItem("calorie_tracker_profile");
    return saved ? JSON.parse(saved) : DEFAULT_PROFILE;
  });

  const [logs, setLogs] = useState<LogEntry[]>(() => {
    const saved = localStorage.getItem("calorie_tracker_logs");
    return saved ? JSON.parse(saved) : [];
  });

  const [weightLogs, setWeightLogs] = useState<WeightLog[]>(() => {
    const saved = localStorage.getItem("calorie_tracker_weight_logs");
    return saved ? JSON.parse(saved) : [];
  });

  const [waterLogs, setWaterLogs] = useState<WaterLog[]>(() => {
    const saved = localStorage.getItem("calorie_tracker_water_logs");
    return saved ? JSON.parse(saved) : [];
  });

  const [customNutrients, setCustomNutrients] = useState<CustomNutrient[]>(() => {
    const savedUser = localStorage.getItem("calorie_tracker_user");
    if (!savedUser) return [];
    try {
      const u = JSON.parse(savedUser);
      const saved = localStorage.getItem(`custom_nutrients_${u.id}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Sync custom nutrients when user changes or nutrients are updated
  useEffect(() => {
    if (currentUser) {
      const saved = localStorage.getItem(`custom_nutrients_${currentUser.id}`);
      setCustomNutrients(saved ? JSON.parse(saved) : []);
    } else {
      setCustomNutrients([]);
    }
  }, [currentUser]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(`custom_nutrients_${currentUser.id}`, JSON.stringify(customNutrients));
    }
  }, [customNutrients, currentUser]);

  const handleAddCustomNutrient = (name: string, unit: string, target: number) => {
    setCustomNutrients(prev => {
      const nextOrder = prev.length > 0 ? Math.max(...prev.map(n => n.order)) + 1 : 1;
      const newNutrient: CustomNutrient = {
        id: `nutrient_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
        name,
        unit,
        target,
        order: nextOrder
      };
      return [...prev, newNutrient];
    });
  };

  const handleUpdateCustomNutrient = (id: string, name: string, unit: string, target: number) => {
    setCustomNutrients(prev => prev.map(n => n.id === id ? { ...n, name, unit, target } : n));
  };

  const handleDeleteCustomNutrient = (id: string) => {
    setCustomNutrients(prev => prev.filter(n => n.id !== id));
  };

  const handleReorderCustomNutrients = (newNutrients: CustomNutrient[]) => {
    setCustomNutrients(newNutrients);
  };

  const handleResetUserData = () => {
    setLogs([]);
    setWeightLogs([]);
    setWaterLogs([]);
    setCustomNutrients([]);
    if (currentUser) {
      localStorage.removeItem(`custom_nutrients_${currentUser.id}`);
      localStorage.setItem(`custom_nutrients_${currentUser.id}`, JSON.stringify([]));
    }
  };

  // Initialize DB on mount
  useEffect(() => {
    initializeDb();
  }, []);

  // Sync user state on changes
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem("calorie_tracker_user", JSON.stringify(currentUser));
      // Save changes back to the mock user registry database to keep everything synchronized!
      const allUsers = getUsers();
      const idx = allUsers.findIndex(u => u.id === currentUser.id);
      if (idx !== -1) {
        allUsers[idx] = currentUser;
        saveUsers(allUsers);
      }
    } else {
      localStorage.removeItem("calorie_tracker_user");
    }
  }, [currentUser]);

  // Persist calorie states to local storage on changes
  useEffect(() => {
    localStorage.setItem("calorie_tracker_profile", JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem("calorie_tracker_logs", JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    localStorage.setItem("calorie_tracker_weight_logs", JSON.stringify(weightLogs));
  }, [weightLogs]);

  useEffect(() => {
    localStorage.setItem("calorie_tracker_water_logs", JSON.stringify(waterLogs));
  }, [waterLogs]);

  // Handler: Add Log entry (from search results or NLP)
  const handleAddLog = (item: FoodItem, quantity: number, mealType: MealType) => {
    const newLog: LogEntry = {
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      foodItem: item,
      quantity,
      mealType,
      timestamp: Date.now(),
    };
    setLogs((prev) => [newLog, ...prev]);
  };

  // Handler: Add Custom custom manual log
  const handleAddCustomLog = (itemDetails: Omit<FoodItem, "id">, quantity: number, mealType: MealType) => {
    const foodItem: FoodItem = {
      ...itemDetails,
      id: `custom_${Date.now()}`,
    };
    handleAddLog(foodItem, quantity, mealType);
  };

  // Handler: Delete Log entry
  const handleDeleteLog = (id: string) => {
    setLogs((prev) => prev.filter((log) => log.id !== id));
  };

  // Handler: Log Weight
  const handleLogWeight = (weight: number) => {
    const todayStr = new Date().toISOString().split("T")[0];
    setWeightLogs((prev) => {
      const filtered = prev.filter((w) => w.date !== todayStr);
      return [...filtered, { date: todayStr, weight }].sort(
        (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
      );
    });
  };

  // Handler: Add Water
  const handleAddWater = (amount: number) => {
    const todayStr = new Date().toISOString().split("T")[0];
    setWaterLogs((prev) => {
      const existing = prev.find((w) => w.date === todayStr);
      const filtered = prev.filter((w) => w.date !== todayStr);
      const currentAmount = existing ? existing.amount : 0;
      const newAmount = Math.max(0, currentAmount + amount);
      return [...filtered, { date: todayStr, amount: newAmount }];
    });
  };

  // Handler: Reset Today's logs
  const handleClearAllLogs = () => {
    if (confirm("Are you sure you want to reset all logged meals, weight stats, and water logs for today?")) {
      setLogs([]);
      const todayStr = new Date().toISOString().split("T")[0];
      setWaterLogs((prev) => prev.filter((w) => w.date !== todayStr));
    }
  };

  // Switch tab navigate
  const handleNavigateToTab = (tab: string) => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Dynamic role toggle between standard User Mode and Admin Dietitian mode
  const handleLogout = () => {
    if (!currentUser) return;
    const isCurrentlyAdmin = currentUser.role === "admin";
    const nextUser: UserAccount = isCurrentlyAdmin
      ? {
          id: "usr_2",
          email: "khanaldistanta@gmail.com",
          name: "Distanta Khanal",
          role: "user",
          createdAt: "2026-07-08",
          trialStart: Date.now() - 4 * 24 * 60 * 60 * 1000,
          trialEnd: Date.now() + 30 * 24 * 60 * 60 * 1000,
          tier: "expert",
          status: "active",
          isAutoRenew: true,
          nextBillingDate: "2026-08-12",
          invoices: [
            { id: "inv_dk1", date: "2026-07-08", amount: 50, status: "paid", plan: "Expert Plan" }
          ]
        }
      : {
          id: "usr_1",
          email: "admin@trackandfuel.com",
          name: "Alex Thorne (Dietitian Admin)",
          role: "admin",
          createdAt: "2026-06-01",
          tier: "expert",
          status: "active",
          isAutoRenew: true,
          nextBillingDate: "2026-08-01",
          invoices: [
            { id: "inv_ad1", date: "2026-06-01", amount: 50, status: "paid", plan: "Expert Plan" },
            { id: "inv_ad2", date: "2026-07-01", amount: 50, status: "paid", plan: "Expert Plan" }
          ]
        };

    setCurrentUser(nextUser);
    localStorage.setItem("calorie_tracker_user", JSON.stringify(nextUser));
    setActiveTab("dashboard");
  };

  // Check if trial of current user is expired
  const isTrialExpired = currentUser && 
    currentUser.tier === "free_trial" && 
    currentUser.trialEnd && 
    Date.now() > currentUser.trialEnd;

  // Render Page Content based on tab active
  const renderTabContent = () => {
    if (!currentUser) return null;

    switch (activeTab) {
      case "dashboard":
        return (
          <Dashboard
            logs={logs}
            profile={profile}
            weightLogs={weightLogs}
            waterLogs={waterLogs}
            customNutrients={customNutrients}
            currentUser={currentUser}
            onAddCustomLog={handleAddCustomLog}
            onDeleteLog={handleDeleteLog}
            onLogWeight={handleLogWeight}
            onAddWater={handleAddWater}
            onClearAllLogs={handleClearAllLogs}
            onNavigateToTab={handleNavigateToTab}
            onAddCustomNutrient={handleAddCustomNutrient}
            onUpdateCustomNutrient={handleUpdateCustomNutrient}
            onDeleteCustomNutrient={handleDeleteCustomNutrient}
            onReorderCustomNutrients={handleReorderCustomNutrients}
          />
        );
      case "logger":
        return (
          <FoodSearch 
            onAddLog={handleAddLog} 
            customNutrients={customNutrients}
            currentUser={currentUser}
            profile={profile}
            onNavigateToTab={handleNavigateToTab}
          />
        );
      case "ai-guide":
        return (
          <AiGuide
            profile={profile}
            logs={logs}
            currentUser={currentUser}
            onNavigateToTab={handleNavigateToTab}
          />
        );
      case "analytics":
        return (
          <Analytics
            logs={logs}
            profile={profile}
            weightLogs={weightLogs}
            waterLogs={waterLogs}
            customNutrients={customNutrients}
          />
        );
      case "pricing":
        return (
          <Pricing
            currentUser={currentUser}
            onSelectPlan={(tier) => setCheckoutPlan(tier)}
          />
        );
      case "billing":
        return (
          <BillingDashboard
            currentUser={currentUser}
            onUpdateUser={setCurrentUser}
            onNavigateToTab={handleNavigateToTab}
          />
        );
      case "admin":
        if (currentUser.role !== "admin") return <div className="text-center font-bold py-16 text-indigo-950">Access Denied</div>;
        return <AdminDashboard />;
      case "settings":
        return (
          <SettingsComponent
            profile={profile}
            onUpdateProfile={setProfile}
            customNutrients={customNutrients}
            onAddCustomNutrient={handleAddCustomNutrient}
            onUpdateCustomNutrient={handleUpdateCustomNutrient}
            onDeleteCustomNutrient={handleDeleteCustomNutrient}
            onResetUserData={handleResetUserData}
          />
        );
      default:
        return null;
    }
  };

  // If not logged in, force registration/auth
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-[#f5f7ff] flex flex-col justify-between">
        <Navbar activeTab="" setActiveTab={() => {}} currentUser={null} onLogout={() => {}} />
        <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 flex-1 flex items-center justify-center">
          <Auth onAuthSuccess={(user) => {
            setCurrentUser(user);
            // Alert 3 days remaining simulation email dispatch if they log in to test standard flows
            if (user.tier === "free_trial") {
              logEmail(
                user.email,
                "Warning: Your Track & Fuel trial expires in 3 days! ⏳",
                `Hi ${user.name},\n\nThis is a courtesy system alert regarding your Track & Fuel subscription.\n\nYour 14-day premium free trial period will conclude in exactly 3 days on: ${user.nextBillingDate}.\n\nConnect any active payment method (Basic, Pro, or Expert Plan) to avoid active coach workspace suspension!`,
                "trial_expiring_soon"
              );
            }
          }} />
        </main>
        <footer className="mt-auto border-t border-indigo-100 bg-white/60 py-6 text-center shrink-0">
          <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs text-indigo-500 font-bold uppercase tracking-wider">
              © 2026 Track & Fuel. All rights reserved.
            </p>
            <div className="flex gap-4">
              <button
                onClick={() => setIsPrivacyOpen(true)}
                className="text-xs font-black text-indigo-600 hover:text-indigo-900 underline underline-offset-4 cursor-pointer"
              >
                Privacy Policy & App Rules
              </button>
            </div>
          </div>
        </footer>
        <PrivacyPolicy isOpen={isPrivacyOpen} onClose={() => setIsPrivacyOpen(false)} />
      </div>
    );
  }

  // If logged in but trial has expired, present fullscreen block Upgrade page
  if (isTrialExpired) {
    return (
      <div className="min-h-screen bg-[#f5f7ff] flex flex-col justify-between relative">
        <Navbar activeTab="pricing" setActiveTab={() => {}} currentUser={currentUser} onLogout={handleLogout} />
        
        {/* Absolute Full Screen Lock Overlay layout */}
        <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8 flex-1 space-y-12">
          
          <div className="rounded-[40px] border-4 border-rose-250 bg-rose-50/50 p-8 text-center max-w-3xl mx-auto space-y-4 shadow-xl">
            <div className="mx-auto h-14 w-14 rounded-[22px] bg-rose-100 text-rose-700 flex items-center justify-center animate-bounce">
              <Lock className="h-6 w-6 stroke-[2.5px]" />
            </div>
            <h2 className="font-sans text-3xl font-black text-rose-950 tracking-tight">Your 14-Day Free Trial Has Expired</h2>
            <p className="text-xs text-rose-800 font-bold max-w-xl mx-auto leading-relaxed">
              Your free trial sandbox period expired automatically after 14 days. Connect an active subscription to instantly unlock all metabolic variables, calorie planners, and your personalized sports-science AI Coach.
            </p>
          </div>

          {/* Pricing cards */}
          <Pricing
            currentUser={currentUser}
            onSelectPlan={(tier) => setCheckoutPlan(tier)}
          />
        </div>

        {/* Checkout portal popup */}
        <AnimatePresence>
          {checkoutPlan && (
            <CheckoutModal
              planId={checkoutPlan}
              currentUser={currentUser}
              onClose={() => setCheckoutPlan(null)}
              onSuccess={(updated) => {
                setCheckoutPlan(null);
                setCurrentUser(updated);
                setActiveTab("dashboard");
              }}
            />
          )}
        </AnimatePresence>

        <footer className="mt-auto border-t border-indigo-100 bg-white/60 py-6 text-center shrink-0">
          <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs text-indigo-500 font-bold uppercase tracking-wider">
              © 2026 Track & Fuel. All rights reserved.
            </p>
            <div className="flex gap-4">
              <button
                onClick={() => setIsPrivacyOpen(true)}
                className="text-xs font-black text-indigo-600 hover:text-indigo-900 underline underline-offset-4 cursor-pointer"
              >
                Privacy Policy & App Rules
              </button>
            </div>
          </div>
        </footer>
        <PrivacyPolicy isOpen={isPrivacyOpen} onClose={() => setIsPrivacyOpen(false)} />
      </div>
    );
  }

  // Standard fully-licensed application view
  return (
    <div className="min-h-screen bg-[#f5f7ff] pb-20">
      {/* Navigation Header */}
      <Navbar 
        activeTab={activeTab} 
        setActiveTab={handleNavigateToTab} 
        currentUser={currentUser}
        onLogout={handleLogout}
      />

      {/* Main Body Stage Area */}
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25, ease: "easeInOut" }}
            id={`tab-container-${activeTab}`}
          >
            {renderTabContent()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Stripe checkout payment modal */}
      <AnimatePresence>
        {checkoutPlan && (
          <CheckoutModal
            planId={checkoutPlan}
            currentUser={currentUser}
            onClose={() => setCheckoutPlan(null)}
            onSuccess={(updated) => {
              setCheckoutPlan(null);
              setCurrentUser(updated);
              // Switch to Billing dashboard to see success!
              setActiveTab("billing");
            }}
          />
        )}
      </AnimatePresence>

      {/* Global Brand Footer with Privacy Policy Trigger */}
      <footer className="mt-auto border-t border-indigo-100 bg-white/60 py-6 text-center shrink-0">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-indigo-500 font-bold uppercase tracking-wider">
            © 2026 Track & Fuel. All rights reserved.
          </p>
          <div className="flex gap-4">
            <button
              onClick={() => setIsPrivacyOpen(true)}
              className="text-xs font-black text-indigo-600 hover:text-indigo-900 underline underline-offset-4 cursor-pointer"
            >
              Privacy Policy & App Rules
            </button>
          </div>
        </div>
      </footer>

      <PrivacyPolicy isOpen={isPrivacyOpen} onClose={() => setIsPrivacyOpen(false)} />
    </div>
  );
}
