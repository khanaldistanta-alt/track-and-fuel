import { UserAccount, SimulatedEmail, SubscriptionTier, Invoice } from "./types";

// Helper to generate IDs
export const generateId = () => Math.random().toString(36).substring(2, 9);

// Default mock users
const DEFAULT_MOCK_USERS: UserAccount[] = [
  {
    id: "usr_1",
    email: "admin@trackandfuel.com",
    name: "Alex Thorne (Dietitian Admin)",
    role: "admin",
    createdAt: "2026-06-01",
    tier: "expert",
    status: "active",
    isAutoRenew: true,
    nextBillingDate: "2026-08-01",
    invoices: [
      { id: "inv_ad1", date: "2026-06-01", amount: 50, status: "paid", plan: "Expert Plan" },
      { id: "inv_ad2", date: "2026-07-01", amount: 50, status: "paid", plan: "Expert Plan" }
    ]
  },
  {
    id: "usr_2",
    email: "khanaldistanta@gmail.com", // User's email from metadata
    name: "Distanta Khanal",
    role: "user",
    createdAt: "2026-07-08",
    trialStart: Date.now() - 4 * 24 * 60 * 60 * 1000, // 4 days ago
    trialEnd: Date.now() + 10 * 24 * 60 * 60 * 1000, // 10 days left
    tier: "free_trial",
    status: "trialing",
    isAutoRenew: true,
    nextBillingDate: "2026-07-22",
    invoices: []
  },
  {
    id: "usr_3",
    email: "elena.active@yahoo.com",
    name: "Elena Rostova",
    role: "user",
    createdAt: "2026-05-15",
    tier: "basic",
    status: "active",
    isAutoRenew: true,
    nextBillingDate: "2026-07-15",
    invoices: [
      { id: "inv_el1", date: "2026-05-15", amount: 5, status: "paid", plan: "Basic Plan" },
      { id: "inv_el2", date: "2026-06-15", amount: 5, status: "paid", plan: "Basic Plan" }
    ]
  },
  {
    id: "usr_4",
    email: "ryan.beast@gmail.com",
    name: "Ryan Gallagher",
    role: "user",
    createdAt: "2026-06-10",
    tier: "pro",
    status: "active",
    isAutoRenew: true,
    nextBillingDate: "2026-07-10",
    invoices: [
      { id: "inv_ry1", date: "2026-06-10", amount: 15, status: "paid", plan: "Pro Plan" },
      { id: "inv_ry2", date: "2026-07-10", amount: 15, status: "failed", plan: "Pro Plan" }
    ]
  },
  {
    id: "usr_5",
    email: "sarah.slim@outlook.com",
    name: "Sarah Jenkins",
    role: "user",
    createdAt: "2026-06-20",
    trialStart: Date.now() - 15 * 24 * 60 * 60 * 1000, // 15 days ago
    trialEnd: Date.now() - 1 * 24 * 60 * 60 * 1000, // expired 1 day ago
    tier: "free_trial",
    status: "expired",
    isAutoRenew: false,
    nextBillingDate: "N/A",
    invoices: []
  },
  {
    id: "usr_6",
    email: "dave.iron@gmail.com",
    name: "Dave Miller",
    role: "user",
    createdAt: "2026-04-10",
    tier: "pro",
    status: "canceled",
    isAutoRenew: false,
    nextBillingDate: "2026-07-10", // Will expire on billing date
    invoices: [
      { id: "inv_dv1", date: "2026-04-10", amount: 15, status: "paid", plan: "Pro Plan" },
      { id: "inv_dv2", date: "2026-05-10", amount: 15, status: "paid", plan: "Pro Plan" },
      { id: "inv_dv3", date: "2026-06-10", amount: 15, status: "paid", plan: "Pro Plan" }
    ]
  },
  {
    id: "usr_7",
    email: "expert_lift@company.com",
    name: "Marcus Aurelius (Fit Coach)",
    role: "user",
    createdAt: "2026-01-20",
    tier: "expert",
    status: "active",
    isAutoRenew: true,
    nextBillingDate: "2026-07-20",
    invoices: [
      { id: "inv_ma1", date: "2026-05-20", amount: 50, status: "paid", plan: "Expert Plan" },
      { id: "inv_ma2", date: "2026-06-20", amount: 50, status: "paid", plan: "Expert Plan" }
    ]
  }
];

const DEFAULT_MOCK_EMAILS: SimulatedEmail[] = [
  {
    id: "em_1",
    to: "khanaldistanta@gmail.com",
    subject: "Welcome to Track & Fuel! 🚀",
    body: "Hi Distanta Khanal,\n\nWelcome to Track & Fuel! Your 14-day premium free trial has started. You can track macro variables and use AI Search free of charge.",
    sentAt: "2026-07-08 09:12",
    type: "trial_started"
  }
];

// Initialize database
export function initializeDb() {
  if (!localStorage.getItem("track_fuel_users")) {
    localStorage.setItem("track_fuel_users", JSON.stringify(DEFAULT_MOCK_USERS));
  }
  if (!localStorage.getItem("track_fuel_emails")) {
    localStorage.setItem("track_fuel_emails", JSON.stringify(DEFAULT_MOCK_EMAILS));
  }
}

// Get all users
export function getUsers(): UserAccount[] {
  initializeDb();
  return JSON.parse(localStorage.getItem("track_fuel_users") || "[]");
}

// Save users
export function saveUsers(users: UserAccount[]) {
  localStorage.setItem("track_fuel_users", JSON.stringify(users));
}

// Get all emails
export function getEmails(): SimulatedEmail[] {
  initializeDb();
  return JSON.parse(localStorage.getItem("track_fuel_emails") || "[]");
}

// Send an email (append to log)
export function logEmail(to: string, subject: string, body: string, type: string) {
  const emails = getEmails();
  const newEmail: SimulatedEmail = {
    id: "em_" + generateId(),
    to,
    subject,
    body,
    sentAt: new Date().toISOString().replace("T", " ").substring(0, 16),
    type
  };
  emails.unshift(newEmail);
  localStorage.setItem("track_fuel_emails", JSON.stringify(emails));
}

// Upgrade or modify plan
export function updateUserSubscription(userId: string, tier: SubscriptionTier, status: "active" | "trialing" | "expired" | "canceled", isAutoRenew: boolean) {
  const users = getUsers();
  const index = users.findIndex(u => u.id === userId);
  if (index !== -1) {
    const user = users[index];
    user.tier = tier;
    user.status = status;
    user.isAutoRenew = isAutoRenew;
    
    const now = new Date();
    now.setMonth(now.getMonth() + 1);
    user.nextBillingDate = now.toISOString().split("T")[0];

    // If upgraded, generate a mock paid invoice if plan is not free trial
    if (tier !== "free_trial") {
      let amount = 5;
      if (tier === "pro") amount = 15;
      if (tier === "expert") amount = 50;

      const newInvoice: Invoice = {
        id: "inv_" + generateId(),
        date: new Date().toISOString().split("T")[0],
        amount,
        status: "paid",
        plan: `${tier.toUpperCase()} Plan`
      };
      user.invoices = [newInvoice, ...user.invoices];
    }

    saveUsers(users);
    return user;
  }
  return null;
}

// Get aggregate financial analytics
export function getSaaSMetrics() {
  const users = getUsers();
  
  let mrr = 0;
  let revenue = 0;
  let activeSubs = 0;
  let expiredTrials = 0;
  let failedPaymentsCount = 0;

  users.forEach(user => {
    // Sum active recurring MRR
    if (user.status === "active") {
      activeSubs++;
      if (user.tier === "basic") mrr += 5;
      else if (user.tier === "pro") mrr += 15;
      else if (user.tier === "expert") mrr += 50;
    } else if (user.status === "expired") {
      expiredTrials++;
    }

    // Sum overall paid revenue from invoices
    user.invoices.forEach(inv => {
      if (inv.status === "paid") {
        revenue += inv.amount;
      } else if (inv.status === "failed") {
        failedPaymentsCount++;
      }
    });
  });

  const arr = mrr * 12;
  const churnRate = 12.5; // Simulated percentage metric

  return {
    mrr,
    arr,
    revenue,
    activeSubs,
    expiredTrials,
    churnRate,
    failedPayments: failedPaymentsCount,
    totalUsers: users.length
  };
}
