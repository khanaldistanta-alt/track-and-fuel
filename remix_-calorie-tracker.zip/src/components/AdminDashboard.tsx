import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Users, DollarSign, RefreshCw, Star, Ban, CheckCircle2, AlertCircle, FileSpreadsheet, 
  Search, ShieldAlert, Award, Calendar, MoreVertical, Edit2, ShieldCheck, Mail
} from "lucide-react";
import { UserAccount, SubscriptionTier, Invoice } from "../types";
import { getUsers, saveUsers, getSaaSMetrics, logEmail } from "../mockDatabase";

export default function AdminDashboard() {
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [metrics, setMetrics] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterRole, setFilterRole] = useState<"all" | "user" | "admin">("all");
  const [filterTier, setFilterTier] = useState<"all" | SubscriptionTier>("all");

  // Selected User Actions Modals
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [selectedTier, setSelectedTier] = useState<SubscriptionTier>("free_trial");
  const [extendDays, setExtendDays] = useState(7);

  // Status message alerts
  const [successMsg, setSuccessMsg] = useState("");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const loadedUsers = getUsers();
    setUsers(loadedUsers);
    setMetrics(getSaaSMetrics());
  };

  const handleUpdateUser = (updated: UserAccount) => {
    const allUsers = getUsers();
    const idx = allUsers.findIndex(u => u.id === updated.id);
    if (idx !== -1) {
      allUsers[idx] = updated;
      saveUsers(allUsers);
      loadData();
      setSuccessMsg(`Account metrics for ${updated.name} have been updated successfully!`);
      setTimeout(() => setSuccessMsg(""), 4000);
    }
  };

  // Toggle user suspension
  const handleToggleSuspension = (user: UserAccount) => {
    const updated = { ...user, isDisabled: !user.isDisabled };
    handleUpdateUser(updated);

    // Simulated notify
    logEmail(
      user.email,
      user.isDisabled ? "Your account has been reactivated 🔓" : "Your account has been suspended 🚫",
      `Hi ${user.name},\n\nThis is a formal update regarding your Track & Fuel subscription account status. Your access has been ${user.isDisabled ? "restored to full operational capacity" : "suspended by our dietitian administration board due to payment audit guidelines"}.`,
      "account_status"
    );
  };

  // Extend Trial Period
  const handleExtendTrial = (user: UserAccount) => {
    if (!user.trialEnd) return;
    
    const additionalMs = extendDays * 24 * 60 * 60 * 1000;
    const newEnd = Math.max(user.trialEnd, Date.now()) + additionalMs;
    const updated: UserAccount = {
      ...user,
      trialEnd: newEnd,
      status: "trialing", // Reactivate trialing if they were expired!
      nextBillingDate: new Date(newEnd).toISOString().split("T")[0]
    };

    handleUpdateUser(updated);
    setEditingUser(null);

    logEmail(
      user.email,
      "Your free trial has been extended! 🎉",
      `Hi ${user.name},\n\nGreat news! A Track & Fuel dietitian administrator has extended your premium free trial period by ${extendDays} additional days.\n\nYour sandbox remains fully active until: ${updated.nextBillingDate}.\n\nKeep logging those metabolic meals!`,
      "trial_extended"
    );
  };

  // Manual Plan Migration
  const handleManualPlanChange = (user: UserAccount, tier: SubscriptionTier) => {
    let nextBilling = user.nextBillingDate;
    let status = user.status;

    if (tier !== user.tier) {
      const now = new Date();
      now.setMonth(now.getMonth() + 1);
      nextBilling = now.toISOString().split("T")[0];
      status = "active";
    }

    const updated: UserAccount = {
      ...user,
      tier,
      status,
      nextBillingDate: nextBilling
    };

    // If changing to a paid plan, generate invoice record
    if (tier !== "free_trial" && tier !== user.tier) {
      let amount = 5;
      if (tier === "pro") amount = 15;
      if (tier === "expert") amount = 50;

      const newInvoice: Invoice = {
        id: "inv_adm_" + Math.random().toString(36).substring(2, 9),
        date: new Date().toISOString().split("T")[0],
        amount,
        status: "paid",
        plan: `${tier.toUpperCase()} Plan (Admin Assigned)`
      };
      updated.invoices = [newInvoice, ...updated.invoices];
    }

    handleUpdateUser(updated);
    setEditingUser(null);

    logEmail(
      user.email,
      `Your subscription plan has been updated to ${tier.toUpperCase()} 🚀`,
      `Hi ${user.name},\n\nAn administrative dietitian supervisor has updated your Track & Fuel subscription plan to: ${tier.toUpperCase()}.\n\nThis allocation is now fully active on your account profile.`,
      "manual_plan_update"
    );
  };

  // Issue Refund on invoice
  const handleIssueRefund = (user: UserAccount, invoiceId: string) => {
    const updatedInvoices = user.invoices.map(inv => {
      if (inv.id === invoiceId) {
        return { ...inv, status: "refunded" as const };
      }
      return inv;
    });

    const updatedUser: UserAccount = {
      ...user,
      invoices: updatedInvoices
    };

    handleUpdateUser(updatedUser);

    const refundedInvoice = user.invoices.find(inv => inv.id === invoiceId);
    if (refundedInvoice) {
      logEmail(
        user.email,
        "Refund processed successfully 💸",
        `Hi ${user.name},\n\nWe have issued a refund of $${refundedInvoice.amount}.00 for invoice reference ${invoiceId}.\n\nThe credit should appear in your balance statements in 3-5 business days.`,
        "refund_completed"
      );
    }
  };

  // Export CSV
  const handleExportCSV = () => {
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "User ID,Name,Email,Role,Registered At,Active Plan,Status,Renewal Date,Total Invoices,Revenue Paid ($)\n";

    users.forEach(u => {
      const totalPaid = u.invoices
        .filter(i => i.status === "paid")
        .reduce((sum, i) => sum + i.amount, 0);

      const row = [
        u.id,
        `"${u.name}"`,
        u.email,
        u.role,
        u.createdAt,
        u.tier,
        u.status,
        u.nextBillingDate,
        u.invoices.length,
        totalPaid
      ].join(",");
      csvContent += row + "\r\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "track_fuel_saas_metrics.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filtered users matching parameters
  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      user.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole = filterRole === "all" ? true : user.role === filterRole;
    const matchesTier = filterTier === "all" ? true : user.tier === filterTier;
    return matchesSearch && matchesRole && matchesTier;
  });

  return (
    <div className="space-y-10 pb-16">
      {/* Visual Hub Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="font-sans text-5xl font-black text-indigo-950 tracking-tight flex items-center gap-3">
            Dietitian Supervisor Admin
            <span className="inline-block rounded-full bg-indigo-950 px-3 py-1 text-xs font-black text-indigo-200 uppercase tracking-widest">
              SYSTEM PORTAL
            </span>
          </h2>
          <p className="mt-2 text-md text-indigo-600 font-bold opacity-80">
            Monitor ARR/MRR metrics, manage subscription billing, extend sandbox trials, and issue secure client refunds.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="rounded-2xl border-4 border-indigo-950 hover:bg-indigo-950 hover:text-white px-5 py-3 text-xs font-black uppercase tracking-widest flex items-center gap-2 transition-colors cursor-pointer"
        >
          <FileSpreadsheet className="h-4 w-4" />
          Export CSV Billing
        </button>
      </div>

      {/* Success notification banner */}
      <AnimatePresence>
        {successMsg && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex items-start gap-3 rounded-[24px] bg-emerald-50 border-4 border-emerald-100 p-5 text-sm text-emerald-950 font-bold shadow-md"
          >
            <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
            <span>{successMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* SaaS financial overview cards (MRR, ARR, overall revenues, churn indices) */}
      {metrics && (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-[32px] border-4 border-indigo-100 bg-white p-6 shadow-md flex items-center gap-4">
            <div className="h-12 w-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
              <DollarSign className="h-6 w-6 stroke-[2.5px]" />
            </div>
            <div>
              <span className="block text-[10px] font-black text-indigo-400 uppercase tracking-widest">Monthly Recurring</span>
              <span className="block text-2xl font-black text-indigo-950 font-mono">${metrics.mrr}.00 MRR</span>
            </div>
          </div>

          <div className="rounded-[32px] border-4 border-indigo-100 bg-white p-6 shadow-md flex items-center gap-4">
            <div className="h-12 w-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
              <DollarSign className="h-6 w-6 stroke-[2.5px]" />
            </div>
            <div>
              <span className="block text-[10px] font-black text-indigo-400 uppercase tracking-widest">Annual Recurring</span>
              <span className="block text-2xl font-black text-indigo-950 font-mono">${metrics.arr}.00 ARR</span>
            </div>
          </div>

          <div className="rounded-[32px] border-4 border-indigo-100 bg-white p-6 shadow-md flex items-center gap-4">
            <div className="h-12 w-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
              <DollarSign className="h-6 w-6 stroke-[2.5px]" />
            </div>
            <div>
              <span className="block text-[10px] font-black text-indigo-400 uppercase tracking-widest">Total Net Paid</span>
              <span className="block text-2xl font-black text-indigo-950 font-mono">${metrics.revenue}.00 USD</span>
            </div>
          </div>

          <div className="rounded-[32px] border-4 border-indigo-100 bg-white p-6 shadow-md flex items-center gap-4">
            <div className="h-12 w-12 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
              <Users className="h-6 w-6 stroke-[2.5px]" />
            </div>
            <div>
              <span className="block text-[10px] font-black text-indigo-400 uppercase tracking-widest">SaaS Churn Rate</span>
              <span className="block text-2xl font-black text-indigo-950 font-mono">{metrics.churnRate}% Churn</span>
            </div>
          </div>
        </div>
      )}

      {/* User Management core workspace */}
      <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-2xl space-y-6">
        <h3 className="font-sans text-xl font-black text-indigo-950 uppercase tracking-wide flex items-center gap-2">
          <Users className="h-5 w-5 text-indigo-600" />
          Active Account Registry ({filteredUsers.length} matched)
        </h3>

        {/* Searching & Filter rails */}
        <div className="grid gap-4 md:grid-cols-12">
          {/* Search */}
          <div className="relative md:col-span-6">
            <Search className="absolute left-4 top-3.5 h-4 w-4 text-indigo-400" />
            <input
              type="text"
              placeholder="Search users by name or biological email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-2xl border-4 border-indigo-50 pl-11 pr-4 py-3 text-xs font-bold text-indigo-950 outline-none focus:border-indigo-400 transition-colors"
            />
          </div>

          {/* Role Filter */}
          <div className="md:col-span-3">
            <select
              value={filterRole}
              onChange={(e) => setFilterRole(e.target.value as any)}
              className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3 text-xs font-black text-indigo-950 outline-none focus:border-indigo-400 transition-colors"
            >
              <option value="all">All Roles (Admin / User)</option>
              <option value="user">Users Only</option>
              <option value="admin">Administrators Only</option>
            </select>
          </div>

          {/* Plan Tier Filter */}
          <div className="md:col-span-3">
            <select
              value={filterTier}
              onChange={(e) => setFilterTier(e.target.value as any)}
              className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3 text-xs font-black text-indigo-950 outline-none focus:border-indigo-400 transition-colors"
            >
              <option value="all">All Plan Tiers</option>
              <option value="free_trial">14-Day Free Trial</option>
              <option value="basic">Basic ($5)</option>
              <option value="pro">Pro ($15)</option>
              <option value="expert">Expert ($50)</option>
            </select>
          </div>
        </div>

        {/* User Registry Table */}
        <div className="overflow-x-auto rounded-2xl border-2 border-indigo-50">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-indigo-50/50 border-b-2 border-indigo-50 text-indigo-500 font-black uppercase tracking-wider">
                <th className="px-6 py-4">Client Detail</th>
                <th className="px-6 py-4">SaaS Tier / Level</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Cycle Renew</th>
                <th className="px-6 py-4 text-center">Invoices</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-indigo-50 font-semibold text-indigo-950">
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-12 text-indigo-400 font-bold">
                    No registry matches found for query parameters.
                  </td>
                </tr>
              ) : (
                filteredUsers.map((user) => {
                  const totalPaid = user.invoices
                    .filter(i => i.status === "paid")
                    .reduce((sum, i) => sum + i.amount, 0);

                  return (
                    <tr key={user.id} className="hover:bg-indigo-50/10 transition-colors">
                      {/* Name & Mail */}
                      <td className="px-6 py-4">
                        <div>
                          <span className="block font-sans text-sm font-black text-indigo-950">{user.name}</span>
                          <span className="block text-[10px] text-indigo-400 font-mono mt-0.5">{user.email}</span>
                        </div>
                      </td>

                      {/* Tier */}
                      <td className="px-6 py-4">
                        <span className={`inline-block px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-wider ${
                          user.tier === "expert" ? "bg-indigo-950 text-indigo-200" :
                          user.tier === "pro" ? "bg-indigo-100 text-indigo-800" :
                          user.tier === "basic" ? "bg-indigo-50 text-indigo-700" : "bg-zinc-100 text-zinc-700"
                        }`}>
                          {user.tier === "free_trial" ? "Free Trial" : `${user.tier.toUpperCase()} Plan`}
                        </span>
                        {user.role === "admin" && (
                          <span className="block text-[9px] text-indigo-600 font-black tracking-widest uppercase mt-1">
                            🛡️ ADMIN ROOT
                          </span>
                        )}
                      </td>

                      {/* Status */}
                      <td className="px-6 py-4">
                        {user.isDisabled ? (
                          <span className="inline-flex items-center gap-1.5 rounded-full bg-red-100 px-2.5 py-1 text-[9px] font-black text-red-800 uppercase tracking-wider">
                            <Ban className="h-3 w-3" /> Suspended
                          </span>
                        ) : (
                          <span className={`inline-block rounded-full px-2.5 py-1 text-[9px] font-black uppercase tracking-wider ${
                            user.status === "active" ? "bg-emerald-100 text-emerald-800" :
                            user.status === "trialing" ? "bg-blue-100 text-blue-800" : "bg-red-50 text-red-600"
                          }`}>
                            {user.status}
                          </span>
                        )}
                      </td>

                      {/* Renewal Date / Countdown */}
                      <td className="px-6 py-4">
                        {user.tier === "free_trial" && user.trialEnd ? (
                          <span className="text-[10px] text-indigo-600 font-black">
                            {Math.max(0, Math.ceil((user.trialEnd - Date.now()) / (1000 * 60 * 60 * 24)))} days left
                          </span>
                        ) : (
                          <span className="text-xs font-mono">{user.nextBillingDate}</span>
                        )}
                      </td>

                      {/* Invoices */}
                      <td className="px-6 py-4 text-center">
                        <span className="block font-mono text-sm font-bold">{user.invoices.length}</span>
                        <span className="block text-[10px] text-emerald-600 font-black">${totalPaid} paid</span>
                      </td>

                      {/* Actions */}
                      <td className="px-6 py-4 text-right space-x-2">
                        {/* Edit plan btn */}
                        <button
                          onClick={() => {
                            setEditingUser(user);
                            setSelectedTier(user.tier);
                          }}
                          className="bg-indigo-50 hover:bg-indigo-100 text-indigo-950 font-black text-[10px] uppercase tracking-wider px-3 py-2 rounded-xl transition-colors cursor-pointer"
                        >
                          Change metrics
                        </button>

                        {/* Ban / Suspension toggle button */}
                        <button
                          onClick={() => handleToggleSuspension(user)}
                          className={`font-black text-[10px] uppercase tracking-wider px-3 py-2 rounded-xl transition-colors cursor-pointer ${
                            user.isDisabled 
                              ? "bg-emerald-50 hover:bg-emerald-100 text-emerald-700"
                              : "bg-red-50 hover:bg-red-100 text-red-700"
                          }`}
                        >
                          {user.isDisabled ? "Re-Activate" : "Suspend"}
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Editing user modal controls */}
      <AnimatePresence>
        {editingUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-indigo-950/40 backdrop-blur-sm p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-lg rounded-[40px] bg-white border-4 border-indigo-100 p-8 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-sans text-xl font-black text-indigo-950">Administrative Control Panel</h3>
                  <p className="text-xs text-indigo-500 font-bold mt-1">Assign custom plan parameters for: {editingUser.name}</p>
                </div>
                <button
                  onClick={() => setEditingUser(null)}
                  className="text-xs font-black uppercase tracking-widest text-indigo-400 hover:text-indigo-950"
                >
                  Close
                </button>
              </div>

              <hr className="border-indigo-50 border-2" />

              {/* ACTION A: MANUALLY CHANGE PLANS */}
              <div className="space-y-3">
                <h4 className="text-[10px] font-black text-indigo-500 uppercase tracking-widest flex items-center gap-1.5">
                  <Award className="h-4 w-4" /> Change SaaS Subscription Plan
                </h4>
                <div className="grid grid-cols-2 gap-2.5">
                  {(["free_trial", "basic", "pro", "expert"] as SubscriptionTier[]).map((t) => (
                    <button
                      key={t}
                      onClick={() => handleManualPlanChange(editingUser, t)}
                      className={`py-3 rounded-2xl text-xs font-black uppercase tracking-wider transition-colors ${
                        editingUser.tier === t
                          ? "bg-indigo-600 text-white"
                          : "bg-indigo-50 hover:bg-indigo-100 text-indigo-950"
                      }`}
                    >
                      {t === "free_trial" ? "Free Trial" : `${t.toUpperCase()} Plan`}
                    </button>
                  ))}
                </div>
              </div>

              <hr className="border-indigo-50 border-2" />

              {/* ACTION B: TRIAL EXTENSION SECTION */}
              {editingUser.tier === "free_trial" && (
                <div className="space-y-4">
                  <h4 className="text-[10px] font-black text-indigo-500 uppercase tracking-widest flex items-center gap-1.5">
                    <Calendar className="h-4 w-4" /> Extend Trial Period
                  </h4>
                  <div className="flex items-center gap-3">
                    <input
                      type="number"
                      min={1}
                      max={60}
                      value={extendDays}
                      onChange={(e) => setExtendDays(parseInt(e.target.value) || 7)}
                      className="w-24 rounded-2xl border-4 border-indigo-50 px-4 py-2.5 text-xs font-black text-indigo-950 text-center"
                    />
                    <span className="text-xs text-indigo-500 font-bold">Days extension starting from now</span>
                    <button
                      onClick={() => handleExtendTrial(editingUser)}
                      className="flex-1 rounded-2xl bg-indigo-950 hover:bg-indigo-900 text-white font-black text-xs uppercase tracking-wider py-3.5 transition-colors"
                    >
                      APPLY EXTENSION
                    </button>
                  </div>
                </div>
              )}

              <hr className="border-indigo-50 border-2" />

              {/* ACTION C: TRANSACTION REFUND PANEL */}
              <div className="space-y-3">
                <h4 className="text-[10px] font-black text-indigo-500 uppercase tracking-widest flex items-center gap-1.5">
                  <DollarSign className="h-4 w-4" /> Invoice Ledger & Refund Gateway
                </h4>
                {editingUser.invoices.length === 0 ? (
                  <p className="text-xs text-indigo-400 font-bold italic">No paid invoices recorded on this account.</p>
                ) : (
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                    {editingUser.invoices.map((inv) => (
                      <div key={inv.id} className="rounded-2xl border border-indigo-50 p-3.5 flex items-center justify-between text-xs">
                        <div>
                          <span className="block font-black text-indigo-950">{inv.plan}</span>
                          <span className="block text-[9px] text-indigo-400 font-mono mt-0.5">{inv.id} | {inv.date}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-mono font-bold">${inv.amount}.00</span>
                          {inv.status === "paid" ? (
                            <button
                              onClick={() => handleIssueRefund(editingUser, inv.id)}
                              className="bg-rose-50 hover:bg-rose-100 text-rose-700 font-black text-[9px] uppercase tracking-wider px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
                            >
                              Issue Refund
                            </button>
                          ) : (
                            <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider ${
                              inv.status === "refunded" ? "bg-amber-100 text-amber-850" : "bg-red-100 text-red-800"
                            }`}>
                              {inv.status}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
