import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, Lock, ShieldCheck, CreditCard, Send, 
  MessageSquare, FileText, CheckCircle2, AlertCircle, Info, RefreshCw, Star, ShieldAlert
} from "lucide-react";
import { LogEntry, UserProfile, UserAccount } from "../types";

interface AiGuideProps {
  profile: UserProfile;
  logs: LogEntry[];
  currentUser: UserAccount;
  onNavigateToTab: (tab: string) => void;
}

interface Message {
  role: "user" | "model";
  text: string;
}

export default function AiGuide({ profile, logs, currentUser, onNavigateToTab }: AiGuideProps) {
  const [activeTab, setActiveTab] = useState<"chat" | "audit">("chat");
  const [chatInput, setChatInput] = useState("");
  const [chatHistory, setChatHistory] = useState<Message[]>(() => {
    const saved = localStorage.getItem(`calorie_tracker_ai_chat_history_${currentUser.id}`);
    return saved ? JSON.parse(saved) : [
      {
        role: "model",
        text: `Hello! I am **FuelBot**, your premium Track & Fuel sports nutrition companion. 
        
I am ready to analyze your active biological profile parameters and daily logs to suggest macro distributions, nutrient timing, and strategy.

How can I guide your custom logs or nutrient targets today?`
      }
    ];
  });
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [auditReport, setAuditReport] = useState<string>("");
  const [isGeneratingAudit, setIsGeneratingAudit] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Sync chat history to localStorage per user
  useEffect(() => {
    localStorage.setItem(`calorie_tracker_ai_chat_history_${currentUser.id}`, JSON.stringify(chatHistory));
    scrollToBottom();
  }, [chatHistory, currentUser.id]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Chat send message via real server-side proxy
  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isGenerating) return;

    const userMsg = textToSend.trim();
    const updatedHistory: Message[] = [...chatHistory, { role: "user", text: userMsg }];
    
    setChatHistory(updatedHistory);
    setChatInput("");
    setIsGenerating(true);

    try {
      const response = await fetch("/api/premium/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          profile,
          logs,
          history: updatedHistory.slice(-8), // Send last 8 messages for context
          message: userMsg
        })
      });

      if (!response.ok) {
        throw new Error("Server failed to respond correctly.");
      }

      const data = await response.json();
      setChatHistory(prev => [...prev, { role: "model", text: data.text }]);
    } catch (error) {
      console.error("Failed to chat with AI coach:", error);
      setChatHistory(prev => [
        ...prev, 
        { 
          role: "model", 
          text: "I experienced a minor latency lag communicating with the database. Please try repeating your question, or ask about **protein tips**!" 
        }
      ]);
    } finally {
      setIsGenerating(false);
    }
  };

  // Generate today's detailed nutritional audit
  const generateAudit = async () => {
    if (isGeneratingAudit) return;
    setIsGeneratingAudit(true);

    try {
      const response = await fetch("/api/premium/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          profile,
          logs,
          history: [],
          message: "Please analyze today's logs and give me a strict, professional nutritional audit and detailed daily strategy."
        })
      });

      if (!response.ok) {
        throw new Error("Audit generation failed");
      }

      const data = await response.json();
      setAuditReport(data.text);
    } catch (error) {
      console.error("Audit generation failed:", error);
      setAuditReport("### Audit Error\nCould not construct your nutritional report. Try logging a few food entries first so we have data to audit!");
    } finally {
      setIsGeneratingAudit(false);
    }
  };

  // Render text helper supporting markdown
  const renderFormattedText = (text: string) => {
    return text.split("\n").map((line, i) => {
      if (line.startsWith("### ")) {
        return (
          <h4 key={i} className="text-sm font-black text-indigo-950 mt-4 mb-1.5 flex items-center gap-2 border-b border-indigo-50 pb-0.5">
            <span className="h-1.5 w-1.5 rounded-full bg-indigo-500" />
            {line.replace("### ", "")}
          </h4>
        );
      }
      if (line.startsWith("## ")) {
        return (
          <h3 key={i} className="text-base font-black text-indigo-950 mt-5 mb-2 border-b-2 border-indigo-100 pb-0.5 uppercase tracking-wide">
            {line.replace("## ", "")}
          </h3>
        );
      }
      if (line.startsWith("* ") || line.startsWith("- ")) {
        const content = line.substring(2);
        return (
          <div key={i} className="flex items-start gap-2.5 text-xs text-indigo-950 my-1.5 leading-relaxed pl-2.5">
            <span className="text-indigo-600 font-bold mt-0.5">➔</span>
            <span>{parseBoldText(content)}</span>
          </div>
        );
      }
      if (line.trim() === "") return <div key={i} className="h-2" />;
      return (
        <p key={i} className="text-xs text-indigo-900 leading-relaxed my-1.5">
          {parseBoldText(line)}
        </p>
      );
    });
  };

  const parseBoldText = (text: string) => {
    const parts = text.split(/\*\*([^*]+)\*\*/g);
    return parts.map((part, index) => {
      if (index % 2 === 1) {
        return <strong key={index} className="font-extrabold text-indigo-950 bg-indigo-50 px-1 rounded">{part}</strong>;
      }
      return part;
    });
  };

  const quickChips = [
    "Protein suggestions for my weight",
    "Analyze custom logged nutrient ratios",
    "How does my activity multiplier affect target guidelines?"
  ];

  // Logic to determine access per tier:
  // - free/free_trial: Locked entirely
  // - basic: Locked entirely (explain scanning only)
  // - pro: Chat is locked (requires Expert), Audit is UNLOCKED
  // - expert: All UNLOCKED
  
  const isFree = currentUser.tier === "free_trial";
  const isBasic = currentUser.tier === "basic";
  const isPro = currentUser.tier === "pro";
  const isExpert = currentUser.tier === "expert";

  const renderTierLockScreen = (featureName: string, requiredTierName: string, message: string) => {
    return (
      <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-12 text-center max-w-2xl mx-auto space-y-6 shadow-2xl">
        <div className="h-16 w-16 bg-indigo-50 text-indigo-600 flex items-center justify-center rounded-2xl mx-auto border-2 border-indigo-100">
          <Lock className="h-8 w-8 text-indigo-600 animate-pulse" />
        </div>
        <div className="space-y-2">
          <h3 className="font-sans text-2xl font-black text-indigo-950 uppercase tracking-tight">
            {featureName} Gated
          </h3>
          <p className="text-xs text-indigo-400 font-black uppercase tracking-widest">
            Your Active Tier: <span className="text-indigo-600 font-black">{currentUser.tier.replace(/_/g, " ")} plan</span>
          </p>
          <p className="text-sm text-indigo-600 font-bold max-w-md mx-auto leading-relaxed pt-2">
            {message}
          </p>
        </div>
        <button
          onClick={() => onNavigateToTab("pricing")}
          className="px-6 py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl shadow-lg shadow-indigo-600/20 transition-all active:scale-95"
        >
          View Plans & pricing details 👑
        </button>
      </div>
    );
  };

  return (
    <div className="space-y-10 pb-16">
      {/* Page Header */}
      <div>
        <h2 className="font-sans text-5xl font-black text-indigo-950 tracking-tight flex items-center gap-3">
          AI Premium Guide
          <span className="inline-block rounded-full bg-indigo-50 border border-indigo-200 px-3 py-1 text-xs font-black text-indigo-700 uppercase tracking-widest">
            {currentUser.tier.toUpperCase().replace(/_/g, " ")} PLAN
          </span>
        </h2>
        <p className="mt-2 text-lg text-indigo-600 font-bold opacity-80">
          Obtain customized daily breakdowns, log strategies, and direct sports nutrition coaching from FuelBot.
        </p>
      </div>

      {isFree ? (
        renderTierLockScreen(
          "AI Companion Suite",
          "Basic or above",
          "Advanced interactive companion features require a premium subscription tier. Upgrade your account today to unlock full logging automation."
        )
      ) : isBasic ? (
        renderTierLockScreen(
          "AI Companion Chat & Audits",
          "Pro or Expert",
          "The Basic tier ($5/mo) unlocks AI Photo Scanning and database calorie predictions. Upgrade to Pro ($15/mo) for Nutritional Audits, or Expert ($50/mo) for the live Coach Chat."
        )
      ) : (
        /* Unlocked multi-tab layout for Pro & Expert users */
        <div className="space-y-8">
          
          {/* Sub tab tabs switcher */}
          <div className="flex border-b-4 border-indigo-100 gap-2">
            <button
              onClick={() => setActiveTab("chat")}
              className={`flex items-center gap-2 border-b-4 -mb-[4px] px-6 py-4 text-xs font-black uppercase tracking-wider transition-all rounded-t-3xl ${
                activeTab === "chat"
                  ? "border-indigo-600 text-indigo-950 bg-indigo-50/50"
                  : "border-transparent text-indigo-500 hover:text-indigo-950 hover:bg-indigo-50/20"
              }`}
            >
              <MessageSquare className="h-4.5 w-4.5 text-indigo-600" />
              24/7 AI Coach Chat
            </button>
            <button
              onClick={() => setActiveTab("audit")}
              className={`flex items-center gap-2 border-b-4 -mb-[4px] px-6 py-4 text-xs font-black uppercase tracking-wider transition-all rounded-t-3xl ${
                activeTab === "audit"
                  ? "border-indigo-600 text-indigo-950 bg-indigo-50/50"
                  : "border-transparent text-indigo-500 hover:text-indigo-950 hover:bg-indigo-50/20"
              }`}
            >
              <FileText className="h-4.5 w-4.5 text-indigo-600" />
              AI Daily Nutritional Audit
            </button>
          </div>

          {/* Subtab content rendering */}
          {activeTab === "chat" && (
            <div className="space-y-6">
              {isPro ? (
                /* Pro tier locks chat assistant, needs Expert */
                renderTierLockScreen(
                  "FuelBot Live Coaching Chat",
                  "Expert Plan",
                  "The Pro tier ($15/mo) includes dynamic Nutritional Audits. Bidirectional chat with your 24/7 personal dietitian coach 'FuelBot' is exclusive to the Expert Plan ($50/mo)."
                )
              ) : (
                /* Full Expert access to Chat */
                <div className="grid gap-8 lg:grid-cols-4">
                  
                  {/* Chat logs feed */}
                  <div className="lg:col-span-3 rounded-[40px] border-4 border-indigo-100 bg-white p-6 shadow-2xl flex flex-col justify-between h-[480px]">
                    
                    {/* Message stream */}
                    <div className="flex-1 overflow-y-auto space-y-4 pr-1 scroll-smooth">
                      {chatHistory.map((msg, idx) => {
                        const isUser = msg.role === "user";
                        return (
                          <div 
                            key={idx} 
                            className={`flex ${isUser ? "justify-end" : "justify-start"}`}
                          >
                            <div 
                              className={`max-w-[85%] rounded-3xl px-5 py-3.5 border-2 ${
                                isUser 
                                  ? "bg-indigo-600 text-white border-indigo-700 rounded-br-none" 
                                  : "bg-indigo-50/30 text-indigo-950 border-indigo-100 rounded-bl-none"
                              }`}
                            >
                              {renderFormattedText(msg.text)}
                            </div>
                          </div>
                        );
                      })}
                      
                      {isGenerating && (
                        <div className="flex justify-start">
                          <div className="bg-indigo-50/30 text-indigo-950 border-indigo-100 border-2 rounded-3xl rounded-bl-none px-5 py-3.5 flex items-center gap-2">
                            <RefreshCw className="h-4 w-4 text-indigo-600 animate-spin" />
                            <span className="text-xs font-black text-indigo-400 uppercase tracking-widest">FuelBot is strategizing...</span>
                          </div>
                        </div>
                      )}
                      
                      <div ref={messagesEndRef} />
                    </div>

                    {/* Chat inputs */}
                    <div className="border-t-2 border-indigo-50 pt-4 mt-4">
                      <div className="flex gap-3">
                        <input
                          type="text"
                          placeholder="Ask FuelBot anything about custom tracking, macronutrients ratio or training guidelines..."
                          value={chatInput}
                          onChange={(e) => setChatInput(e.target.value)}
                          onKeyDown={(e) => e.key === "Enter" && handleSendMessage(chatInput)}
                          className="flex-1 rounded-2xl border-4 border-indigo-50 px-4 py-3 text-xs font-bold text-indigo-950 outline-none focus:border-indigo-300 transition-colors bg-indigo-50/10"
                        />
                        <button
                          onClick={() => handleSendMessage(chatInput)}
                          disabled={isGenerating || !chatInput.trim()}
                          className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-2xl text-xs uppercase tracking-widest transition-all shrink-0 active:scale-95 flex items-center gap-1.5 shadow-md shadow-indigo-600/15"
                        >
                          <Send className="h-4 w-4 stroke-[3px]" />
                          Send
                        </button>
                      </div>
                    </div>

                  </div>

                  {/* Sidebar with helpful hints */}
                  <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-6 shadow-2xl flex flex-col justify-between space-y-6">
                    <div className="space-y-4">
                      <div className="flex items-center gap-2">
                        <Sparkles className="h-5 w-5 text-indigo-600" />
                        <h4 className="font-sans text-sm font-black text-indigo-950 uppercase tracking-tight">Suggestions</h4>
                      </div>
                      <p className="text-xs text-indigo-500 font-bold leading-relaxed">
                        FuelBot uses your current physical constraints and your logged custom goal nutrients to formulate hyper-accurate sports science targets. Try tapping one of the chips below:
                      </p>

                      <div className="space-y-2.5">
                        {quickChips.map((chip, i) => (
                          <button
                            key={i}
                            onClick={() => handleSendMessage(chip)}
                            className="w-full text-left p-3 border border-indigo-100 hover:border-indigo-500 rounded-2xl bg-indigo-50/25 hover:bg-white text-xs font-bold text-indigo-950 transition-all leading-snug"
                          >
                            {chip}
                          </button>
                        ))}
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        if (confirm("Clear active chat session history?")) {
                          setChatHistory([
                            {
                              role: "model",
                              text: "History wiped! How can I guide your macro guidelines now?"
                            }
                          ]);
                        }
                      }}
                      className="w-full py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-950 text-[10px] font-black uppercase tracking-widest rounded-xl transition-colors"
                    >
                      Clear Conversation
                    </button>
                  </div>

                </div>
              )}
            </div>
          )}

          {/* Audit tab */}
          {activeTab === "audit" && (
            <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-2xl space-y-6">
              <div className="flex items-center justify-between border-b-2 border-indigo-50 pb-4">
                <div>
                  <h3 className="font-sans text-xl font-black text-indigo-950 uppercase">
                    Premium Daily Nutritional Audit
                  </h3>
                  <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest mt-1">
                    Complete macro velocity breakdowns and sports-science strategist recommendations
                  </p>
                </div>

                <button
                  onClick={generateAudit}
                  disabled={isGeneratingAudit}
                  className="px-6 py-3.5 bg-indigo-650 hover:bg-indigo-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl shadow-lg transition-transform active:scale-95 flex items-center gap-1.5"
                >
                  {isGeneratingAudit ? (
                    <>
                      <RefreshCw className="h-4.5 w-4.5 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4.5 w-4.5" />
                      GENERATE REPORT NOW
                    </>
                  )}
                </button>
              </div>

              {auditReport ? (
                <div className="bg-indigo-50/20 border-2 border-indigo-50 rounded-3xl p-6 md:p-8 overflow-y-auto max-h-[420px]">
                  {renderFormattedText(auditReport)}
                </div>
              ) : (
                <div className="text-center py-16 space-y-4">
                  <FileText className="h-12 w-12 text-indigo-200 mx-auto animate-pulse" />
                  <div className="space-y-1">
                    <p className="text-sm font-black text-indigo-950 uppercase">Strategic Audit Pending</p>
                    <p className="text-xs text-indigo-400">Click the generate report button to evaluate today's food logs.</p>
                  </div>
                </div>
              )}
            </div>
          )}

        </div>
      )}
    </div>
  );
}
