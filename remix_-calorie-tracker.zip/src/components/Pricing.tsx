import React, { useState } from "react";
import { motion } from "motion/react";
import { 
  Check, HelpCircle, Shield, Sparkles, Award, Zap, Heart, CheckCircle2, AlertCircle
} from "lucide-react";
import { SubscriptionTier, UserAccount } from "../types";

interface PricingProps {
  currentUser: UserAccount;
  onSelectPlan: (tier: SubscriptionTier) => void;
}

export default function Pricing({ currentUser, onSelectPlan }: PricingProps) {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "annual">("monthly");

  const plans = [
    {
      id: "free_trial" as SubscriptionTier,
      name: "Free Trial",
      description: "Ideal for testing your calorie and macro tracking variables risk-free.",
      price: 0,
      period: "14 Days",
      features: [
        "14-day fully featured sandbox trial",
        "No credit card required to start",
        "Full daily intake calorie logger",
        "Manual target nutrient controls",
        "Dynamic custom nutrient goal creation",
        "Single user local persistence"
      ],
      notIncluded: [
        "AI food photo scanner & volume estimation",
        "Interactive personal AI Coach Chat",
        "Intelligent macronutrient intake auditing",
        "Priority sports science ticket support"
      ],
      buttonText: "Start Trial Sandbox",
      color: "border-indigo-100 text-indigo-950 bg-white",
      btnClass: "bg-indigo-50 text-indigo-950 hover:bg-indigo-100 border-2 border-indigo-200"
    },
    {
      id: "basic" as SubscriptionTier,
      name: "Basic Plan",
      description: "Perfect for active individuals looking to upgrade daily macro planning.",
      price: 5,
      period: "month",
      features: [
        "Full access to all core tracking modules",
        "Basic customer support services",
        "Standard AI usage limits",
        "AI food scanning & photo calorie estimation",
        "Dynamic visual macro progress metrics"
      ],
      notIncluded: [
        "Priority professional support ticketing",
        "Advanced nutritional daily audits",
        "24/7 live AI Coach Chatbot (FuelBot)",
        "Team sharing & dietitian collaboration tools"
      ],
      buttonText: "Upgrade to Basic",
      color: "border-indigo-100 text-indigo-950 bg-indigo-50/30",
      btnClass: "bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-600/25"
    },
    {
      id: "pro" as SubscriptionTier,
      name: "Pro Plan",
      description: "Our recommended tier for athletes, bodybuilders, and sports coaches.",
      price: 15,
      period: "month",
      isRecommended: true,
      features: [
        "Everything included in the Basic tier",
        "Higher AI usage & response limits",
        "Priority support channels (24h response)",
        "Advanced analytics & weekly trends",
        "AI meal analysis audits & recipes",
        "Faster server response priorities"
      ],
      notIncluded: [
        "24/7 live AI Coach Chatbot (FuelBot)",
        "Team collaboration & shared team portals"
      ],
      buttonText: "Join Pro League",
      color: "border-indigo-600 text-indigo-950 bg-white ring-4 ring-indigo-600/20 relative",
      btnClass: "bg-indigo-600 text-white hover:bg-indigo-700 shadow-xl shadow-indigo-600/40"
    },
    {
      id: "expert" as SubscriptionTier,
      name: "Expert Plan",
      description: "Ultimate power pack designed for coaching professionals and gym networks.",
      price: 50,
      period: "month",
      features: [
        "Everything in the Pro plan, fully unlocked",
        "Unlimited AI usage (fair use policy)",
        "Premium priority support channels",
        "Live 24/7 AI Coach Chatbot (FuelBot)",
        "Team collaboration & shared dietitian portals",
        "Early access to new experimental features"
      ],
      notIncluded: [],
      buttonText: "Deploy Expert Stack",
      color: "border-indigo-950 text-indigo-950 bg-indigo-950/5 relative overflow-hidden",
      btnClass: "bg-indigo-950 text-white hover:bg-zinc-900 shadow-xl shadow-indigo-950/35"
    }
  ];

  return (
    <div className="space-y-12 pb-16">
      {/* Visual Hub Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-1.5 rounded-full bg-indigo-100 px-4.5 py-1.5 text-xs font-black text-indigo-700 uppercase tracking-widest"
        >
          <Award className="h-4.5 w-4.5 text-indigo-600" />
          Track & Fuel Licensing Tiers
        </motion.div>
        
        <h2 className="font-sans text-5xl md:text-6xl font-black text-indigo-950 tracking-tighter leading-none">
          Choose Your Nutrition Velocity
        </h2>
        
        <p className="text-lg text-indigo-600 font-bold opacity-80 max-w-2xl mx-auto">
          Scale from custom self-tracking up to fully responsive AI-driven dietary audits. Change, pause, or adjust your subscriptions with zero transaction penalties.
        </p>

        {/* Annual / Monthly Toggle Switch */}
        <div className="flex items-center justify-center gap-3 pt-4">
          <span className={`text-xs uppercase font-black tracking-widest transition-colors ${billingCycle === "monthly" ? "text-indigo-950" : "text-indigo-400"}`}>
            Monthly Billing
          </span>
          <button
            onClick={() => setBillingCycle(prev => prev === "monthly" ? "annual" : "monthly")}
            className="w-14 h-8 bg-indigo-200 hover:bg-indigo-300 rounded-full p-1 transition-colors relative flex items-center"
          >
            <motion.div
              layout
              className="h-6 w-6 rounded-full bg-indigo-600 shadow-md"
              animate={{ x: billingCycle === "monthly" ? 0 : 24 }}
              transition={{ type: "spring", stiffness: 500, damping: 30 }}
            />
          </button>
          <span className={`text-xs uppercase font-black tracking-widest transition-colors ${billingCycle === "annual" ? "text-indigo-950 animate-pulse" : "text-indigo-400"}`}>
            Annual Saver (20% OFF) 🎁
          </span>
        </div>
      </div>

      {/* Plans Layout Grid */}
      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4 max-w-7xl mx-auto px-4">
        {plans.map((plan) => {
          const isCurrentPlan = currentUser.tier === plan.id && currentUser.status !== "expired";
          const displayPrice = billingCycle === "annual" ? Math.round(plan.price * 0.8) : plan.price;

          return (
            <motion.div
              key={plan.id}
              className={`rounded-[36px] border-4 p-8 flex flex-col justify-between shadow-lg transition-shadow hover:shadow-2xl ${plan.color}`}
              whileHover={{ y: -8 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
            >
              {/* Highlight / Recommended Ribbon */}
              {plan.isRecommended && (
                <div className="absolute top-0 right-1/2 translate-x-1/2 -translate-y-1/2 bg-indigo-600 text-white text-[10px] font-black uppercase tracking-widest px-4 py-1.5 rounded-full shadow-lg flex items-center gap-1 whitespace-nowrap">
                  <Sparkles className="h-3 w-3 text-amber-300 fill-amber-300" />
                  Most Recommended Tier
                </div>
              )}

              {plan.id === "expert" && (
                <div className="absolute top-3 right-3 text-indigo-400 opacity-20">
                  <Zap className="h-20 w-20 fill-indigo-400 stroke-none" />
                </div>
              )}

              {/* Pricing Core Info */}
              <div className="space-y-6">
                <div>
                  <h3 className="font-sans text-2xl font-black text-indigo-950 tracking-tight flex items-center gap-2">
                    {plan.name}
                    {isCurrentPlan && (
                      <span className="inline-block rounded-full bg-emerald-100 text-emerald-800 text-[9px] font-black uppercase tracking-widest px-2.5 py-1">
                        Active Now
                      </span>
                    )}
                  </h3>
                  <p className="text-xs text-indigo-500 font-bold mt-2 leading-relaxed h-12">
                    {plan.description}
                  </p>
                </div>

                <hr className="border-indigo-50 border-2" />

                {/* Price Display */}
                <div>
                  <div className="flex items-baseline gap-1 text-indigo-950">
                    <span className="text-sm font-black tracking-widest uppercase">$</span>
                    <span className="text-5xl font-black tracking-tighter">{displayPrice}</span>
                    <span className="text-xs text-indigo-400 font-bold tracking-widest uppercase">
                      /{plan.period === "month" ? "mo" : plan.period}
                    </span>
                  </div>
                  {billingCycle === "annual" && plan.price > 0 && (
                    <span className="text-[10px] text-emerald-600 font-extrabold block mt-1 uppercase tracking-widest">
                      Billed yearly (Save ${plan.price * 12 - displayPrice * 12}/yr)
                    </span>
                  )}
                </div>

                <hr className="border-indigo-50 border-2" />

                {/* Feature Checklists */}
                <div className="space-y-4">
                  <span className="block text-[10px] font-black text-indigo-500 uppercase tracking-widest">
                    Included Capabilities
                  </span>
                  <div className="space-y-2.5">
                    {plan.features.map((feat, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs font-bold text-indigo-950 leading-normal">
                        <Check className="h-4.5 w-4.5 text-indigo-600 shrink-0 stroke-[3px]" />
                        <span>{feat}</span>
                      </div>
                    ))}
                    {plan.notIncluded.map((feat, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs font-bold text-indigo-400 opacity-60 leading-normal line-through decoration-indigo-300">
                        <span className="text-indigo-300 shrink-0 font-bold">•</span>
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Order / Licensing CTA Button */}
              <div className="pt-8">
                {isCurrentPlan ? (
                  <div className="w-full text-center py-4 bg-emerald-50 text-emerald-950 font-black text-xs uppercase tracking-widest rounded-2xl border-2 border-emerald-100 flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="h-4.5 w-4.5 text-emerald-500" />
                    Currently Licensed
                  </div>
                ) : (
                  <button
                    onClick={() => onSelectPlan(plan.id)}
                    className={`w-full py-4 text-xs font-black uppercase tracking-widest rounded-2xl transition-transform active:scale-95 ${plan.btnClass}`}
                  >
                    {plan.buttonText}
                  </button>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Fair use warning details block */}
      <div className="max-w-4xl mx-auto rounded-[36px] border-4 border-indigo-100 bg-white p-8 flex flex-col md:flex-row items-center gap-6 shadow-md">
        <div className="h-12 w-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
          <Shield className="h-6 w-6" />
        </div>
        <div className="space-y-1.5 text-center md:text-left">
          <h4 className="font-sans text-md font-black text-indigo-950 uppercase tracking-wide">
            Stripe & SSL Security Protection Core
          </h4>
          <p className="text-xs text-indigo-500 font-bold leading-relaxed">
            All credit cards are handled on proxy gateways in secure testing variables. Downgrades take effect immediately, while upgrades instantly calculate prorated credits. For corporate, white-labeled API or dietitian volume enterprise inquiries, please write to us directly.
          </p>
        </div>
      </div>
    </div>
  );
}
