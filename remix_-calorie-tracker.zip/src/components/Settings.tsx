import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { UserProfile, CustomNutrient } from "../types";
import { 
  Settings, Award, RefreshCw, Scale, Heart, 
  Dumbbell, Sparkles, AlertCircle, Save, Info, CheckCircle, Trash2, Plus, RefreshCcw, MoveUp, MoveDown
} from "lucide-react";

interface SettingsProps {
  profile: UserProfile;
  onUpdateProfile: (profile: UserProfile) => void;
  customNutrients: CustomNutrient[];
  onAddCustomNutrient: (name: string, unit: string, target: number) => void;
  onUpdateCustomNutrient: (id: string, name: string, unit: string, target: number) => void;
  onDeleteCustomNutrient: (id: string) => void;
  onResetUserData: () => void;
}

export default function SettingsComponent({ 
  profile, 
  onUpdateProfile,
  customNutrients,
  onAddCustomNutrient,
  onUpdateCustomNutrient,
  onDeleteCustomNutrient,
  onResetUserData,
}: SettingsProps) {
  // Local biological states
  const [age, setAge] = useState(profile.age);
  const [gender, setGender] = useState(profile.gender);
  const [height, setHeight] = useState(profile.height);
  const [weight, setWeight] = useState(profile.weight);
  const [activityLevel, setActivityLevel] = useState(profile.activityLevel);
  const [weightGoal, setWeightGoal] = useState(profile.weightGoal);
  
  const [fitnessGoal, setFitnessGoal] = useState<"lose_weight" | "maintain" | "gain_weight">("maintain");

  // Goals Manager States
  const [newGoalName, setNewGoalName] = useState("");
  const [newGoalUnit, setNewGoalUnit] = useState("g");
  const [newGoalTarget, setNewGoalTarget] = useState("");
  const [addingError, setAddingError] = useState("");

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState("");
  const [editingUnit, setEditingUnit] = useState("");
  const [editingTarget, setEditingTarget] = useState("");

  const [isCalculating, setIsCalculating] = useState(false);
  const [successBanner, setSuccessBanner] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);
  const [calculatedTarget, setCalculatedTarget] = useState<{
    bmr: number;
    tdee: number;
    calorieGoal: number;
    proteinGoal: number;
    carbsGoal: number;
    fatGoal: number;
  } | null>(null);

  // Auto calculate metabolic Baselines on biological values changes
  const triggerGoalCalculation = async () => {
    setIsCalculating(true);
    try {
      const response = await fetch("/api/goals/calculate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          age,
          gender,
          height,
          weight,
          activityLevel,
          fitnessGoal
        }),
      });
      const data = await response.json();
      if (!data.error) {
        setCalculatedTarget(data);
      }
    } catch (error) {
      console.error("Failed to calculate goals:", error);
    } finally {
      setIsCalculating(false);
    }
  };

  useEffect(() => {
    triggerGoalCalculation();
  }, [age, gender, height, weight, activityLevel, fitnessGoal]);

  // Turn metabolic calculation values into user-created Custom Goals!
  const handleApplyAsCustomGoals = () => {
    if (!calculatedTarget) return;

    // Remove duplicates by name first
    const itemsToAdd = [
      { name: "Daily Calories", unit: "kcal", target: calculatedTarget.calorieGoal },
      { name: "Protein", unit: "g", target: calculatedTarget.proteinGoal },
      { name: "Carbohydrates", unit: "g", target: calculatedTarget.carbsGoal },
      { name: "Fat", unit: "g", target: calculatedTarget.fatGoal }
    ];

    itemsToAdd.forEach(item => {
      const exists = customNutrients.some(cn => cn.name.toLowerCase() === item.name.toLowerCase());
      if (!exists) {
        onAddCustomNutrient(item.name, item.unit, item.target);
      }
    });

    setSuccessBanner(true);
    setTimeout(() => setSuccessBanner(false), 3000);
  };

  const handleAddGoal = (e: React.FormEvent) => {
    e.preventDefault();
    setAddingError("");
    if (!newGoalName.trim() || !newGoalTarget) return;

    // Check if name already exists
    const exists = customNutrients.some(cn => cn.name.toLowerCase() === newGoalName.toLowerCase().trim());
    if (exists) {
      setAddingError("A goal with this name already exists. Please edit that goal or choose a unique name.");
      return;
    }

    onAddCustomNutrient(newGoalName.trim(), newGoalUnit.trim() || "g", Number(newGoalTarget) || 0);
    setNewGoalName("");
    setNewGoalTarget("");
  };

  const handleStartEdit = (cn: CustomNutrient) => {
    setEditingId(cn.id);
    setEditingName(cn.name);
    setEditingUnit(cn.unit);
    setEditingTarget(cn.target.toString());
  };

  const handleSaveEdit = (id: string) => {
    if (!editingName.trim() || !editingTarget) return;
    onUpdateCustomNutrient(id, editingName.trim(), editingUnit.trim() || "g", Number(editingTarget) || 0);
    setEditingId(null);
  };

  const handleSaveBio = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      ...profile,
      age,
      gender,
      height,
      weight,
      activityLevel,
      weightGoal,
    });
    setSuccessBanner(true);
    setTimeout(() => setSuccessBanner(false), 4000);
  };

  const triggerReset = () => {
    if (confirm("🚨 DANGER: This will delete all of your logged meals, water logs, weight tracking, and custom goals forever. This action cannot be undone. Are you sure you want to proceed?")) {
      onResetUserData();
      setResetSuccess(true);
      setTimeout(() => setResetSuccess(false), 4000);
    }
  };

  return (
    <div className="space-y-12 pb-24">
      {/* Page Header */}
      <div>
        <h2 className="font-sans text-5xl font-black text-indigo-950 tracking-tight">
          Goals & Profile Settings
        </h2>
        <p className="mt-2 text-lg text-indigo-600 font-bold opacity-80">
          Maintain your custom tracking parameters, adjust physical metrics, or wipe user data locally.
        </p>
      </div>

      {/* Toast notifications */}
      <AnimatePresence>
        {successBanner && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex items-center gap-3.5 rounded-[24px] bg-emerald-50 border-4 border-emerald-100 px-6 py-4 text-sm text-emerald-950 font-black shadow-xl"
          >
            <CheckCircle className="h-6 w-6 text-emerald-500 shrink-0" />
            <span>Successfully updated goals and biological stats!</span>
          </motion.div>
        )}
        {resetSuccess && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex items-center gap-3.5 rounded-[24px] bg-red-50 border-4 border-red-100 px-6 py-4 text-sm text-red-950 font-black shadow-xl"
          >
            <AlertCircle className="h-6 w-6 text-red-500 shrink-0" />
            <span>All your personal data, targets, and logs have been deleted successfully.</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* PART 1: STAGE FOR CREATING AND EDITING CUSTOM NUTRIENTS (THE MANUAL-FIRST GOALS BOARD) */}
      <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-2xl space-y-8">
        <div>
          <h3 className="font-sans text-xl font-black text-indigo-950 uppercase flex items-center gap-2">
            <Sparkles className="h-5.5 w-5.5 text-indigo-600" />
            1. My Custom Nutrient Targets & Goals
          </h3>
          <p className="text-xs text-indigo-500 font-bold mt-1 uppercase tracking-widest">
            Nothing is loaded by default. Define, rename, alter, or remove tracking variables.
          </p>
        </div>

        {/* Existing targets list */}
        {customNutrients.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2">
            {customNutrients.map((cn) => {
              const isEditing = editingId === cn.id;
              return (
                <div 
                  key={cn.id} 
                  className="rounded-3xl border-2 border-indigo-50 p-5 bg-indigo-50/10 flex items-center justify-between gap-4"
                >
                  {isEditing ? (
                    <div className="flex-1 space-y-2">
                      <input 
                        type="text"
                        value={editingName}
                        onChange={(e) => setEditingName(e.target.value)}
                        className="w-full text-xs font-black uppercase border-2 border-indigo-200 bg-white rounded-xl p-2"
                        placeholder="Nutrient Name"
                      />
                      <div className="flex gap-2">
                        <input 
                          type="text"
                          value={editingUnit}
                          onChange={(e) => setEditingUnit(e.target.value)}
                          className="w-16 text-xs text-center border-2 border-indigo-200 bg-white rounded-xl p-2 font-mono"
                          placeholder="unit"
                        />
                        <input 
                          type="number"
                          value={editingTarget}
                          onChange={(e) => setEditingTarget(e.target.value)}
                          className="flex-1 text-xs border-2 border-indigo-200 bg-white rounded-xl p-2 font-bold"
                          placeholder="Limit"
                        />
                      </div>
                    </div>
                  ) : (
                    <div>
                      <h4 className="text-sm font-black text-indigo-950 uppercase flex items-center gap-1.5 leading-none">
                        {cn.name}
                        <span className="text-[10px] text-indigo-400 font-mono font-bold">({cn.unit})</span>
                      </h4>
                      <p className="text-xs text-indigo-500 font-bold mt-2">
                        Daily Goal: {cn.target.toLocaleString()} {cn.unit}
                      </p>
                    </div>
                  )}

                  <div className="flex items-center gap-1.5 shrink-0">
                    {isEditing ? (
                      <>
                        <button
                          onClick={() => handleSaveEdit(cn.id)}
                          className="p-2 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-xl transition-colors text-xs font-black"
                        >
                          Save
                        </button>
                        <button
                          onClick={() => setEditingId(null)}
                          className="p-2 bg-zinc-150 hover:bg-zinc-200 text-indigo-950 rounded-xl transition-colors text-xs font-black"
                        >
                          Cancel
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          onClick={() => handleStartEdit(cn)}
                          className="p-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-950 rounded-xl transition-colors text-xs font-black uppercase tracking-wider"
                        >
                          Modify
                        </button>
                        <button
                          onClick={() => onDeleteCustomNutrient(cn.id)}
                          className="p-2 bg-red-50 hover:bg-red-100 text-red-700 rounded-xl transition-colors text-xs font-black"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="border-2 border-dashed border-indigo-100 rounded-3xl p-6 text-center text-indigo-400 font-bold text-xs italic">
            No customized tracking metrics declared. Add some below to begin logging.
          </div>
        )}

        {/* Add goal sub-form */}
        <form onSubmit={handleAddGoal} className="border-t-2 border-indigo-50 pt-6 space-y-4">
          <h4 className="text-xs font-black text-indigo-400 uppercase tracking-widest">
            Create Custom Nutrient Track Target
          </h4>
          
          <div className="flex flex-col sm:flex-row gap-3">
            <input 
              type="text"
              required
              placeholder="Goal Name (e.g. Sugar, Iron, Daily Calories)"
              value={newGoalName}
              onChange={(e) => setNewGoalName(e.target.value)}
              className="flex-1 rounded-2xl border-4 border-indigo-50 px-4 py-3 text-sm font-black uppercase text-indigo-950 outline-none focus:border-indigo-300 transition-colors bg-indigo-50/10"
            />
            <input 
              type="text"
              required
              placeholder="Unit (g, mg, ml, IU)"
              value={newGoalUnit}
              onChange={(e) => setNewGoalUnit(e.target.value)}
              className="w-full sm:w-28 rounded-2xl border-4 border-indigo-50 px-4 py-3 text-sm font-bold text-center text-indigo-950 outline-none focus:border-indigo-300 transition-colors font-mono bg-indigo-50/10"
            />
            <input 
              type="number"
              required
              placeholder="Daily Limit"
              value={newGoalTarget}
              onChange={(e) => setNewGoalTarget(e.target.value)}
              className="w-full sm:w-36 rounded-2xl border-4 border-indigo-50 px-4 py-3 text-sm font-bold text-indigo-950 outline-none focus:border-indigo-300 transition-colors font-mono bg-indigo-50/10"
            />
            <button
              type="submit"
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest transition-transform active:scale-95 flex items-center justify-center gap-1.5 shrink-0"
            >
              <Plus className="h-4.5 w-4.5 stroke-[3px]" />
              Add Target
            </button>
          </div>

          {addingError && (
            <p className="text-xs text-red-600 font-bold flex items-center gap-1.5">
              <AlertCircle className="h-4 w-4" />
              {addingError}
            </p>
          )}
        </form>
      </div>

      {/* PART 2: OPTIONAL METABOLIC ESTIMATOR (TDEE BASELINE CALCULATOR) */}
      <div className="grid gap-8 lg:grid-cols-3">
        {/* Bio metrics inputs */}
        <div className="lg:col-span-2 rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-2xl space-y-6">
          <h3 className="font-sans text-lg font-black text-indigo-950 uppercase flex items-center gap-2">
            <Heart className="h-5 w-5 text-indigo-600" />
            2. Bio Parameters & Activity Factors
          </h3>

          <form onSubmit={handleSaveBio} className="space-y-6">
            <div className="grid gap-6 sm:grid-cols-2">
              <div>
                <label className="block text-xs font-black text-indigo-500 uppercase tracking-widest mb-1.5">Age (Years)</label>
                <input
                  type="number"
                  required
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value) || 0)}
                  className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3 text-sm font-bold text-indigo-950 outline-none focus:border-indigo-400 transition-colors font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-black text-indigo-500 uppercase tracking-widest mb-1.5">Gender</label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as any)}
                  className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3 text-sm font-black text-indigo-950 outline-none focus:border-indigo-400 transition-colors"
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-black text-indigo-500 uppercase tracking-widest mb-1.5">Height (cm)</label>
                <input
                  type="number"
                  required
                  value={height}
                  onChange={(e) => setHeight(Number(e.target.value) || 0)}
                  className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3 text-sm font-bold text-indigo-950 outline-none focus:border-indigo-400 transition-colors font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-black text-indigo-500 uppercase tracking-widest mb-1.5">Current Weight (kg)</label>
                <input
                  type="number"
                  required
                  value={weight}
                  onChange={(e) => setWeight(Number(e.target.value) || 0)}
                  className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3 text-sm font-bold text-indigo-950 outline-none focus:border-indigo-400 transition-colors font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-black text-indigo-500 uppercase tracking-widest mb-1.5">Target Goal Weight (kg)</label>
                <input
                  type="number"
                  required
                  value={weightGoal}
                  onChange={(e) => setWeightGoal(Number(e.target.value) || 0)}
                  className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3 text-sm font-bold text-indigo-950 outline-none focus:border-indigo-400 transition-colors font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-black text-indigo-500 uppercase tracking-widest mb-1.5">Weight Goal Direction</label>
                <select
                  value={fitnessGoal}
                  onChange={(e) => setFitnessGoal(e.target.value as any)}
                  className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3 text-sm font-black text-indigo-950 outline-none focus:border-indigo-400 transition-colors"
                >
                  <option value="lose_weight">Deficit (Weight Loss)</option>
                  <option value="maintain">Maintenance (Keep Static)</option>
                  <option value="gain_weight">Surplus (Muscle Gain)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-black text-indigo-500 uppercase tracking-widest mb-1.5">Weekly Activity Factor</label>
              <select
                value={activityLevel}
                onChange={(e) => setActivityLevel(e.target.value as any)}
                className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3 text-sm font-black text-indigo-950 outline-none focus:border-indigo-400 transition-colors"
              >
                <option value="sedentary">Sedentary (desk job, low active motion)</option>
                <option value="light">Light Activity (light exercise 1-3 days/week)</option>
                <option value="moderate">Moderate Activity (regular training 3-5 days/week)</option>
                <option value="active">Active Athletics (intense sports 6-7 days/week)</option>
                <option value="very_active">Elite Athletics / heavy construction worker</option>
              </select>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="px-6 py-3 bg-indigo-950 hover:bg-indigo-900 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-colors"
              >
                Save Biological Stats Only
              </button>
            </div>
          </form>
        </div>

        {/* Metabolic Calculations and Action Card */}
        <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-2xl flex flex-col justify-between gap-6">
          <h3 className="font-sans text-lg font-black text-indigo-950 uppercase flex items-center gap-2">
            <Dumbbell className="h-5 w-5 text-indigo-600 animate-bounce" />
            3. Dynamic BMR/TDEE
          </h3>

          {isCalculating ? (
            <div className="flex-1 flex flex-col items-center justify-center py-10">
              <RefreshCw className="h-10 w-10 text-indigo-600 animate-spin" />
              <p className="mt-3 text-sm font-black text-indigo-950">Recalculating Baselines...</p>
            </div>
          ) : calculatedTarget ? (
            <div className="space-y-4 flex-1 flex flex-col justify-center">
              <div className="bg-indigo-50/50 rounded-2xl p-4 flex justify-between items-center border-2 border-indigo-50">
                <span className="text-xs font-black text-indigo-500 uppercase tracking-widest">BMR</span>
                <span className="font-sans text-base font-black text-indigo-950">{calculatedTarget.bmr} kcal</span>
              </div>

              <div className="bg-indigo-50/50 rounded-2xl p-4 flex justify-between items-center border-2 border-indigo-50">
                <span className="text-xs font-black text-indigo-500 uppercase tracking-widest">TDEE</span>
                <span className="font-sans text-base font-black text-indigo-950">{calculatedTarget.tdee} kcal</span>
              </div>

              <div className="bg-indigo-50 border-2 border-indigo-150 rounded-2xl p-4 flex justify-between items-center">
                <span className="text-xs font-black text-indigo-500 uppercase tracking-widest">Calorie Recommendation</span>
                <span className="font-sans text-base font-black text-indigo-950">{calculatedTarget.calorieGoal} kcal</span>
              </div>

              <button
                type="button"
                onClick={handleApplyAsCustomGoals}
                className="w-full rounded-2xl bg-indigo-600 py-4 text-xs font-black text-white shadow-lg shadow-indigo-600/20 hover:bg-indigo-700 active:scale-95 transition-all uppercase tracking-wider"
              >
                APPLY AS CUSTOM TRACKING GOALS ⚡
              </button>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center py-10 text-center">
              <AlertCircle className="h-10 w-10 text-indigo-200 mx-auto" />
              <p className="mt-3 text-sm font-black text-indigo-950">Fill biological stats on left to load metabolic recommendations</p>
            </div>
          )}
        </div>
      </div>

      {/* PART 3: RED DESTRUCTIVE PANEL (WIPE PERSONAL DATA) */}
      <div className="rounded-[40px] border-4 border-red-100 bg-red-50/30 p-8 shadow-xl space-y-4.5">
        <div>
          <h3 className="font-sans text-lg font-black text-red-950 uppercase flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-red-600 animate-pulse" />
            Dangerous Operation: Wipe Personal Data Only
          </h3>
          <p className="text-xs text-red-500 font-bold uppercase tracking-widest mt-1">
            Wipe your specific logs, settings, custom nutrients, water levels, and weight charts.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-red-100 pt-4">
          <p className="text-xs text-red-800 font-bold max-w-xl leading-relaxed">
            This operation acts exclusively on your personal session storage profile (<code>custom_nutrients_user</code>, meal registries, and biological stats logs). Shared admin datasets or subscriptions are completely unaffected.
          </p>
          <button
            type="button"
            onClick={triggerReset}
            className="px-6 py-4 bg-red-600 hover:bg-red-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest transition-transform active:scale-95 shrink-0 shadow-lg shadow-red-600/10"
          >
            Reset My Personal Workspace
          </button>
        </div>
      </div>
    </div>
  );
}
