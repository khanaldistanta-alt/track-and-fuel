import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Plus, Trash2, Droplets, Scale, Utensils, 
  TrendingUp, RefreshCw, Apple, AlertCircle, Info, ArrowUp, ArrowDown, Edit2, Check, X, Sparkles, Award
} from "lucide-react";
import { LogEntry, MealType, FoodItem, UserProfile, CustomNutrient, UserAccount } from "../types";

interface DashboardProps {
  logs: LogEntry[];
  profile: UserProfile;
  weightLogs: { date: string; weight: number }[];
  waterLogs: { date: string; amount: number }[];
  customNutrients: CustomNutrient[];
  currentUser: UserAccount;
  onAddCustomLog: (item: Omit<FoodItem, "id">, quantity: number, mealType: MealType) => void;
  onDeleteLog: (id: string) => void;
  onLogWeight: (weight: number) => void;
  onAddWater: (amount: number) => void;
  onClearAllLogs: () => void;
  onNavigateToTab: (tab: string) => void;
  onAddCustomNutrient: (name: string, unit: string, target: number) => void;
  onUpdateCustomNutrient: (id: string, name: string, unit: string, target: number) => void;
  onDeleteCustomNutrient: (id: string) => void;
  onReorderCustomNutrients: (newNutrients: CustomNutrient[]) => void;
}

export default function Dashboard({
  logs,
  profile,
  weightLogs,
  waterLogs,
  customNutrients,
  currentUser,
  onAddCustomLog,
  onDeleteLog,
  onLogWeight,
  onAddWater,
  onClearAllLogs,
  onNavigateToTab,
  onAddCustomNutrient,
  onUpdateCustomNutrient,
  onDeleteCustomNutrient,
  onReorderCustomNutrients,
}: DashboardProps) {
  // Local state for meal log modal
  const [quickAddMeal, setQuickAddMeal] = useState<MealType | null>(null);
  const [customName, setCustomName] = useState("");
  const [customServingSize, setCustomServingSize] = useState("1");
  const [customServingUnit, setCustomServingUnit] = useState("serving");
  
  // Dynamic fields state for manual food logger
  const [manualNutrientValues, setManualNutrientValues] = useState<Record<string, string>>({});

  // Local state for adding/editing goals
  const [isAddingNutrient, setIsAddingNutrient] = useState(false);
  const [newNutrientName, setNewNutrientName] = useState("");
  const [newNutrientUnit, setNewNutrientUnit] = useState("g");
  const [newNutrientTarget, setNewNutrientTarget] = useState("");
  
  const [editingNutrientId, setEditingNutrientId] = useState<string | null>(null);
  const [editNutrientName, setEditNutrientName] = useState("");
  const [editNutrientUnit, setEditNutrientUnit] = useState("");
  const [editNutrientTarget, setEditNutrientTarget] = useState("");

  // Weight Logging state
  const [weightInput, setWeightInput] = useState("");

  const todayStr = new Date().toISOString().split("T")[0];

  // Sum up today's logs for each custom nutrient
  const getConsumedAmount = (nutrientId: string) => {
    return logs.reduce((sum, entry) => {
      // Direct custom entry match
      if (entry.foodItem.nutrients && entry.foodItem.nutrients[nutrientId] !== undefined) {
        return sum + (entry.foodItem.nutrients[nutrientId] || 0) * entry.quantity;
      }
      
      // Fallback name matching for standard foods in the database
      const nutrient = customNutrients.find(n => n.id === nutrientId);
      if (!nutrient) return sum;
      
      const lowerName = nutrient.name.toLowerCase();
      let fallbackVal = 0;
      if (lowerName.includes("calorie") || lowerName === "kcal" || lowerName === "energy") {
        fallbackVal = entry.foodItem.calories || 0;
      } else if (lowerName.includes("protein")) {
        fallbackVal = entry.foodItem.protein || 0;
      } else if (lowerName.includes("carb")) {
        fallbackVal = entry.foodItem.carbs || 0;
      } else if (lowerName.includes("fat")) {
        fallbackVal = entry.foodItem.fat || 0;
      } else if (lowerName.includes("fiber")) {
        fallbackVal = (entry.foodItem as any).fiber || 0;
      } else if (lowerName.includes("sugar")) {
        fallbackVal = (entry.foodItem as any).sugar || 0;
      } else if (lowerName.includes("sodium")) {
        fallbackVal = (entry.foodItem as any).sodium || 0;
      } else if (lowerName.includes("water")) {
        fallbackVal = (entry.foodItem as any).water || 0;
      }
      return sum + fallbackVal * entry.quantity;
    }, 0);
  };

  // Today's biological stats
  const todayWeight = weightLogs.find((w) => w.date === todayStr)?.weight || profile.weight;
  const todayWater = waterLogs.find((w) => w.date === todayStr)?.amount || 0;

  // Handles adding custom log with dynamic manual fields
  const handleLogSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim()) return;

    // Convert dynamic values state into dynamic nutrients record
    const loggedNutrients: Record<string, number> = {};
    customNutrients.forEach(cn => {
      loggedNutrients[cn.id] = Number(manualNutrientValues[cn.id]) || 0;
    });

    // Populate standard backwards-compatible fields
    let calories = 0;
    let protein = 0;
    let carbs = 0;
    let fat = 0;

    customNutrients.forEach(cn => {
      const lowerName = cn.name.toLowerCase();
      const val = loggedNutrients[cn.id];
      if (lowerName.includes("calorie") || lowerName === "kcal" || lowerName === "energy") {
        calories = val;
      } else if (lowerName.includes("protein")) {
        protein = val;
      } else if (lowerName.includes("carb")) {
        carbs = val;
      } else if (lowerName.includes("fat")) {
        fat = val;
      }
    });

    onAddCustomLog(
      {
        name: customName,
        calories,
        protein,
        carbs,
        fat,
        servingSize: Number(customServingSize) || 1,
        servingUnit: customServingUnit || "serving",
        nutrients: loggedNutrients,
      },
      1,
      quickAddMeal!
    );

    // Reset Form
    setCustomName("");
    setCustomServingSize("1");
    setCustomServingUnit("serving");
    setManualNutrientValues({});
    setQuickAddMeal(null);
  };

  // Preset suggestions for rapid goal addition
  const presets = [
    { name: "Daily Calories", unit: "kcal", target: 2000 },
    { name: "Protein", unit: "g", target: 140 },
    { name: "Carbohydrates", unit: "g", target: 220 },
    { name: "Fat", unit: "g", target: 65 },
    { name: "Fiber", unit: "g", target: 30 },
    { name: "Sugar", unit: "g", target: 50 },
    { name: "Sodium", unit: "mg", target: 2300 },
    { name: "Water intake", unit: "ml", target: 2500 },
    { name: "Iron", unit: "mg", target: 18 },
    { name: "Vitamin C", unit: "mg", target: 90 },
  ];

  const handleAddPreset = (p: typeof presets[0]) => {
    onAddCustomNutrient(p.name, p.unit, p.target);
  };

  // Reordering helpers
  const handleMoveUp = (index: number) => {
    if (index === 0) return;
    const items = [...customNutrients];
    const temp = items[index];
    items[index] = items[index - 1];
    items[index - 1] = temp;
    onReorderCustomNutrients(items);
  };

  const handleMoveDown = (index: number) => {
    if (index === customNutrients.length - 1) return;
    const items = [...customNutrients];
    const temp = items[index];
    items[index] = items[index + 1];
    items[index + 1] = temp;
    onReorderCustomNutrients(items);
  };

  const handleStartEdit = (cn: CustomNutrient) => {
    setEditingNutrientId(cn.id);
    setEditNutrientName(cn.name);
    setEditNutrientUnit(cn.unit);
    setEditNutrientTarget(cn.target.toString());
  };

  const handleSaveEdit = (id: string) => {
    if (!editNutrientName.trim() || !editNutrientTarget) return;
    onUpdateCustomNutrient(id, editNutrientName, editNutrientUnit, Number(editNutrientTarget) || 0);
    setEditingNutrientId(null);
  };

  // Meal sections render details
  const mealTypes: { type: MealType; label: string; desc: string; emoji: string }[] = [
    { type: "breakfast", label: "Breakfast Intake", desc: "Start strong with dense nourishment", emoji: "🍳" },
    { type: "lunch", label: "Lunch Intake", desc: "Keep insulin levels balanced for focus", emoji: "🍱" },
    { type: "dinner", label: "Dinner Intake", desc: "Prioritize sleep hygiene and slow protein", emoji: "🍽️" },
    { type: "snack", label: "Snacking & Fuel", desc: "Energy corrections and performance boosters", emoji: "🍌" },
  ];

  return (
    <div className="space-y-12 pb-24">
      
      {/* 3D Animated Title Name called "Track & Fuel" */}
      <div className="flex flex-col items-center justify-center pt-8 pb-4">
        <div className="relative group perspective-1000">
          <motion.h1 
            id="track_fuel_logo_3d"
            className="text-6xl sm:text-7xl md:text-8xl font-black text-center tracking-tighter uppercase select-none cursor-pointer"
            style={{
              background: "linear-gradient(135deg, #4f46e5 0%, #7c3aed 50%, #db2777 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              textShadow: "1px 1px 0px rgba(79, 70, 229, 0.2), 2px 2px 0px rgba(124, 58, 237, 0.15), 3px 3px 0px rgba(219, 39, 119, 0.1), 0px 10px 30px rgba(79, 70, 229, 0.2)",
              transformStyle: "preserve-3d",
            }}
            whileHover={{ 
              rotateY: 10, 
              rotateX: -10, 
              scale: 1.05,
              translateZ: 30
            }}
            transition={{ type: "spring", stiffness: 400, damping: 15 }}
          >
            TRACK & FUEL
          </motion.h1>
          <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-indigo-500 via-purple-600 to-pink-500 opacity-20 blur-xl group-hover:opacity-45 transition-all duration-500 -z-10" />
        </div>
        <p className="text-[10px] sm:text-xs font-black text-indigo-500 uppercase tracking-widest mt-4">
          Manual-First Metabolic Performance Workspace
        </p>
      </div>

      {/* Conditional setup state if 0 custom goals */}
      {customNutrients.length === 0 ? (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto rounded-[36px] border-4 border-dashed border-indigo-200 bg-white p-8 md:p-12 text-center space-y-8 shadow-xl"
        >
          <div className="mx-auto h-20 w-20 rounded-3xl bg-indigo-50 flex items-center justify-center text-indigo-600">
            <Apple className="h-10 w-10 animate-bounce" />
          </div>
          
          <div className="space-y-4">
            <h3 className="font-sans text-3xl md:text-4xl font-black text-indigo-950 tracking-tight leading-none">
              Zero Pre-Configured Goals Loaded
            </h3>
            <p className="text-sm md:text-md text-indigo-600 font-bold opacity-80 max-w-xl mx-auto leading-relaxed">
              To honor a clean mechanical design, we deleted all cookie-cutter recommendations, automatic calorie budgets, and protein guidelines. Define exactly what your body needs to track!
            </p>
          </div>

          <div className="border-t-2 border-indigo-50 pt-8 space-y-6">
            <h4 className="text-xs font-black text-indigo-400 uppercase tracking-widest">
              Quick Starter Goals Preset (Click to Add instantly)
            </h4>
            <div className="flex flex-wrap justify-center gap-2.5">
              {presets.map((p, idx) => {
                const isAlreadyAdded = customNutrients.some(cn => cn.name.toLowerCase() === p.name.toLowerCase());
                return (
                  <button
                    key={idx}
                    disabled={isAlreadyAdded}
                    onClick={() => handleAddPreset(p)}
                    className={`px-4.5 py-2.5 rounded-full text-xs font-black uppercase tracking-wider transition-all duration-200 flex items-center gap-1.5 active:scale-95 ${
                      isAlreadyAdded
                        ? "bg-indigo-50 text-indigo-300 cursor-not-allowed border-2 border-indigo-100"
                        : "bg-indigo-50 hover:bg-indigo-600 hover:text-white text-indigo-950 border-2 border-indigo-200 hover:border-indigo-600 shadow-sm"
                    }`}
                  >
                    <Plus className="h-3.5 w-3.5" />
                    {p.name} ({p.target}{p.unit})
                  </button>
                );
              })}
            </div>
          </div>

          <div className="bg-indigo-950 text-white rounded-3xl p-6 flex flex-col sm:flex-row items-center gap-4.5 justify-between text-left">
            <div className="space-y-1">
              <span className="inline-flex items-center gap-1 bg-indigo-800 text-white text-[9px] font-black uppercase tracking-widest px-2.5 py-1 rounded-full">
                <Sparkles className="h-3 w-3 text-amber-300 fill-amber-300" />
                Want AI assistance instead?
              </span>
              <p className="text-xs font-bold opacity-90 leading-normal">
                Unlock automated photos scanning and calorie calculations using Google's elite Gemini AI models!
              </p>
            </div>
            <button
              onClick={() => onNavigateToTab("pricing")}
              className="px-5 py-3 rounded-2xl bg-white text-indigo-950 font-black text-xs uppercase tracking-widest hover:bg-indigo-50 transition-colors shrink-0"
            >
              Unlock Premium AI
            </button>
          </div>
        </motion.div>
      ) : (
        <div className="space-y-12">
          
          {/* Main Dashboard Grid with custom visual Bento boxes */}
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {customNutrients.map((cn, idx) => {
              const consumed = getConsumedAmount(cn.id);
              const percentage = cn.target > 0 ? Math.min(100, Math.round((consumed / cn.target) * 100)) : 0;
              const isOverGoal = consumed > cn.target;
              const isEditing = editingNutrientId === cn.id;

              return (
                <motion.div
                  key={cn.id}
                  layout
                  className={`rounded-[32px] border-4 p-6 flex flex-col justify-between transition-all bg-white shadow-xl ${
                    isOverGoal ? "border-amber-400" : "border-indigo-100"
                  }`}
                  whileHover={{ y: -4 }}
                >
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      {isEditing ? (
                        <div className="space-y-2 w-full">
                          <input
                            type="text"
                            value={editNutrientName}
                            onChange={(e) => setEditNutrientName(e.target.value)}
                            className="w-full text-xs font-black uppercase border-2 border-indigo-200 rounded-lg p-1.5 focus:outline-none focus:border-indigo-600"
                            placeholder="Goal Name"
                          />
                          <div className="flex gap-1.5">
                            <input
                              type="text"
                              value={editNutrientUnit}
                              onChange={(e) => setEditNutrientUnit(e.target.value)}
                              className="w-16 text-xs font-mono border-2 border-indigo-200 rounded-lg p-1.5 focus:outline-none focus:border-indigo-600"
                              placeholder="unit"
                            />
                            <input
                              type="number"
                              value={editNutrientTarget}
                              onChange={(e) => setEditNutrientTarget(e.target.value)}
                              className="flex-1 text-xs border-2 border-indigo-200 rounded-lg p-1.5 focus:outline-none focus:border-indigo-600 font-bold"
                              placeholder="Target Limit"
                            />
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-0.5">
                          <h4 className="font-sans text-md font-black text-indigo-950 uppercase tracking-tight flex items-center gap-1.5">
                            {cn.name}
                            <span className="text-[10px] font-bold text-indigo-400 font-mono">({cn.unit})</span>
                          </h4>
                          <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-widest">
                            Target: {cn.target} {cn.unit}
                          </span>
                        </div>
                      )}

                      {/* Editing Actions */}
                      <div className="flex items-center gap-1 shrink-0">
                        {isEditing ? (
                          <>
                            <button
                              onClick={() => handleSaveEdit(cn.id)}
                              className="p-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-lg transition-colors"
                            >
                              <Check className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => setEditingNutrientId(null)}
                              className="p-1.5 bg-zinc-100 hover:bg-zinc-200 text-zinc-800 rounded-lg transition-colors"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </>
                        ) : (
                          <div className="flex items-center gap-0.5">
                            {/* Reorder Arrows */}
                            <button
                              disabled={idx === 0}
                              onClick={() => handleMoveUp(idx)}
                              title="Move Up"
                              className="p-1 text-indigo-400 hover:text-indigo-950 disabled:opacity-20 transition-colors"
                            >
                              <ArrowUp className="h-3.5 w-3.5" />
                            </button>
                            <button
                              disabled={idx === customNutrients.length - 1}
                              onClick={() => handleMoveDown(idx)}
                              title="Move Down"
                              className="p-1 text-indigo-400 hover:text-indigo-950 disabled:opacity-20 transition-colors"
                            >
                              <ArrowDown className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => handleStartEdit(cn)}
                              title="Modify Target"
                              className="p-1.5 hover:bg-indigo-50 text-indigo-500 hover:text-indigo-900 rounded-lg transition-colors ml-1"
                            >
                              <Edit2 className="h-3.5 w-3.5" />
                            </button>
                            <button
                              onClick={() => onDeleteCustomNutrient(cn.id)}
                              title="Delete Goal"
                              className="p-1.5 hover:bg-red-50 text-red-500 hover:text-red-900 rounded-lg transition-colors"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Progress representation */}
                    <div className="space-y-2">
                      <div className="flex items-baseline justify-between text-indigo-950">
                        <span className="text-3xl font-black font-sans leading-none">
                          {consumed.toLocaleString(undefined, { maximumFractionDigits: 1 })}
                        </span>
                        <span className="text-xs text-indigo-400 font-bold">
                          {percentage}% logged
                        </span>
                      </div>
                      
                      {/* Horizontal progress meter */}
                      <div className="w-full h-3 bg-indigo-50 rounded-full overflow-hidden border border-indigo-100">
                        <motion.div 
                          className={`h-full rounded-full ${isOverGoal ? 'bg-amber-500' : 'bg-indigo-600'}`}
                          initial={{ width: 0 }}
                          animate={{ width: `${percentage}%` }}
                          transition={{ duration: 0.6, ease: "easeOut" }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 flex items-center justify-between text-[10px] font-bold text-indigo-400 border-t border-indigo-50 mt-4 uppercase tracking-widest">
                    <span>Remaining</span>
                    <span className="font-mono text-indigo-950">
                      {cn.target - consumed > 0 
                        ? `${(cn.target - consumed).toLocaleString(undefined, { maximumFractionDigits: 1 })} ${cn.unit}` 
                        : "Target Met! ✓"}
                    </span>
                  </div>
                </motion.div>
              );
            })}

            {/* Quick Add Goal Card */}
            <motion.div
              layout
              className="rounded-[32px] border-4 border-dashed border-indigo-200 bg-indigo-50/20 p-6 flex flex-col justify-center items-center text-center space-y-4 shadow-sm"
            >
              {isAddingNutrient ? (
                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (!newNutrientName.trim() || !newNutrientTarget) return;
                    onAddCustomNutrient(newNutrientName, newNutrientUnit, Number(newNutrientTarget) || 0);
                    setNewNutrientName("");
                    setNewNutrientTarget("");
                    setIsAddingNutrient(false);
                  }}
                  className="w-full space-y-3.5 text-left"
                >
                  <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest block">
                    Define Tracking Goal
                  </span>
                  
                  <div className="space-y-2">
                    <input
                      type="text"
                      required
                      placeholder="Nutrient Name (e.g. Protein)"
                      value={newNutrientName}
                      onChange={(e) => setNewNutrientName(e.target.value)}
                      className="w-full px-3.5 py-2 text-xs font-black uppercase text-indigo-950 border-2 border-indigo-200 bg-white rounded-xl focus:outline-none focus:border-indigo-600"
                    />
                    <div className="flex gap-2">
                      <input
                        type="text"
                        required
                        placeholder="unit"
                        value={newNutrientUnit}
                        onChange={(e) => setNewNutrientUnit(e.target.value)}
                        className="w-18 px-3 py-2 text-xs font-mono text-center text-indigo-950 border-2 border-indigo-200 bg-white rounded-xl focus:outline-none focus:border-indigo-600"
                      />
                      <input
                        type="number"
                        required
                        placeholder="Daily Target"
                        value={newNutrientTarget}
                        onChange={(e) => setNewNutrientTarget(e.target.value)}
                        className="flex-1 px-3.5 py-2 text-xs font-bold text-indigo-950 border-2 border-indigo-200 bg-white rounded-xl focus:outline-none focus:border-indigo-600"
                      />
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <button
                      type="submit"
                      className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-black text-xs uppercase tracking-widest transition-colors shadow-lg shadow-indigo-600/20"
                    >
                      Save Goal
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsAddingNutrient(false)}
                      className="px-4 py-2.5 bg-zinc-100 hover:bg-zinc-200 text-indigo-950 rounded-xl font-black text-xs uppercase tracking-widest transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              ) : (
                <div className="space-y-4">
                  <div className="h-12 w-12 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center mx-auto">
                    <TrendingUp className="h-6 w-6" />
                  </div>
                  <div className="space-y-1">
                    <h5 className="font-sans text-md font-black text-indigo-950 uppercase tracking-tight">
                      Add Custom Goal
                    </h5>
                    <p className="text-xs text-indigo-500 font-bold">
                      Add custom vitamins, minerals, or macro parameters.
                    </p>
                  </div>
                  <button
                    onClick={() => setIsAddingNutrient(true)}
                    className="inline-flex items-center gap-1.5 px-4.5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-transform active:scale-95"
                  >
                    <Plus className="h-3.5 w-3.5 stroke-[3px]" />
                    Create Goal
                  </button>
                </div>
              )}
            </motion.div>
          </div>

          {/* Quick Helper presets below grid */}
          <div className="rounded-[28px] border-2 border-indigo-50 bg-white/60 p-4.5 flex flex-wrap items-center justify-between gap-3 shadow-md">
            <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest flex items-center gap-1.5">
              <Info className="h-4 w-4 text-indigo-600 shrink-0" />
              Add more goals from the quick list:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {presets.map((p, idx) => {
                const isAdded = customNutrients.some(cn => cn.name.toLowerCase() === p.name.toLowerCase());
                if (isAdded) return null;
                return (
                  <button
                    key={idx}
                    onClick={() => handleAddPreset(p)}
                    className="px-3.5 py-1.5 rounded-full bg-indigo-50 hover:bg-indigo-600 text-indigo-950 hover:text-white transition-all text-[10px] font-black uppercase tracking-wider border border-indigo-100 flex items-center gap-1"
                  >
                    <Plus className="h-3 w-3" />
                    {p.name}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Biometrics Node: Water and Weight */}
          <div className="grid gap-6 md:grid-cols-2">
            
            {/* Water Tracker Component */}
            <div className="rounded-[36px] border-4 border-indigo-100 bg-white p-8 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="space-y-4 text-center md:text-left">
                <div className="inline-flex h-11 w-11 items-center justify-center rounded-[18px] bg-blue-50 text-blue-600">
                  <Droplets className="h-5.5 w-5.5" />
                </div>
                <div>
                  <h4 className="font-sans text-xl font-black text-indigo-950 tracking-tight leading-none">
                    Hydration Log
                  </h4>
                  <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mt-1">
                    Record cellular water intake
                  </p>
                </div>
                <div className="flex items-baseline justify-center md:justify-start gap-1">
                  <span className="text-4xl font-black text-indigo-950">{todayWater}</span>
                  <span className="text-xs text-indigo-400 font-bold font-mono">ml</span>
                </div>
              </div>

              {/* Incremental actions */}
              <div className="flex flex-col gap-2 w-full max-w-[180px] shrink-0">
                <button
                  onClick={() => onAddWater(250)}
                  className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-black uppercase tracking-wider rounded-2xl transition-all flex items-center justify-center gap-1.5 active:scale-95 shadow-lg shadow-blue-600/20"
                >
                  <Plus className="h-3.5 w-3.5 stroke-[3px]" />
                  +250ml Glass
                </button>
                <button
                  onClick={() => onAddWater(500)}
                  className="w-full py-3.5 bg-blue-50 text-blue-950 border-2 border-blue-200 hover:bg-blue-100 text-[11px] font-black uppercase tracking-wider rounded-2xl transition-colors flex items-center justify-center gap-1.5"
                >
                  <Plus className="h-3.5 w-3.5" />
                  +500ml Bottle
                </button>
                <button
                  onClick={() => onAddWater(-250)}
                  disabled={todayWater <= 0}
                  className="w-full py-2 text-[9px] font-black text-blue-400 hover:text-blue-800 disabled:opacity-20 uppercase tracking-wider text-center"
                >
                  Remove 250ml
                </button>
              </div>
            </div>

            {/* Weight Tracker Component */}
            <div className="rounded-[36px] border-4 border-indigo-100 bg-white p-8 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="space-y-4 text-center md:text-left">
                <div className="inline-flex h-11 w-11 items-center justify-center rounded-[18px] bg-indigo-50 text-indigo-600">
                  <Scale className="h-5.5 w-5.5" />
                </div>
                <div>
                  <h4 className="font-sans text-xl font-black text-indigo-950 tracking-tight leading-none">
                    Bodyweight Registry
                  </h4>
                  <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mt-1">
                    Calibrate weight velocity
                  </p>
                </div>
                <div className="flex items-baseline justify-center md:justify-start gap-1">
                  <span className="text-4xl font-black text-indigo-950">{todayWeight}</span>
                  <span className="text-xs text-indigo-400 font-bold font-mono">kg</span>
                </div>
              </div>

              {/* Weight Form */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!weightInput) return;
                  onLogWeight(Number(weightInput));
                  setWeightInput("");
                }}
                className="flex flex-col gap-2 w-full max-w-[180px] shrink-0"
              >
                <input
                  type="number"
                  step="0.1"
                  required
                  placeholder="Record (kg)"
                  value={weightInput}
                  onChange={(e) => setWeightInput(e.target.value)}
                  className="w-full px-4 py-3 text-xs font-bold text-center border-2 border-indigo-200 rounded-2xl focus:outline-none focus:border-indigo-600 bg-indigo-50/30"
                />
                <button
                  type="submit"
                  className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-black uppercase tracking-wider rounded-2xl transition-colors shadow-lg shadow-indigo-600/20"
                >
                  Log Weight
                </button>
              </form>
            </div>
          </div>

          {/* Meals Logging Registry Sections */}
          <div className="space-y-8">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b-4 border-indigo-100 pb-4">
              <div>
                <h3 className="font-sans text-3xl font-black text-indigo-950 tracking-tight">
                  Daily Fuel Registry
                </h3>
                <p className="text-xs text-indigo-500 font-bold uppercase tracking-widest mt-1">
                  Chronological macro logging partitions
                </p>
              </div>
              <button
                onClick={onClearAllLogs}
                className="px-4.5 py-2.5 text-xs font-black uppercase tracking-widest border-2 border-indigo-200 text-indigo-600 hover:bg-indigo-50 rounded-2xl transition-colors shrink-0"
              >
                Reset Today's Logs ↺
              </button>
            </div>

            {/* Meal partition items */}
            <div className="grid gap-6">
              {mealTypes.map((mt) => {
                const mealLogs = logs.filter((l) => l.mealType === mt.type);
                return (
                  <div 
                    key={mt.type}
                    className="rounded-[32px] border-4 border-indigo-50 bg-white p-6 shadow-md hover:shadow-lg transition-shadow"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex items-start gap-4">
                        <span className="text-3xl shrink-0 mt-0.5">{mt.emoji}</span>
                        <div>
                          <h4 className="font-sans text-lg font-black text-indigo-950 tracking-tight leading-none flex items-center gap-2">
                            {mt.label}
                            <span className="rounded-full bg-indigo-50 px-2.5 py-0.5 text-[10px] font-mono font-bold text-indigo-600">
                              {mealLogs.length} logged
                            </span>
                          </h4>
                          <p className="text-xs font-bold text-indigo-400 mt-1.5">{mt.desc}</p>
                        </div>
                      </div>

                      {/* Log Action Button */}
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => setQuickAddMeal(mt.type)}
                          className="px-4.5 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase tracking-widest transition-colors flex items-center gap-1.5 shadow-md shadow-indigo-600/10"
                        >
                          <Plus className="h-4 w-4 stroke-[3px]" />
                          Manual Log
                        </button>
                        <button
                          onClick={() => onNavigateToTab("logger")}
                          className="px-4 py-3 rounded-2xl border-2 border-indigo-200 text-indigo-600 hover:bg-indigo-50 font-black text-xs uppercase tracking-widest transition-colors"
                        >
                          Find Food
                        </button>
                      </div>
                    </div>

                    {/* Meal items log list */}
                    {mealLogs.length > 0 ? (
                      <div className="mt-6 border-t border-indigo-50 pt-4 space-y-3">
                        {mealLogs.map((log) => (
                          <div 
                            key={log.id}
                            className="flex items-center justify-between gap-4 py-2.5 px-3 rounded-2xl hover:bg-indigo-50/50 transition-colors"
                          >
                            <div className="space-y-1 min-w-0">
                              <h5 className="font-sans text-sm font-black text-indigo-950 truncate">
                                {log.foodItem.name}
                              </h5>
                              <p className="text-xs text-indigo-500 font-bold flex flex-wrap items-center gap-x-2 gap-y-1">
                                <span>{log.quantity} × {log.foodItem.servingSize}{log.foodItem.servingUnit}</span>
                                <span className="text-indigo-200">•</span>
                                {/* Display active custom logged nutrient strings */}
                                {customNutrients.map((cn) => {
                                  const val = log.foodItem.nutrients?.[cn.id] !== undefined
                                    ? log.foodItem.nutrients[cn.id]
                                    : getConsumedAmount(cn.id) > 0 ? (
                                      cn.name.toLowerCase().includes("calorie") ? log.foodItem.calories :
                                      cn.name.toLowerCase().includes("protein") ? log.foodItem.protein :
                                      cn.name.toLowerCase().includes("carb") ? log.foodItem.carbs :
                                      cn.name.toLowerCase().includes("fat") ? log.foodItem.fat : 0
                                    ) : 0;
                                  return (
                                    <span key={cn.id} className="bg-indigo-50/50 px-1.5 py-0.5 rounded font-mono text-[10px]">
                                      {cn.name}: {val * log.quantity} {cn.unit}
                                    </span>
                                  );
                                })}
                              </p>
                            </div>

                            <button
                              onClick={() => onDeleteLog(log.id)}
                              className="p-2 hover:bg-red-50 text-red-400 hover:text-red-700 rounded-xl transition-colors shrink-0"
                            >
                              <Trash2 className="h-4.5 w-4.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="mt-6 border-t border-indigo-50 pt-4 text-center py-4">
                        <span className="text-xs text-indigo-400 font-bold italic">
                          No logged intake recorded for this window
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      )}

      {/* Manual Intake Quick-Add Overlay Modal Dialog */}
      <AnimatePresence>
        {quickAddMeal !== null && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-indigo-950/40 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-lg bg-white rounded-[36px] border-4 border-indigo-600 p-8 shadow-2xl relative"
            >
              <div className="flex items-center justify-between border-b-2 border-indigo-50 pb-4 mb-6">
                <div>
                  <h4 className="font-sans text-xl font-black text-indigo-950 uppercase tracking-tight">
                    Manual Intake Registry
                  </h4>
                  <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest mt-1">
                    Adding to {quickAddMeal}
                  </p>
                </div>
                <button
                  onClick={() => setQuickAddMeal(null)}
                  className="p-2 hover:bg-indigo-50 text-indigo-600 rounded-xl transition-colors"
                >
                  <X className="h-5.5 w-5.5" />
                </button>
              </div>

              {customNutrients.length === 0 ? (
                <div className="text-center py-6 space-y-4">
                  <p className="text-xs text-indigo-600 font-bold">
                    You have not configured any custom tracking goals! Set up your daily goals first under "Tracking Goals" to log metrics.
                  </p>
                  <button
                    onClick={() => {
                      setQuickAddMeal(null);
                      setIsAddingNutrient(true);
                      window.scrollTo({ top: 100, behavior: "smooth" });
                    }}
                    className="px-4.5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-widest rounded-xl"
                  >
                    Set Up Goals First
                  </button>
                </div>
              ) : (
                <form onSubmit={handleLogSubmit} className="space-y-5">
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">
                      Food Item Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Scrambled eggs"
                      value={customName}
                      onChange={(e) => setCustomName(e.target.value)}
                      className="w-full px-4 py-3 text-xs font-bold text-indigo-950 border-2 border-indigo-200 bg-white rounded-2xl focus:outline-none focus:border-indigo-600"
                    />
                  </div>

                  <div className="grid gap-4 grid-cols-2">
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">
                        Serving Size
                      </label>
                      <input
                        type="number"
                        required
                        min="0.1"
                        step="0.1"
                        value={customServingSize}
                        onChange={(e) => setCustomServingSize(e.target.value)}
                        className="w-full px-4 py-3 text-xs font-bold text-indigo-950 border-2 border-indigo-200 bg-white rounded-2xl focus:outline-none focus:border-indigo-600 font-mono"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">
                        Serving Unit
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. large, g, bowl"
                        value={customServingUnit}
                        onChange={(e) => setCustomServingUnit(e.target.value)}
                        className="w-full px-4 py-3 text-xs font-bold text-indigo-950 border-2 border-indigo-200 bg-white rounded-2xl focus:outline-none focus:border-indigo-600"
                      />
                    </div>
                  </div>

                  {/* Dynamic inputs for each customized nutrient */}
                  <div className="space-y-3.5 border-t border-indigo-50 pt-4">
                    <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest block">
                      Custom Nutrient Values (Per Serving)
                    </span>
                    
                    <div className="grid gap-4 grid-cols-2">
                      {customNutrients.map((cn) => (
                        <div key={cn.id} className="space-y-1">
                          <label className="text-[10px] font-black text-indigo-650 uppercase tracking-tight flex justify-between">
                            <span>{cn.name}</span>
                            <span className="font-mono text-indigo-400">({cn.unit})</span>
                          </label>
                          <input
                            type="number"
                            step="0.01"
                            value={manualNutrientValues[cn.id] || ""}
                            onChange={(e) => setManualNutrientValues({
                              ...manualNutrientValues,
                              [cn.id]: e.target.value
                            })}
                            className="w-full px-3.5 py-2 text-xs font-bold text-indigo-950 border-2 border-indigo-200 rounded-xl focus:outline-none focus:border-indigo-600 font-mono"
                            placeholder="0"
                          />
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4 border-t border-indigo-50">
                    <button
                      type="submit"
                      className="flex-1 py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-colors shadow-lg shadow-indigo-600/25"
                    >
                      Log Manual Food Item
                    </button>
                    <button
                      type="button"
                      onClick={() => setQuickAddMeal(null)}
                      className="px-6 py-4 bg-zinc-150 hover:bg-zinc-200 text-indigo-950 font-black text-xs uppercase tracking-widest rounded-2xl transition-colors"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
