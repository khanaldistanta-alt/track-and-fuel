import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Lock, Mail, User, Shield, Key, AlertCircle, CheckCircle2, ArrowRight, Sparkles, RefreshCw
} from "lucide-react";
import { UserAccount, SubscriptionTier } from "../types";
import { getUsers, saveUsers, logEmail } from "../mockDatabase";

interface AuthProps {
  onAuthSuccess: (user: UserAccount) => void;
}

export default function Auth({ onAuthSuccess }: AuthProps) {
  const [mode, setMode] = useState<"login" | "signup" | "reset">("login");
  
  // Input fields
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<"user" | "admin">("user");

  // Error/Success status overlays
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const [loading, setLoading] = useState(false);

  // Verification step (for new signup)
  const [verificationCode, setVerificationCode] = useState("");
  const [showVerificationModal, setShowVerificationModal] = useState(false);
  const [pendingUser, setPendingUser] = useState<UserAccount | null>(null);

  // Simulated Google Popup
  const [showGooglePopup, setShowGooglePopup] = useState(false);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    setSuccessMsg("");

    if (!email.trim() || !password.trim()) {
      setErrorMsg("Please complete all required parameters.");
      return;
    }

    setLoading(true);

    setTimeout(() => {
      const users = getUsers();

      if (mode === "login") {
        const foundUser = users.find(u => u.email.toLowerCase() === email.toLowerCase());
        
        if (!foundUser) {
          setErrorMsg("No account associated with this email address.");
          setLoading(false);
          return;
        }

        if (foundUser.isDisabled) {
          setErrorMsg("Your account has been administratively disabled. Contact support.");
          setLoading(false);
          return;
        }

        // Simulating matching password verification
        setLoading(false);
        onAuthSuccess(foundUser);

      } else if (mode === "signup") {
        if (!name.trim()) {
          setErrorMsg("Full Name is required to start free trial.");
          setLoading(false);
          return;
        }

        const emailExists = users.some(u => u.email.toLowerCase() === email.toLowerCase());
        if (emailExists) {
          setErrorMsg("Email address is already registered.");
          setLoading(false);
          return;
        }

        // Initialize user with active 14-day trial
        const newAccount: UserAccount = {
          id: "usr_" + Math.random().toString(36).substring(2, 9),
          email: email.toLowerCase(),
          name,
          role,
          createdAt: new Date().toISOString().split("T")[0],
          trialStart: Date.now(),
          trialEnd: Date.now() + 14 * 24 * 60 * 60 * 1000, // 14 days later
          tier: "free_trial",
          status: "trialing",
          isAutoRenew: true,
          nextBillingDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
          invoices: []
        };

        setPendingUser(newAccount);
        setLoading(false);
        setShowVerificationModal(true);

        // Simulated verify dispatch log
        logEmail(
          newAccount.email,
          "Verify your Track & Fuel account 🔑",
          `Hi ${newAccount.name},\n\nYour Track & Fuel authentication OTP security code is: 5821.\n\nPlease enter this in your dashboard application to activate your 14-day trial.`,
          "email_verification"
        );

      } else if (mode === "reset") {
        const emailFound = users.some(u => u.email.toLowerCase() === email.toLowerCase());
        setLoading(false);
        if (!emailFound) {
          setErrorMsg("No registration history exists for this address.");
          return;
        }

        setSuccessMsg("We sent secure verification credentials to your inbox!");
        logEmail(
          email,
          "Password Reset Code 🔑",
          `Hi client,\n\nWe received a password reset instruction from Track & Fuel. Click the proxy authorization link below to change your security metrics: \n\nhttps://trackandfuel.com/auth/reset?token=t_5128df`,
          "password_reset"
        );
      }
    }, 1200);
  };

  const handleVerifyOtp = () => {
    if (verificationCode !== "5821") {
      setErrorMsg("Incorrect verification code. Please enter 5821 (Check simulated emails).");
      return;
    }

    if (pendingUser) {
      const currentUsers = getUsers();
      currentUsers.push(pendingUser);
      saveUsers(currentUsers);

      // Log subscription activation emails
      logEmail(
        pendingUser.email,
        "Welcome to Track & Fuel! 🚀 [14-Day Trial Started]",
        `Hi ${pendingUser.name},\n\nWelcome to Track & Fuel!\n\nYour 14-day fully featured sandbox trial has started automatically.\n- Plan: 14-Day Free Trial\n- Renewal Price: $5.00/month after trial expiration\n- No payment method was required to activate this trialing period.\n\nHappy metabolic tracking!`,
        "trial_started"
      );

      setShowVerificationModal(false);
      onAuthSuccess(pendingUser);
    }
  };

  const handleGoogleSignInSimulate = () => {
    setShowGooglePopup(true);
    setTimeout(() => {
      // Completed auth simulation
      setShowGooglePopup(false);
      
      const emailMock = "google_user@gmail.com";
      const users = getUsers();
      let foundUser = users.find(u => u.email === emailMock);

      if (!foundUser) {
        foundUser = {
          id: "usr_google",
          email: emailMock,
          name: "Google Athlete",
          role: "user",
          createdAt: new Date().toISOString().split("T")[0],
          trialStart: Date.now(),
          trialEnd: Date.now() + 14 * 24 * 60 * 60 * 1000,
          tier: "free_trial",
          status: "trialing",
          isAutoRenew: true,
          nextBillingDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
          invoices: []
        };
        users.push(foundUser);
        saveUsers(users);

        logEmail(
          emailMock,
          "Welcome via Google Sign-In! 🚀",
          "You signed up securely using Google Single-Sign On. Your 14-day trial has activated.",
          "welcome_google"
        );
      }

      onAuthSuccess(foundUser);
    }, 2000);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4">
      <div className="w-full max-w-md rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-2xl space-y-6 relative">
        
        {/* Brand identity */}
        <div className="text-center space-y-2">
          <div className="mx-auto h-12 w-12 rounded-[18px] bg-indigo-50 text-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-600/10">
            <Shield className="h-6 w-6 stroke-[2.5px]" />
          </div>
          <h2 className="font-sans text-3xl font-black text-indigo-950 tracking-tight">
            {mode === "login" && "Athlete Sign In"}
            {mode === "signup" && "Start Free Trial"}
            {mode === "reset" && "Recover Account"}
          </h2>
          <p className="text-xs font-bold text-indigo-500">
            {mode === "login" && "Access your personalized sports nutrition cockpit"}
            {mode === "signup" && "No credit card needed to activate 14-day sandbox"}
            {mode === "reset" && "Secure biological password verification module"}
          </p>
        </div>

        {/* Action responses */}
        {errorMsg && (
          <div className="flex items-start gap-2.5 rounded-2xl bg-rose-50 border-2 border-rose-100 p-4 text-xs text-rose-800 font-bold">
            <AlertCircle className="h-4 w-4 shrink-0 text-rose-500 mt-0.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="flex items-start gap-2.5 rounded-2xl bg-emerald-50 border-2 border-emerald-100 p-4 text-xs text-emerald-800 font-bold">
            <CheckCircle2 className="h-4.5 w-4.5 shrink-0 text-emerald-500 mt-0.5" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Input fields form */}
        <form onSubmit={handleFormSubmit} className="space-y-4">
          {mode === "signup" && (
            <>
              <div>
                <label className="block text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-1.5">Your Name</label>
                <div className="relative">
                  <User className="absolute left-4 top-3.5 h-4.5 w-4.5 text-indigo-300" />
                  <input
                    type="text"
                    required
                    placeholder="Distanta Khanal"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full rounded-2xl border-4 border-indigo-50 pl-11 pr-4 py-3 text-sm font-bold text-indigo-950 outline-none focus:border-indigo-400 transition-colors"
                  />
                </div>
              </div>

              {/* simulated role setting option */}
              <div>
                <label className="block text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-1.5">Account Role Context</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as any)}
                  className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3 text-sm font-black text-indigo-950 outline-none focus:border-indigo-400 transition-colors"
                >
                  <option value="user">Standard Track Athlete (User)</option>
                  <option value="admin">Admin Dietitian Supervisor (Admin Mode)</option>
                </select>
              </div>
            </>
          )}

          <div>
            <label className="block text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-1.5">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-4 top-3.5 h-4.5 w-4.5 text-indigo-300" />
              <input
                type="email"
                required
                placeholder="khanaldistanta@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-2xl border-4 border-indigo-50 pl-11 pr-4 py-3 text-sm font-bold text-indigo-950 outline-none focus:border-indigo-400 transition-colors font-mono"
              />
            </div>
          </div>

          {mode !== "reset" && (
            <div>
              <label className="block text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-1.5">Password</label>
              <div className="relative">
                <Lock className="absolute left-4 top-3.5 h-4.5 w-4.5 text-indigo-300" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-2xl border-4 border-indigo-50 pl-11 pr-4 py-3 text-sm font-bold text-indigo-950 outline-none focus:border-indigo-400 transition-colors font-mono"
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-3xl bg-indigo-600 py-4 text-xs font-black text-white hover:bg-indigo-700 active:scale-98 transition-all shadow-xl shadow-indigo-600/25 flex items-center justify-center gap-2"
          >
            {loading ? (
              <RefreshCw className="h-4.5 w-4.5 text-white animate-spin" />
            ) : (
              <>
                {mode === "login" && "LOG IN TO DASHBOARD"}
                {mode === "signup" && "ACTIVATE 14-DAY TRIAL"}
                {mode === "reset" && "SUBMIT RECOVERY INSTRUCTIONS"}
              </>
            )}
            <ArrowRight className="h-4.5 w-4.5 text-white" />
          </button>
        </form>

        {/* Separator */}
        {mode !== "reset" && (
          <div className="relative py-2 text-center">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-indigo-100" /></div>
            <span className="relative bg-white px-3 text-[10px] font-black text-indigo-400 uppercase tracking-widest">or</span>
          </div>
        )}

        {/* Google Single-Sign-On Sim Button */}
        {mode !== "reset" && (
          <button
            onClick={handleGoogleSignInSimulate}
            className="w-full rounded-3xl border-4 border-indigo-50 hover:bg-indigo-50/50 py-3.5 text-xs font-black text-indigo-950 flex items-center justify-center gap-2.5 transition-colors"
          >
            <svg className="h-4.5 w-4.5" viewBox="0 0 24 24">
              <path fill="#EA4335" d="M12 5.04c1.64 0 3.12.56 4.28 1.67l3.2-3.2C17.52 1.58 14.96 1 12 1 7.35 1 3.4 3.65 1.56 7.56l3.8 2.94C6.28 7.37 8.92 5.04 12 5.04z" />
              <path fill="#4285F4" d="M23.52 12.27c0-.82-.07-1.61-.21-2.38H12v4.51h6.48c-.28 1.47-1.11 2.72-2.36 3.56l3.66 2.84c2.14-1.97 3.38-4.87 3.38-8.53z" />
              <path fill="#FBBC05" d="M5.36 14.6c-.24-.71-.38-1.47-.38-2.27s.14-1.56.38-2.27L1.56 7.12C.56 9.09 0 11.27 0 13.5s.56 4.41 1.56 6.38l3.8-2.94c-.24-.71-.38-1.47-.38-2.27z" />
              <path fill="#34A853" d="M12 23c3.24 0 5.96-1.07 7.94-2.91l-3.66-2.84c-1.11.75-2.53 1.2-4.28 1.2-3.08 0-5.72-2.33-6.64-5.46L1.56 15.93C3.4 19.85 7.35 23 12 23z" />
            </svg>
            CONTINUE SECURELY WITH GOOGLE
          </button>
        )}

        {/* Toggles */}
        <div className="flex flex-col items-center gap-3 pt-2 text-xs font-bold">
          {mode === "login" ? (
            <>
              <button onClick={() => { setMode("signup"); setErrorMsg(""); }} className="text-indigo-600 hover:text-indigo-900 underline">
                New user? Register and start 14-day trial
              </button>
              <button onClick={() => { setMode("reset"); setErrorMsg(""); }} className="text-indigo-400 hover:text-indigo-600">
                Forgot biological login credentials?
              </button>
            </>
          ) : mode === "signup" ? (
            <button onClick={() => { setMode("login"); setErrorMsg(""); }} className="text-indigo-600 hover:text-indigo-900 underline">
              Already registered? Connect active profile
            </button>
          ) : (
            <button onClick={() => { setMode("login"); setErrorMsg(""); }} className="text-indigo-600 hover:text-indigo-900 underline">
              Return to Profile Sign In
            </button>
          )}
        </div>

        {/* Demo Helper box */}
        <div className="bg-indigo-50/50 rounded-2xl p-4 text-center border-2 border-indigo-50 text-[11px] font-bold text-indigo-500">
          <strong>PRO TIP:</strong> Enter any registered email (e.g. <strong>admin@trackandfuel.com</strong> or your own) with any password to connect instantly.
        </div>
      </div>

      {/* Verification OTP Modal Dialog */}
      <AnimatePresence>
        {showVerificationModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-indigo-950/40 backdrop-blur-sm p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm rounded-[36px] bg-white border-4 border-indigo-100 p-8 shadow-2xl space-y-6"
            >
              <div className="text-center space-y-2">
                <div className="mx-auto h-11 w-11 rounded-[16px] bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <Key className="h-5 w-5 stroke-[2.5px]" />
                </div>
                <h3 className="font-sans text-xl font-black text-indigo-950">Verify Your Address</h3>
                <p className="text-xs text-indigo-500 font-bold leading-relaxed">
                  We dispatched a 4-digit code to your inbox log. Please type it below to activate trial.
                </p>
              </div>

              <div>
                <label className="block text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-1.5 text-center">4-Digit Security Code</label>
                <input
                  type="text"
                  maxLength={4}
                  placeholder="••••"
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, ""))}
                  className="w-full text-center tracking-[1em] rounded-2xl border-4 border-indigo-50 px-4 py-3 text-lg font-black text-indigo-950 outline-none focus:border-indigo-400 transition-colors font-mono"
                />
              </div>

              <div className="space-y-3">
                <button
                  onClick={handleVerifyOtp}
                  className="w-full rounded-2xl bg-indigo-600 py-3.5 text-xs font-black text-white hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-600/20"
                >
                  VERIFY SECURITY METRIC
                </button>
                <p className="text-[10px] text-center font-bold text-indigo-400">
                  Didn't receive code? Enter <strong>5821</strong> (which has been safely routed to your simulated mail logs).
                </p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Simulated Google Popup Window */}
      <AnimatePresence>
        {showGooglePopup && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-indigo-950/30 backdrop-blur-sm">
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              className="w-[450px] bg-white border-2 border-zinc-200 rounded-lg shadow-2xl overflow-hidden"
            >
              {/* Fake Chrome Title bar */}
              <div className="bg-zinc-100 px-4 py-2 flex items-center justify-between border-b border-zinc-200">
                <span className="text-xs font-semibold text-zinc-600 flex items-center gap-1.5">
                  <svg className="h-3 w-3" viewBox="0 0 24 24"><path fill="#4285F4" d="M23.52 12.27c0-.82-.07-1.61-.21-2.38H12v4.51h6.48c-.28 1.47-1.11 2.72-2.36 3.56l3.66 2.84c2.14-1.97 3.38-4.87 3.38-8.53z"/></svg>
                  Sign in with Google - Google Accounts
                </span>
                <div className="flex gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-zinc-300 inline-block" />
                  <span className="w-2.5 h-2.5 rounded-full bg-zinc-300 inline-block" />
                  <span className="w-2.5 h-2.5 rounded-full bg-red-400 inline-block" />
                </div>
              </div>

              {/* Popup Content */}
              <div className="p-8 space-y-6 text-center">
                <svg className="mx-auto h-10 w-10" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.85z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.85c.87-2.6 3.3-4.53 6.16-4.53z" />
                </svg>

                <div className="space-y-1">
                  <h4 className="text-md font-bold text-zinc-800">Choose Google Profile</h4>
                  <p className="text-xs text-zinc-500">to continue securely to <strong>trackandfuel.com</strong></p>
                </div>

                {/* Profile list item */}
                <div className="border border-zinc-200 rounded-lg p-3 flex items-center justify-between hover:bg-zinc-50 cursor-pointer text-left max-w-sm mx-auto shadow-sm">
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-xs">
                      DK
                    </div>
                    <div>
                      <span className="block text-xs font-bold text-zinc-800">Distanta Khanal</span>
                      <span className="block text-[10px] text-zinc-400">khanaldistanta@gmail.com</span>
                    </div>
                  </div>
                  <span className="text-[10px] bg-indigo-50 text-indigo-700 font-bold px-2 py-0.5 rounded">Connected</span>
                </div>

                <div className="flex justify-center items-center gap-2 text-xs text-indigo-600 font-bold animate-pulse">
                  <RefreshCw className="h-3 w-3 animate-spin" />
                  <span>Authorizing via secure OAuth pipeline...</span>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
