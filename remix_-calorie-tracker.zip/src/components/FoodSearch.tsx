import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Search, Sparkles, Plus, Loader2, Utensils, 
  HelpCircle, CheckCircle, Flame, CheckSquare, Square, RefreshCw, Camera, Upload, ShieldAlert, Award
} from "lucide-react";
import { FoodItem, MealType, CustomNutrient, UserAccount, UserProfile } from "../types";

interface FoodSearchProps {
  onAddLog: (item: FoodItem, quantity: number, mealType: MealType) => void;
  customNutrients: CustomNutrient[];
  currentUser: UserAccount;
  profile: UserProfile;
  onNavigateToTab: (tab: string) => void;
}

export default function FoodSearch({ onAddLog, customNutrients, currentUser, profile, onNavigateToTab }: FoodSearchProps) {
  // Tabs: 'search', 'nlp', 'scanner'
  const [activeSubTab, setActiveSubTab] = useState<"search" | "nlp" | "scanner">("search");

  // State for Food Database Search
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<FoodItem[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchSource, setSearchSource] = useState("");
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Meal mapping per search result (id -> { mealType, quantity })
  const [logConfig, setLogConfig] = useState<Record<string, { mealType: MealType; quantity: number }>>({});

  // State for Natural Language Parse
  const [nlpText, setNlpText] = useState("");
  const [parsedNlpResults, setParsedNlpResults] = useState<{ food: FoodItem; quantity: number }[]>([]);
  const [nlpSummary, setNlpSummary] = useState("");
  const [isNlpParsing, setIsNlpParsing] = useState(false);
  const [selectedNlpIndices, setSelectedNlpIndices] = useState<number[]>([]);
  const [nlpMealType, setNlpMealType] = useState<MealType>("breakfast");

  // State for AI Photo Recognition
  const [scanningImage, setScanningImage] = useState<string | null>(null);
  const [scannedFood, setScannedFood] = useState<FoodItem | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scannerMealType, setScannerMealType] = useState<MealType>("lunch");
  const [scannerQuantity, setScannerQuantity] = useState(1);
  const [scanError, setScanError] = useState<string | null>(null);

  // State for complete, detailed 21 nutrients computer vision analysis
  const [detailedScanResult, setDetailedScanResult] = useState<{
    summary: string;
    confidenceScore: number;
    detectedItems: Array<{
      name: string;
      portionSize: string;
      estimatedWeightGrams: number;
      category: string;
      isPackaged: boolean;
      isHomemade: boolean;
      confidence: number;
    }>;
    nutrients: {
      calories: number;
      protein: number;
      carbs: number;
      fat: number;
      fiber: number;
      sugar: number;
      sodium: number;
      cholesterol: number;
      saturatedFat: number;
      unsaturatedFat: number;
      potassium: number;
      calcium: number;
      iron: number;
      magnesium: number;
      zinc: number;
      vitaminA: number;
      vitaminB: number;
      vitaminC: number;
      vitaminD: number;
      vitaminE: number;
      vitaminK: number;
    };
    healthInsights: {
      verdict: string;
      whyHealthy: string;
      strengths: string[];
      weaknesses: string[];
      missingNutrients: string[];
      isBalanced: boolean;
      glycemicImpact: string;
      satietyScore: number;
      hydrationContribution: number;
      overallScore: number;
    };
    personalizedRecommendations: {
      generalAdvice: string;
      portionRecommendation: string;
      foodsToAdd: string[];
      foodsToReduce: string[];
      betterAlternatives: string[];
      healthierSubstitutions: string[];
      mealTiming: string;
      dailyNutritionGuidance: string;
      goalSpecificAdvice: string;
    };
  } | null>(null);

  // Checks user's billing tier privileges
  const isPremiumUser = currentUser.tier !== "free_trial";
  
  // Custom nutrients mapping helper
  const buildMappedNutrients = (item: FoodItem) => {
    const mapped: Record<string, number> = {};
    customNutrients.forEach(cn => {
      const lowerName = cn.name.toLowerCase();
      let val = 0;
      
      if (lowerName.includes("calorie") || lowerName === "kcal" || lowerName === "energy") {
        val = item.calories || 0;
      } else if (lowerName.includes("protein")) {
        val = item.protein || 0;
      } else if (lowerName.includes("carb")) {
        val = item.carbs || 0;
      } else if (lowerName.includes("fat") && !lowerName.includes("saturated") && !lowerName.includes("unsaturated")) {
        val = item.fat || 0;
      } else if (lowerName.includes("fiber")) {
        val = (item as any).fiber || item.nutrients?.fiber || 0;
      } else if (lowerName.includes("sugar")) {
        val = (item as any).sugar || item.nutrients?.sugar || 0;
      } else if (lowerName.includes("sodium")) {
        val = (item as any).sodium || item.nutrients?.sodium || 0;
      } else if (lowerName.includes("cholesterol")) {
        val = (item as any).cholesterol || item.nutrients?.cholesterol || 0;
      } else if (lowerName.includes("saturated")) {
        val = (item as any).saturatedFat || item.nutrients?.saturatedFat || 0;
      } else if (lowerName.includes("unsaturated")) {
        val = (item as any).unsaturatedFat || item.nutrients?.unsaturatedFat || 0;
      } else if (lowerName.includes("potassium")) {
        val = (item as any).potassium || item.nutrients?.potassium || 0;
      } else if (lowerName.includes("calcium")) {
        val = (item as any).calcium || item.nutrients?.calcium || 0;
      } else if (lowerName.includes("iron")) {
        val = (item as any).iron || item.nutrients?.iron || 0;
      } else if (lowerName.includes("magnesium")) {
        val = (item as any).magnesium || item.nutrients?.magnesium || 0;
      } else if (lowerName.includes("zinc")) {
        val = (item as any).zinc || item.nutrients?.zinc || 0;
      } else if (lowerName.includes("vitamin a")) {
        val = (item as any).vitaminA || item.nutrients?.vitaminA || 0;
      } else if (lowerName.includes("vitamin b")) {
        val = (item as any).vitaminB || item.nutrients?.vitaminB || 0;
      } else if (lowerName.includes("vitamin c")) {
        val = (item as any).vitaminC || item.nutrients?.vitaminC || 0;
      } else if (lowerName.includes("vitamin d")) {
        val = (item as any).vitaminD || item.nutrients?.vitaminD || 0;
      } else if (lowerName.includes("vitamin e")) {
        val = (item as any).vitaminE || item.nutrients?.vitaminE || 0;
      } else if (lowerName.includes("vitamin k")) {
        val = (item as any).vitaminK || item.nutrients?.vitaminK || 0;
      } else if (lowerName.includes("water")) {
        val = (item as any).water || item.nutrients?.water || 0;
      }
      mapped[cn.id] = val;
    });
    return mapped;
  };

  // Handle Food search submit
  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    try {
      const response = await fetch(`/api/food/search?q=${encodeURIComponent(searchQuery)}`);
      const data = await response.json();
      
      if (data.results) {
        setSearchResults(data.results);
        setSearchSource(data.source);
        
        // Initialize log configurations for new results
        const newConfigs: Record<string, { mealType: MealType; quantity: number }> = {};
        data.results.forEach((item: FoodItem) => {
          newConfigs[item.id] = { mealType: "breakfast", quantity: 1 };
        });
        setLogConfig(newConfigs);
      }
    } catch (error) {
      console.error("Search failed:", error);
    } finally {
      setIsSearching(false);
    }
  };

  // Handle single result log add (with dynamic custom nutrients mapping!)
  const handleAddSingleLog = (item: FoodItem) => {
    const config = logConfig[item.id] || { mealType: "breakfast", quantity: 1 };
    
    // Map existing standard macro targets into custom nutrients record!
    const mappedItem: FoodItem = {
      ...item,
      nutrients: buildMappedNutrients(item)
    };

    onAddLog(mappedItem, config.quantity, config.mealType);
    
    setSuccessMessage(`Logged ${config.quantity}x ${item.name} into your active ${config.mealType} log!`);
    setTimeout(() => setSuccessMessage(null), 3500);
  };

  const updateSingleLogConfig = (itemId: string, updates: Partial<{ mealType: MealType; quantity: number }>) => {
    setLogConfig((prev) => ({
      ...prev,
      [itemId]: {
        ...prev[itemId],
        ...updates,
      },
    }));
  };

  // Handle Natural Language Parse Submission
  const handleNlpParseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nlpText.trim()) return;

    setIsNlpParsing(true);
    try {
      const response = await fetch("/api/food/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: nlpText }),
      });
      const data = await response.json();
      
      if (data.items) {
        // Map all standard parsed items to their custom nutrient guides
        const mappedItems = data.items.map((itemObj: any) => ({
          ...itemObj,
          food: {
            ...itemObj.food,
            nutrients: buildMappedNutrients(itemObj.food)
          }
        }));
        
        setParsedNlpResults(mappedItems);
        setNlpSummary(data.summary);
        setSelectedNlpIndices(mappedItems.map((_: any, idx: number) => idx));
      }
    } catch (error) {
      console.error("NLP Parse failed:", error);
    } finally {
      setIsNlpParsing(false);
    }
  };

  const toggleNlpSelection = (index: number) => {
    setSelectedNlpIndices((prev) =>
      prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
    );
  };

  const handleLogSelectedNlpItems = () => {
    if (parsedNlpResults.length === 0 || selectedNlpIndices.length === 0) return;

    selectedNlpIndices.forEach((index) => {
      const entry = parsedNlpResults[index];
      onAddLog(entry.food, entry.quantity, nlpMealType);
    });

    setSuccessMessage(`Logged ${selectedNlpIndices.length} NLP items to ${nlpMealType}!`);
    setTimeout(() => setSuccessMessage(null), 3000);

    setParsedNlpResults([]);
    setNlpText("");
    setNlpSummary("");
  };

  // Preset photos dishes for camera recognition simulations
  const scanSamples = [
    {
      name: "Avocado Toast with Egg",
      image: "https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&q=80&w=400",
      food: {
        id: "scan_1",
        name: "Avocado Toast with Poached Egg",
        calories: 380,
        protein: 14,
        carbs: 28,
        fat: 22,
        servingSize: 1,
        servingUnit: "plate",
        isGeminiVerified: true
      }
    },
    {
      name: "Ribeye Steak & Broccoli",
      image: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=400",
      food: {
        id: "scan_2",
        name: "Ribeye Steak with Roasted Broccoli",
        calories: 680,
        protein: 48,
        carbs: 12,
        fat: 45,
        servingSize: 1,
        servingUnit: "portion",
        isGeminiVerified: true
      }
    },
    {
      name: "Greek Yogurt Bowl",
      image: "https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&q=80&w=400",
      food: {
        id: "scan_3",
        name: "Greek Yogurt Bowl with Berries and Honey",
        calories: 240,
        protein: 18,
        carbs: 26,
        fat: 4,
        servingSize: 1,
        servingUnit: "bowl",
        isGeminiVerified: true
      }
    }
  ];

  const handleStartScan = async (imageSrc: string) => {
    setScanningImage(imageSrc);
    setIsScanning(true);
    setScannedFood(null);
    setDetailedScanResult(null);
    setScanError(null);

    try {
      const response = await fetch("/api/food/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image: imageSrc, profile })
      });

      if (!response.ok) {
        throw new Error("Vision server returned error response.");
      }

      const data = await response.json();
      setDetailedScanResult(data);

      // Create a compatible main FoodItem from the scan
      const mainFoodItem: FoodItem = {
        id: `scan_${Date.now()}`,
        name: data.detectedItems?.[0]?.name || "Scanned Meal",
        calories: data.nutrients?.calories || 0,
        protein: data.nutrients?.protein || 0,
        carbs: data.nutrients?.carbs || 0,
        fat: data.nutrients?.fat || 0,
        servingSize: 1,
        servingUnit: "portion",
        isGeminiVerified: true,
        // Carry the rest of the 21 nutrients on the food item so they can be logged!
        fiber: data.nutrients?.fiber || 0,
        sugar: data.nutrients?.sugar || 0,
        sodium: data.nutrients?.sodium || 0,
        cholesterol: data.nutrients?.cholesterol || 0,
        saturatedFat: data.nutrients?.saturatedFat || 0,
        unsaturatedFat: data.nutrients?.unsaturatedFat || 0,
        potassium: data.nutrients?.potassium || 0,
        calcium: data.nutrients?.calcium || 0,
        iron: data.nutrients?.iron || 0,
        magnesium: data.nutrients?.magnesium || 0,
        zinc: data.nutrients?.zinc || 0,
        vitaminA: data.nutrients?.vitaminA || 0,
        vitaminB: data.nutrients?.vitaminB || 0,
        vitaminC: data.nutrients?.vitaminC || 0,
        vitaminD: data.nutrients?.vitaminD || 0,
        vitaminE: data.nutrients?.vitaminE || 0,
        vitaminK: data.nutrients?.vitaminK || 0,
      } as any;

      setScannedFood(mainFoodItem);
    } catch (err: any) {
      console.error("Scanning failed:", err);
      setScanError(err.message || "An unexpected error occurred during visual plate analysis.");
    } finally {
      setIsScanning(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      alert("File size exceeds 10MB limit.");
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64Url = reader.result as string;
      handleStartScan(base64Url);
    };
    reader.readAsDataURL(file);
  };

  const handleLogScannedFood = () => {
    if (!scannedFood) return;

    // Map scanned items to dynamic custom goals
    const mappedFood: FoodItem = {
      ...scannedFood,
      nutrients: buildMappedNutrients(scannedFood)
    };

    onAddLog(mappedFood, scannerQuantity, scannerMealType);

    setSuccessMessage(`Successfully logged ${scannerQuantity}x ${scannedFood.name} via AI Scanner!`);
    setTimeout(() => setSuccessMessage(null), 3000);

    setScannedFood(null);
    setScanningImage(null);
    setDetailedScanResult(null);
  };

  return (
    <div className="space-y-10 pb-16">
      {/* Page Header */}
      <div>
        <h2 className="font-sans text-5xl font-black text-indigo-950 tracking-tight">
          Food Logging Center
        </h2>
        <p className="mt-2 text-lg text-indigo-600 font-bold opacity-80">
          Query our high-fidelity intelligent database or leverage premium AI processing to scan or parse meals.
        </p>
      </div>

      {/* Sub tabs switcher */}
      <div className="flex border-b-4 border-indigo-100 gap-1.5 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveSubTab("search")}
          className={`flex items-center gap-2 border-b-4 -mb-[4px] px-6 py-4 text-xs font-black uppercase tracking-wider transition-all rounded-t-3xl shrink-0 ${
            activeSubTab === "search"
              ? "border-indigo-600 text-indigo-950 bg-indigo-50/50"
              : "border-transparent text-indigo-500 hover:text-indigo-950 hover:bg-indigo-50/20"
          }`}
        >
          <Search className="h-4 w-4 text-indigo-600" />
          Intelligent Database Search
        </button>
        <button
          onClick={() => setActiveSubTab("nlp")}
          className={`flex items-center gap-2 border-b-4 -mb-[4px] px-6 py-4 text-xs font-black uppercase tracking-wider transition-all rounded-t-3xl shrink-0 ${
            activeSubTab === "nlp"
              ? "border-indigo-600 text-indigo-950 bg-indigo-50/50"
              : "border-transparent text-indigo-500 hover:text-indigo-950 hover:bg-indigo-50/20"
          }`}
        >
          <Sparkles className="h-4 w-4 text-indigo-600" />
          AI NLP Freeform Parse
        </button>
        <button
          onClick={() => setActiveSubTab("scanner")}
          className={`flex items-center gap-2 border-b-4 -mb-[4px] px-6 py-4 text-xs font-black uppercase tracking-wider transition-all rounded-t-3xl shrink-0 ${
            activeSubTab === "scanner"
              ? "border-indigo-600 text-indigo-950 bg-indigo-50/50"
              : "border-transparent text-indigo-500 hover:text-indigo-950 hover:bg-indigo-50/20"
          }`}
        >
          <Camera className="h-4 w-4 text-indigo-600 animate-bounce" />
          AI Photo Food Scanner
        </button>
      </div>

      {/* Toast Message Notification */}
      <AnimatePresence>
        {successMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex items-center gap-3.5 rounded-[24px] bg-emerald-50 border-4 border-emerald-100 px-6 py-4 text-sm text-emerald-950 font-black shadow-xl"
          >
            <CheckCircle className="h-6 w-6 text-emerald-500 shrink-0" />
            <span>{successMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Search Database Tab */}
      {activeSubTab === "search" && (
        <div className="space-y-8">
          {/* Integrated Badge */}
          <div className="flex items-center justify-between rounded-[24px] border-4 border-indigo-100 bg-white px-6 py-4 text-xs font-black text-indigo-950 shadow-sm">
            <span className="flex items-center gap-2.5">
              <span className="h-3 w-3 rounded-full bg-indigo-600 inline-block animate-pulse" />
              <span>Food Database Integration: <strong className="text-indigo-600 font-black">Edamam & Nutritionix Proxy</strong></span>
            </span>
            <span className="text-indigo-400 font-bold hidden sm:inline">Active, server-side verified</span>
          </div>

          {/* Search bar form */}
          <form onSubmit={handleSearchSubmit} className="bg-white rounded-[40px] p-4 flex items-center gap-4 shadow-xl border-4 border-indigo-100 focus-within:border-indigo-400 transition-colors">
            <div className="relative flex-1 flex items-center">
              <Search className="h-6 w-6 text-indigo-300 ml-2" />
              <input
                type="text"
                placeholder="Query database... (e.g. 'Greek salad', '150g steak')"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent border-none outline-none text-xl font-bold text-indigo-950 placeholder:text-indigo-200 ml-3"
              />
            </div>
            <button
              type="submit"
              disabled={isSearching}
              className="bg-indigo-600 text-white px-8 py-4 rounded-3xl font-black shadow-lg hover:bg-indigo-700 active:scale-95 transition-all flex items-center gap-2"
            >
              {isSearching ? <Loader2 className="h-5 w-5 animate-spin text-white" /> : "SEARCH DB"}
            </button>
          </form>

          {/* Search results rendering */}
          {isSearching && (
            <div className="flex flex-col items-center justify-center py-24">
              <Loader2 className="h-12 w-12 text-indigo-600 animate-spin" />
              <p className="mt-4 text-base font-black text-indigo-950">Consulting Nutrition Database...</p>
            </div>
          )}

          {!isSearching && searchResults.length > 0 && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-widest text-indigo-400">
                  Search Results ({searchResults.length})
                </h3>
                {searchSource && (
                  <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full uppercase tracking-wider">
                    Source: {searchSource.replace(/_/g, " ")}
                  </span>
                )}
              </div>

              <div className="grid gap-6 sm:grid-cols-2">
                {searchResults.map((item) => {
                  const config = logConfig[item.id] || { mealType: "breakfast", quantity: 1 };
                  return (
                    <div
                      key={item.id}
                      className="rounded-[32px] border-4 border-indigo-50 bg-white p-6 shadow-xl hover:shadow-2xl hover:border-indigo-100 transition-all flex flex-col justify-between"
                    >
                      <div className="space-y-3.5">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <h4 className="font-sans text-md font-black text-indigo-950 truncate leading-snug">{item.name}</h4>
                            <p className="text-xs text-indigo-400 font-bold mt-1">Serving: {item.servingSize} {item.servingUnit}</p>
                          </div>
                          {item.isGeminiVerified && (
                            <span className="shrink-0 rounded-full bg-indigo-100 text-indigo-700 text-[9px] font-black uppercase tracking-widest px-2 py-0.5">
                              ✓ Verified
                            </span>
                          )}
                        </div>

                        {/* Standard macros display (can map to their active goals) */}
                        <div className="bg-indigo-50/40 rounded-2xl p-3 border-2 border-indigo-50 flex items-center justify-between gap-1 text-[11px] font-bold text-indigo-950">
                          <span className="text-indigo-900"><Flame className="h-3.5 w-3.5 text-orange-500 inline mr-1" /> {item.calories} kcal</span>
                          <span>•</span>
                          <span className="text-orange-700">P: {item.protein}g</span>
                          <span>•</span>
                          <span className="text-blue-600">C: {item.carbs}g</span>
                          <span>•</span>
                          <span className="text-green-600">F: {item.fat}g</span>
                        </div>
                      </div>

                      {/* Log config and trigger */}
                      <div className="mt-5 border-t border-indigo-50 pt-4 flex flex-col sm:flex-row gap-2.5 items-center justify-between">
                        <div className="flex items-center gap-1.5 w-full sm:w-auto">
                          <input
                            type="number"
                            min="0.5"
                            step="0.5"
                            value={config.quantity}
                            onChange={(e) => updateSingleLogConfig(item.id, { quantity: Number(e.target.value) || 1 })}
                            className="w-14 rounded-xl border-2 border-indigo-100 p-2 text-xs font-black font-mono text-center text-indigo-950 focus:outline-none focus:border-indigo-500"
                          />
                          <select
                            value={config.mealType}
                            onChange={(e) => updateSingleLogConfig(item.id, { mealType: e.target.value as MealType })}
                            className="flex-1 sm:flex-none rounded-xl border-2 border-indigo-100 p-2 text-xs font-black text-indigo-950 focus:outline-none"
                          >
                            <option value="breakfast">Breakfast</option>
                            <option value="lunch">Lunch</option>
                            <option value="dinner">Dinner</option>
                            <option value="snack">Snacking</option>
                          </select>
                        </div>
                        <button
                          onClick={() => handleAddSingleLog(item)}
                          className="w-full sm:w-auto px-5 py-2.5 bg-indigo-650 hover:bg-indigo-700 text-white font-black text-xs uppercase tracking-widest rounded-xl transition-colors flex items-center justify-center gap-1.5 active:scale-95 shadow-md shadow-indigo-600/10"
                        >
                          <Plus className="h-4 w-4 stroke-[3px]" />
                          Add Food
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* AI Freeform Natural Language Tab */}
      {activeSubTab === "nlp" && (
        <div className="space-y-8">
          {!isPremiumUser ? (
            /* Subscription block gate */
            <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-8 text-center max-w-2xl mx-auto space-y-6 shadow-2xl">
              <div className="h-16 w-16 bg-indigo-50 text-indigo-650 flex items-center justify-center rounded-2xl mx-auto border-2 border-indigo-100">
                <ShieldAlert className="h-8 w-8 text-indigo-650" />
              </div>
              <div className="space-y-2">
                <h3 className="font-sans text-2xl font-black text-indigo-950 uppercase tracking-tight">
                  Premium AI Feature Locked
                </h3>
                <p className="text-sm text-indigo-600 font-bold max-w-md mx-auto leading-relaxed">
                  Your Free Plan includes manual food logging, database searching, and custom goals trackers. Upgrading to a Paid subscription tier is required to unlock natural language processing.
                </p>
              </div>
              <button
                onClick={() => onNavigateToTab("pricing")}
                className="px-6 py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl shadow-lg shadow-indigo-600/20 transition-all active:scale-95"
              >
                View Premium Pricing Tiers 👑
              </button>
            </div>
          ) : (
            /* Active NLP UI */
            <div className="grid gap-8 lg:grid-cols-5">
              <div className="lg:col-span-3 rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-2xl space-y-6">
                <div>
                  <h3 className="font-sans text-lg font-black text-indigo-950 uppercase flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-indigo-600" />
                    Record Whole Meals In Plain English
                  </h3>
                  <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest mt-1">
                    Gemini parses food names, counts weights, and computes standard ratios
                  </p>
                </div>

                <form onSubmit={handleNlpParseSubmit} className="space-y-4">
                  <textarea
                    required
                    placeholder="Describe what you ate today... e.g., 'I had a cup of oatmeal with raw almond butter and half a sliced banana, plus an espresso and 150g egg whites'"
                    value={nlpText}
                    onChange={(e) => setNlpText(e.target.value)}
                    rows={4}
                    className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3.5 text-sm font-bold text-indigo-950 placeholder:text-indigo-250 outline-none focus:border-indigo-300 transition-colors bg-indigo-50/10"
                  />

                  <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="flex items-center gap-1.5 w-full sm:w-auto">
                      <span className="text-xs font-black text-indigo-400 uppercase tracking-wider">Log to:</span>
                      <select
                        value={nlpMealType}
                        onChange={(e) => setNlpMealType(e.target.value as MealType)}
                        className="rounded-xl border-2 border-indigo-100 p-2 text-xs font-black text-indigo-950 focus:outline-none"
                      >
                        <option value="breakfast">Breakfast</option>
                        <option value="lunch">Lunch</option>
                        <option value="dinner">Dinner</option>
                        <option value="snack">Snacking</option>
                      </select>
                    </div>

                    <button
                      type="submit"
                      disabled={isNlpParsing}
                      className="w-full sm:w-auto px-6 py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-colors shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-1.5"
                    >
                      {isNlpParsing ? (
                        <>
                          <Loader2 className="h-4.5 w-4.5 animate-spin" />
                          <span>Parsing Food...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="h-4.5 w-4.5" />
                          <span>PARSE MEAL WITH GEMINI</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>

              {/* Parsed NLP Results list card */}
              <div className="lg:col-span-2 rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-2xl flex flex-col justify-between min-h-[300px]">
                {parsedNlpResults.length > 0 ? (
                  <div className="space-y-6 flex-1 flex flex-col justify-between">
                    <div className="space-y-4">
                      <div className="border-b-2 border-indigo-50 pb-3">
                        <h4 className="text-xs font-black text-indigo-400 uppercase tracking-widest">
                          Parsed Food Constituents
                        </h4>
                        {nlpSummary && (
                          <p className="text-[10px] text-indigo-500 font-bold mt-1 italic">
                            "{nlpSummary}"
                          </p>
                        )}
                      </div>

                      <div className="space-y-2 max-h-[180px] overflow-y-auto pr-1">
                        {parsedNlpResults.map((item, idx) => {
                          const isSelected = selectedNlpIndices.includes(idx);
                          return (
                            <div
                              key={idx}
                              onClick={() => toggleNlpSelection(idx)}
                              className={`rounded-xl p-3 border-2 cursor-pointer transition-all flex items-center justify-between gap-3 ${
                                isSelected
                                  ? "border-indigo-600 bg-indigo-50/30"
                                  : "border-indigo-50 bg-white opacity-60"
                              }`}
                            >
                              <div className="min-w-0">
                                <h5 className="text-xs font-black text-indigo-950 truncate leading-none">
                                  {item.food.name}
                                </h5>
                                <p className="text-[10px] font-bold text-indigo-400 mt-1.5">
                                  {item.quantity} portions • {item.food.calories} kcal
                                </p>
                              </div>
                              <div className="shrink-0 text-indigo-600">
                                {isSelected ? (
                                  <CheckSquare className="h-4.5 w-4.5 stroke-[3px]" />
                                ) : (
                                  <Square className="h-4.5 w-4.5" />
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    <button
                      onClick={handleLogSelectedNlpItems}
                      className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-all shadow-md shadow-indigo-600/20 mt-4"
                    >
                      LOG {selectedNlpIndices.length} SELECTED TO {nlpMealType.toUpperCase()}
                    </button>
                  </div>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center py-8 text-center">
                    <Utensils className="h-10 w-10 text-indigo-200 mx-auto" />
                    <p className="mt-3 text-sm font-black text-indigo-950">No parsed food segments loaded.</p>
                    <p className="text-xs text-indigo-400 mt-1">Describe your meal in the text box and press parse.</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* AI Photo Scanner Tab */}
      {activeSubTab === "scanner" && (
        <div className="space-y-8">
          {!isPremiumUser ? (
            /* Locked Gate */
            <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-8 text-center max-w-2xl mx-auto space-y-6 shadow-2xl">
              <div className="h-16 w-16 bg-indigo-50 text-indigo-650 flex items-center justify-center rounded-2xl mx-auto border-2 border-indigo-100">
                <Camera className="h-8 w-8 text-indigo-650" />
              </div>
              <div className="space-y-2">
                <h3 className="font-sans text-2xl font-black text-indigo-950 uppercase tracking-tight">
                  AI Food Scanning Gated
                </h3>
                <p className="text-sm text-indigo-600 font-bold max-w-md mx-auto leading-relaxed">
                  Avoid manual calorie calculations altogether by logging meals from visual photos. Available on all premium plans (Basic, Pro, Expert).
                </p>
              </div>
              <button
                onClick={() => onNavigateToTab("pricing")}
                className="px-6 py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl shadow-lg shadow-indigo-600/20 transition-all"
              >
                Unlock AI Visual Scanner 👑
              </button>
            </div>
          ) : detailedScanResult ? (
            /* ================= SCAN RESULTS SCREEN ================= */
            <div className="space-y-8">
              {/* Top Action Bar */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-indigo-100 pb-4">
                <div>
                  <span className="text-xs font-black text-indigo-600 uppercase tracking-widest bg-indigo-50 px-3 py-1 rounded-full">
                    ✓ Multi-Item Visual Prediction Complete
                  </span>
                  <h3 className="text-2xl font-black text-indigo-950 mt-1">
                    Meal Diagnostic Report
                  </h3>
                </div>
                <button
                  onClick={() => {
                    setDetailedScanResult(null);
                    setScannedFood(null);
                    setScanningImage(null);
                    setScanError(null);
                  }}
                  className="px-5 py-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-950 text-xs font-black uppercase tracking-wider rounded-xl transition-colors flex items-center gap-2 border-2 border-indigo-100"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  Scan Another Plate
                </button>
              </div>

              <div className="grid gap-8 lg:grid-cols-12">
                {/* Left Side: Photo, Detected Items, Controls (lg:col-span-5) */}
                <div className="lg:col-span-5 space-y-6">
                  {/* Food Image Card */}
                  <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-4 shadow-xl overflow-hidden relative group">
                    <div className="relative h-64 w-full rounded-[32px] overflow-hidden bg-indigo-50">
                      {scanningImage ? (
                        <img
                          src={scanningImage}
                          alt="Scanned Plate"
                          referrerPolicy="no-referrer"
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="h-full w-full flex items-center justify-center text-indigo-200">
                          <Camera className="h-16 w-16" />
                        </div>
                      )}
                      
                      {/* Floating Calorie / Confidence Card */}
                      <div className="absolute top-4 right-4 bg-indigo-950/90 backdrop-blur-md text-white px-4 py-2 rounded-2xl shadow-xl flex items-center gap-1.5 border border-indigo-500/20">
                        <Flame className="h-4.5 w-4.5 text-orange-400 fill-orange-400" />
                        <span className="text-sm font-black font-mono">
                          {Math.round((detailedScanResult.nutrients?.calories || 0) * scannerQuantity)} kcal
                        </span>
                      </div>

                      <div className="absolute bottom-4 left-4 bg-emerald-500/90 backdrop-blur-md text-white px-3.5 py-1.5 rounded-xl shadow-xl text-[10px] font-black uppercase tracking-wider">
                        {detailedScanResult.confidenceScore}% Vision Match
                      </div>
                    </div>
                  </div>

                  {/* Multi-Item Detection Breakdown */}
                  <div className="rounded-[36px] border-4 border-indigo-100 bg-white p-6 shadow-xl space-y-4">
                    <h4 className="text-xs font-black uppercase tracking-widest text-indigo-400">
                      Detected Constituents ({detailedScanResult.detectedItems?.length || 0})
                    </h4>
                    <div className="space-y-3">
                      {detailedScanResult.detectedItems?.map((item, idx) => (
                        <div
                          key={idx}
                          className="rounded-2xl border-2 border-indigo-50 p-4 flex items-center justify-between gap-4 bg-indigo-50/10 hover:border-indigo-100 transition-colors"
                        >
                          <div className="min-w-0">
                            <p className="text-sm font-black text-indigo-950 truncate">{item.name}</p>
                            <p className="text-[10px] text-indigo-400 font-bold mt-1">
                              {item.portionSize} • {item.estimatedWeightGrams}g • <span className="capitalize">{item.category.replace(/_/g, " ")}</span>
                            </p>
                          </div>
                          <div className="text-right">
                            <span className="text-[10px] font-black text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-lg">
                              {Math.round(item.confidence * 100)}% Match
                            </span>
                            <div className="flex gap-1.5 mt-2 justify-end">
                              {item.isPackaged && (
                                <span className="text-[8px] font-black text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded uppercase">Packaged</span>
                              )}
                              {item.isHomemade && (
                                <span className="text-[8px] font-black text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded uppercase">Homemade</span>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Log Logging Config & Action Button */}
                  <div className="rounded-[36px] border-4 border-indigo-100 bg-indigo-50/30 p-6 shadow-xl space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Portion Multiplier:</label>
                        <input
                          type="number"
                          min="0.5"
                          step="0.5"
                          value={scannerQuantity}
                          onChange={(e) => setScannerQuantity(Number(e.target.value) || 1)}
                          className="w-full rounded-2xl border-2 border-indigo-100 p-3 text-sm font-black font-mono text-center text-indigo-950 focus:outline-none focus:border-indigo-500 bg-white"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Meal Category:</label>
                        <select
                          value={scannerMealType}
                          onChange={(e) => setScannerMealType(e.target.value as MealType)}
                          className="w-full rounded-2xl border-2 border-indigo-100 p-3 text-sm font-black text-indigo-950 focus:outline-none bg-white"
                        >
                          <option value="breakfast">Breakfast</option>
                          <option value="lunch">Lunch</option>
                          <option value="dinner">Dinner</option>
                          <option value="snack">Snacking</option>
                        </select>
                      </div>
                    </div>

                    <button
                      onClick={handleLogScannedFood}
                      className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-all shadow-lg shadow-indigo-600/35 flex items-center justify-center gap-2 active:scale-95"
                    >
                      <Plus className="h-5 w-5 stroke-[3px]" />
                      LOG DISH TO FOOD DIARY
                    </button>
                  </div>
                </div>

                {/* Right Side: Health Insights, 21 Nutrients, and AI Recommendations (lg:col-span-7) */}
                <div className="lg:col-span-7 space-y-8">
                  {/* Health Score & Verdict Bento */}
                  <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-xl grid md:grid-cols-12 gap-6 items-center">
                    <div className="md:col-span-4 flex justify-center">
                      <div className="relative flex items-center justify-center h-28 w-28 shrink-0">
                        <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                          <circle
                            cx="50"
                            cy="50"
                            r="40"
                            stroke="#EEF2F6"
                            strokeWidth="10"
                            fill="transparent"
                          />
                          <circle
                            cx="50"
                            cy="50"
                            r="40"
                            stroke={
                              detailedScanResult.healthInsights.overallScore >= 80 ? "#10B981" : 
                              detailedScanResult.healthInsights.overallScore >= 50 ? "#F59E0B" : "#EF4444"
                            }
                            strokeWidth="10"
                            fill="transparent"
                            strokeDasharray={251.2}
                            strokeDashoffset={251.2 - (251.2 * detailedScanResult.healthInsights.overallScore) / 100}
                            strokeLinecap="round"
                            className="transition-all duration-1000 ease-out"
                          />
                        </svg>
                        <div className="absolute flex flex-col items-center justify-center">
                          <span className="text-3xl font-black text-indigo-950">{detailedScanResult.healthInsights.overallScore}</span>
                          <span className="text-[9px] font-black uppercase text-indigo-400">Score</span>
                        </div>
                      </div>
                    </div>

                    <div className="md:col-span-8 space-y-3.5">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`px-3.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                          detailedScanResult.healthInsights.verdict.includes("unhealthy") 
                            ? "bg-rose-50 text-rose-700 border-2 border-rose-100" 
                            : "bg-emerald-50 text-emerald-700 border-2 border-emerald-100"
                        }`}>
                          Verdict: {detailedScanResult.healthInsights.verdict.replace(/_/g, " ")}
                        </span>
                        
                        <span className={`px-3.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                          detailedScanResult.healthInsights.glycemicImpact === "high" 
                            ? "bg-rose-50 text-rose-700" 
                            : detailedScanResult.healthInsights.glycemicImpact === "medium"
                              ? "bg-amber-50 text-amber-700"
                              : "bg-emerald-50 text-emerald-700"
                        }`}>
                          Glycemic: {detailedScanResult.healthInsights.glycemicImpact}
                        </span>
                      </div>

                      <p className="text-sm font-bold text-indigo-950 leading-relaxed">
                        {detailedScanResult.healthInsights.whyHealthy}
                      </p>

                      <div className="grid grid-cols-2 gap-4 border-t border-indigo-50 pt-3 text-xs font-black text-indigo-950">
                        <div>
                          <span className="text-indigo-400 font-bold block text-[9px] uppercase tracking-wider">Satiety Score:</span>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="flex-1 bg-indigo-50 h-2.5 rounded-full overflow-hidden">
                              <div className="bg-indigo-600 h-full" style={{ width: `${detailedScanResult.healthInsights.satietyScore}%` }} />
                            </div>
                            <span className="font-mono">{detailedScanResult.healthInsights.satietyScore}%</span>
                          </div>
                        </div>

                        <div>
                          <span className="text-indigo-400 font-bold block text-[9px] uppercase tracking-wider">Hydration Contribution:</span>
                          <span className="text-indigo-600 block mt-1">{detailedScanResult.healthInsights.hydrationContribution} mL water</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Detailed Strengths / Weaknesses Bento */}
                  <div className="grid gap-6 sm:grid-cols-2">
                    <div className="rounded-[32px] border-4 border-emerald-100 bg-white p-6 shadow-md space-y-3">
                      <h5 className="text-xs font-black text-emerald-800 uppercase tracking-wider flex items-center gap-1.5">
                        <CheckCircle className="h-4.5 w-4.5 text-emerald-500 shrink-0" />
                        Nutritional Strengths
                      </h5>
                      <ul className="space-y-2 text-xs text-indigo-950 font-bold leading-relaxed list-disc list-inside">
                        {detailedScanResult.healthInsights.strengths?.map((str, i) => (
                          <li key={i}>{str}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="rounded-[32px] border-4 border-rose-100 bg-white p-6 shadow-md space-y-3">
                      <h5 className="text-xs font-black text-rose-800 uppercase tracking-wider flex items-center gap-1.5">
                        <HelpCircle className="h-4.5 w-4.5 text-rose-500 shrink-0" />
                        Nutritional Warnings
                      </h5>
                      <ul className="space-y-2 text-xs text-indigo-950 font-bold leading-relaxed list-disc list-inside">
                        {detailedScanResult.healthInsights.weaknesses?.map((wk, i) => (
                          <li key={i}>{wk}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* 21 Complete Nutrient Breakdown Section */}
                  <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-xl space-y-6">
                    <div>
                      <h4 className="text-sm font-black uppercase tracking-widest text-indigo-950">
                        Complete Nutrient Breakdown
                      </h4>
                      <p className="text-[10px] text-indigo-400 font-bold mt-1 uppercase">
                        All 21 visual-estimated micro and macro diet elements
                      </p>
                    </div>

                    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 max-h-[360px] overflow-y-auto pr-2">
                      {[
                        { label: "Calories", value: detailedScanResult.nutrients.calories, unit: "kcal", color: "bg-orange-500", rawVal: detailedScanResult.nutrients.calories },
                        { label: "Protein", value: detailedScanResult.nutrients.protein, unit: "g", color: "bg-red-500", rawVal: detailedScanResult.nutrients.protein },
                        { label: "Carbs", value: detailedScanResult.nutrients.carbs, unit: "g", color: "bg-blue-500", rawVal: detailedScanResult.nutrients.carbs },
                        { label: "Total Fat", value: detailedScanResult.nutrients.fat, unit: "g", color: "bg-green-500", rawVal: detailedScanResult.nutrients.fat },
                        { label: "Fiber", value: detailedScanResult.nutrients.fiber, unit: "g", color: "bg-indigo-500", rawVal: detailedScanResult.nutrients.fiber },
                        { label: "Sugar", value: detailedScanResult.nutrients.sugar, unit: "g", color: "bg-pink-500", rawVal: detailedScanResult.nutrients.sugar },
                        { label: "Saturated Fat", value: detailedScanResult.nutrients.saturatedFat, unit: "g", color: "bg-amber-600", rawVal: detailedScanResult.nutrients.saturatedFat },
                        { label: "Unsaturated Fat", value: detailedScanResult.nutrients.unsaturatedFat, unit: "g", color: "bg-emerald-500", rawVal: detailedScanResult.nutrients.unsaturatedFat },
                        { label: "Sodium", value: detailedScanResult.nutrients.sodium, unit: "mg", color: "bg-slate-400", rawVal: detailedScanResult.nutrients.sodium },
                        { label: "Cholesterol", value: detailedScanResult.nutrients.cholesterol, unit: "mg", color: "bg-rose-400", rawVal: detailedScanResult.nutrients.cholesterol },
                        { label: "Potassium", value: detailedScanResult.nutrients.potassium, unit: "mg", color: "bg-violet-400", rawVal: detailedScanResult.nutrients.potassium },
                        { label: "Calcium", value: detailedScanResult.nutrients.calcium, unit: "mg", color: "bg-cyan-400", rawVal: detailedScanResult.nutrients.calcium },
                        { label: "Iron", value: detailedScanResult.nutrients.iron, unit: "mg", color: "bg-teal-400", rawVal: detailedScanResult.nutrients.iron },
                        { label: "Magnesium", value: detailedScanResult.nutrients.magnesium, unit: "mg", color: "bg-yellow-500", rawVal: detailedScanResult.nutrients.magnesium },
                        { label: "Zinc", value: detailedScanResult.nutrients.zinc, unit: "mg", color: "bg-orange-400", rawVal: detailedScanResult.nutrients.zinc },
                        { label: "Vitamin A", value: detailedScanResult.nutrients.vitaminA, unit: "mcg", color: "bg-red-400", rawVal: detailedScanResult.nutrients.vitaminA },
                        { label: "Vitamin B Complex", value: detailedScanResult.nutrients.vitaminB, unit: "mg", color: "bg-orange-350", rawVal: detailedScanResult.nutrients.vitaminB },
                        { label: "Vitamin C", value: detailedScanResult.nutrients.vitaminC, unit: "mg", color: "bg-yellow-400", rawVal: detailedScanResult.nutrients.vitaminC },
                        { label: "Vitamin D", value: detailedScanResult.nutrients.vitaminD, unit: "mcg", color: "bg-amber-400", rawVal: detailedScanResult.nutrients.vitaminD },
                        { label: "Vitamin E", value: detailedScanResult.nutrients.vitaminE, unit: "mg", color: "bg-green-400", rawVal: detailedScanResult.nutrients.vitaminE },
                        { label: "Vitamin K", value: detailedScanResult.nutrients.vitaminK, unit: "mcg", color: "bg-teal-300", rawVal: detailedScanResult.nutrients.vitaminK },
                      ].map((nut, i) => (
                        <div key={i} className="rounded-xl border border-indigo-50 p-3 bg-indigo-50/10 flex flex-col justify-between">
                          <span className="text-[10px] font-black text-indigo-400 uppercase tracking-wider">{nut.label}</span>
                          <div className="flex items-baseline gap-1 mt-2">
                            <span className="text-base font-black text-indigo-950">
                              {Math.round(nut.rawVal * scannerQuantity * 10) / 10}
                            </span>
                            <span className="text-[9px] font-black text-indigo-400">{nut.unit}</span>
                          </div>
                        </div>
                      ))}
                    </div>

                    {detailedScanResult.healthInsights.missingNutrients?.length > 0 && (
                      <div className="bg-indigo-50/50 p-4 rounded-2xl border border-indigo-50 text-xs">
                        <span className="font-black text-indigo-950 block mb-1">Missing Elements Warning:</span>
                        <p className="text-indigo-600 font-bold leading-relaxed">
                          This plate lacks significant amounts of: <span className="text-indigo-950 font-black">{detailedScanResult.healthInsights.missingNutrients.join(", ")}</span>.
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Personalized AI Recommendations Section */}
                  <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-xl space-y-6">
                    <div>
                      <h4 className="text-sm font-black uppercase tracking-widest text-indigo-950">
                        Personalized AI Recommendations
                      </h4>
                      <p className="text-[10px] text-indigo-400 font-bold mt-1 uppercase">
                        Dietitian tailored for user aged {profile.age} ({profile.weightGoal ? `Target: ${profile.weightGoal}kg` : "Dynamic Goals"})
                      </p>
                    </div>

                    <div className="space-y-4 text-xs font-bold leading-relaxed text-indigo-950">
                      {/* General Guidance */}
                      <div className="bg-indigo-50/20 p-4 rounded-2xl border-2 border-indigo-50 space-y-1">
                        <span className="text-[9px] font-black uppercase text-indigo-400 block tracking-widest">General Dietitian Advice:</span>
                        <p className="text-indigo-950">{detailedScanResult.personalizedRecommendations.generalAdvice}</p>
                      </div>

                      {/* Portion & Deficit/Surplus advice */}
                      <div className="bg-indigo-50/20 p-4 rounded-2xl border-2 border-indigo-50 space-y-1">
                        <span className="text-[9px] font-black uppercase text-indigo-400 block tracking-widest">Portion Alignment Guidance:</span>
                        <p className="text-indigo-950">{detailedScanResult.personalizedRecommendations.portionRecommendation}</p>
                      </div>

                      {/* Foods to Add & Reduce Grid */}
                      <div className="grid gap-4 sm:grid-cols-2">
                        <div className="bg-emerald-50/30 p-4 rounded-2xl border border-emerald-100 space-y-1.5">
                          <span className="text-[9px] font-black uppercase text-emerald-800 block tracking-widest">Ingredients to Add:</span>
                          <ul className="list-disc list-inside space-y-1 text-[11px]">
                            {detailedScanResult.personalizedRecommendations.foodsToAdd?.map((food, idx) => (
                              <li key={idx}>{food}</li>
                            ))}
                          </ul>
                        </div>

                        <div className="bg-rose-50/30 p-4 rounded-2xl border border-rose-100 space-y-1.5">
                          <span className="text-[9px] font-black uppercase text-rose-800 block tracking-widest">Ingredients to Reduce:</span>
                          <ul className="list-disc list-inside space-y-1 text-[11px]">
                            {detailedScanResult.personalizedRecommendations.foodsToReduce?.map((food, idx) => (
                              <li key={idx}>{food}</li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      {/* Healthy Substitutions */}
                      <div className="bg-indigo-50/20 p-4 rounded-2xl border-2 border-indigo-50 space-y-1.5">
                        <span className="text-[9px] font-black uppercase text-indigo-400 block tracking-widest font-black">Healthier Substitution Alternatives:</span>
                        <ul className="list-decimal list-inside space-y-1 text-[11px]">
                          {detailedScanResult.personalizedRecommendations.healthierSubstitutions?.map((sub, idx) => (
                            <li key={idx}>{sub}</li>
                          ))}
                        </ul>
                      </div>

                      {/* Better Alternatives */}
                      {detailedScanResult.personalizedRecommendations.betterAlternatives?.length > 0 && (
                        <div className="bg-indigo-50/20 p-4 rounded-2xl border-2 border-indigo-50 space-y-1.5">
                          <span className="text-[9px] font-black uppercase text-indigo-400 block tracking-widest font-black">Alternative Menu Choices:</span>
                          <ul className="list-decimal list-inside space-y-1 text-[11px]">
                            {detailedScanResult.personalizedRecommendations.betterAlternatives.map((alt, idx) => (
                              <li key={idx}>{alt}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Timing & Goals specific */}
                      <div className="grid gap-4 sm:grid-cols-2 text-[11px]">
                        <div className="bg-indigo-50/20 p-4 rounded-2xl border border-indigo-50">
                          <span className="text-[8px] font-black uppercase text-indigo-400 block tracking-wider mb-1">Meal Timing suggestion:</span>
                          <p>{detailedScanResult.personalizedRecommendations.mealTiming}</p>
                        </div>
                        <div className="bg-indigo-50/20 p-4 rounded-2xl border border-indigo-50">
                          <span className="text-[8px] font-black uppercase text-indigo-400 block tracking-wider mb-1">Goal Specific advice:</span>
                          <p>{detailedScanResult.personalizedRecommendations.goalSpecificAdvice}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* SCANNER ACTIVE INTERFACE */
            <div className="grid gap-8 lg:grid-cols-5">
              
              {/* Image Upload simulation */}
              <div className="lg:col-span-3 rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-2xl space-y-6">
                <div>
                  <h3 className="font-sans text-lg font-black text-indigo-950 uppercase flex items-center gap-2">
                    <Camera className="h-5 w-5 text-indigo-600" />
                    AI Vision Recognition Scanner
                  </h3>
                  <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest mt-1">
                    Analyze food items instantly from real plate snapshots
                  </p>
                </div>

                <div className="grid gap-4 sm:grid-cols-3">
                  {scanSamples.map((sample, idx) => (
                    <div 
                      key={idx}
                      onClick={() => handleStartScan(sample.image)}
                      className="group cursor-pointer rounded-2xl overflow-hidden border-2 border-indigo-50 hover:border-indigo-600 transition-all relative flex flex-col justify-between bg-indigo-50/10 shadow-sm"
                    >
                      <img 
                        src={sample.image} 
                        alt={sample.name} 
                        referrerPolicy="no-referrer"
                        className="h-28 w-full object-cover group-hover:scale-105 transition-transform duration-350"
                      />
                      <div className="p-2.5 text-center">
                        <span className="text-[10px] font-black uppercase text-indigo-950 tracking-tight">
                          {sample.name}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="border-4 border-dashed border-indigo-100 rounded-3xl p-8 text-center space-y-4 bg-indigo-50/5 relative">
                  <Upload className="h-10 w-10 text-indigo-300 mx-auto" />
                  <div className="space-y-1">
                    <p className="text-xs text-indigo-950 font-black uppercase">Drag & Drop plate snapshot</p>
                    <p className="text-[10px] text-indigo-400 font-bold">PNG, JPG formats up to 10MB accepted</p>
                  </div>
                  
                  {/* Invisible real file input */}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />

                  <button
                    type="button"
                    className="px-4.5 py-2 bg-indigo-50 hover:bg-indigo-150 text-indigo-950 text-[10px] font-black uppercase tracking-wider rounded-xl transition-colors relative z-10 pointer-events-none"
                  >
                    Select File
                  </button>
                </div>
              </div>

              {/* Scanned food calculations results box */}
              <div className="lg:col-span-2 rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-2xl flex flex-col justify-between min-h-[300px]">
                {isScanning ? (
                  <div className="flex-1 flex flex-col items-center justify-center py-12 space-y-4">
                    <Loader2 className="h-10 w-10 text-indigo-600 animate-spin" />
                    <div className="text-center">
                      <p className="text-sm font-black text-indigo-950 uppercase tracking-tight">AI scanning plate...</p>
                      <p className="text-[10px] text-indigo-400 font-bold">Gemini is estimating volumes and density</p>
                    </div>
                  </div>
                ) : scanError ? (
                  <div className="flex-1 flex flex-col items-center justify-center py-8 text-center space-y-3">
                    <ShieldAlert className="h-10 w-10 text-rose-500 mx-auto" />
                    <p className="text-sm font-black text-indigo-950">Scan Failed</p>
                    <p className="text-xs text-rose-500">{scanError}</p>
                    <button
                      onClick={() => setScanError(null)}
                      className="px-4 py-2 bg-indigo-50 text-indigo-950 text-[10px] font-black rounded-xl uppercase hover:bg-indigo-100"
                    >
                      Clear Error
                    </button>
                  </div>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center py-8 text-center">
                    <Camera className="h-10 w-10 text-indigo-200 mx-auto" />
                    <p className="mt-3 text-sm font-black text-indigo-950">AI Plate Scan Pending.</p>
                    <p className="text-xs text-indigo-400 mt-1">Select a sample dish or drag/drop an image to scan.</p>
                  </div>
                )}
              </div>

            </div>
          )}
        </div>
      )}
    </div>
  );
}
