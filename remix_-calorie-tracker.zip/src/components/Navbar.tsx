import React from "react";
import { 
  LayoutDashboard, Search, Sparkles, TrendingUp, Settings, Flame, 
  CreditCard, ShieldAlert, LogOut, Award, CalendarClock, RefreshCw
} from "lucide-react";
import { UserAccount } from "../types";

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentUser: UserAccount | null;
  onLogout: () => void;
}

export default function Navbar({ activeTab, setActiveTab, currentUser, onLogout }: NavbarProps) {
  // Navigation tabs definition
  const getNavItems = () => {
    const items = [
      { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
      { id: "logger", label: "AI Log & Search", icon: Search },
      { id: "ai-guide", label: "AI Premium Guide", icon: Sparkles },
      { id: "analytics", label: "Trends & Charts", icon: TrendingUp },
      { id: "pricing", label: "Plans & Pricing", icon: Award },
    ];

    if (currentUser) {
      // Add Billing dashboard
      items.push({ id: "billing", label: "My Billing", icon: CreditCard });

      // Add Admin workspace if role is admin
      if (currentUser.role === "admin") {
        items.push({ id: "admin", label: "Admin Portal", icon: ShieldAlert });
      }
    }

    items.push({ id: "settings", label: "Goals & Profile", icon: Settings });

    return items;
  };

  const navItems = getNavItems();

  // Calculate Trial countdown
  const getTrialCountdown = () => {
    if (!currentUser || currentUser.tier !== "free_trial" || !currentUser.trialEnd) return null;
    const daysLeft = Math.max(0, Math.ceil((currentUser.trialEnd - Date.now()) / (1000 * 60 * 60 * 24)));
    return daysLeft;
  };

  const daysLeft = getTrialCountdown();

  return (
    <header className="sticky top-0 z-50 w-full border-b-4 border-indigo-100 bg-white/95 backdrop-blur-md">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Logo / Brand Name */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="flex h-11 w-11 items-center justify-center rounded-[18px] bg-indigo-600 text-white shadow-lg shadow-indigo-600/30">
            <Flame className="h-5.5 w-5.5" />
          </div>
          <div className="hidden sm:block">
            <h1 className="font-sans text-xl font-black text-indigo-950 tracking-tight leading-none">
              Track & Fuel
            </h1>
            <p className="text-[9px] font-bold text-indigo-500 uppercase tracking-widest mt-1">Calorie Tracker</p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex space-x-1 sm:space-x-1.5 overflow-x-auto py-1 max-w-full no-scrollbar">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-1.5 rounded-2xl px-3 py-2 text-xs font-black transition-all duration-200 shrink-0 ${
                  isActive
                    ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/20"
                    : "text-indigo-600 hover:bg-indigo-50 hover:text-indigo-900"
                }`}
              >
                <Icon className={`h-4 w-4 ${isActive ? "text-white" : "text-indigo-500"}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* User Account / Trial Status Badge / Logout */}
        {currentUser && (
          <div className="flex items-center gap-3 shrink-0">
            {/* Trial count or Tier Label indicator */}
            {daysLeft !== null ? (
              <button 
                onClick={() => setActiveTab("pricing")}
                className="hidden lg:flex items-center gap-1.5 rounded-full bg-indigo-100 px-3.5 py-1.5 text-[10px] font-black text-indigo-700 uppercase tracking-wider hover:bg-indigo-200 transition-colors"
              >
                <CalendarClock className="h-3.5 w-3.5 animate-pulse" />
                <span>{daysLeft} Trial Days Left ⏳</span>
              </button>
            ) : (
              <span className="hidden lg:inline-block rounded-full bg-emerald-100 px-3 py-1 text-[10px] font-black text-emerald-800 uppercase tracking-wider">
                {currentUser.tier === "expert" ? "👑 Expert" : currentUser.tier === "pro" ? "⚡ PRO Member" : "✓ Basic Active"}
              </span>
            )}

            {/* Profile node */}
            <div className="flex items-center gap-2 border-l-2 border-indigo-50 pl-3">
              <div className="flex flex-col text-right hidden md:block">
                <span className="text-xs font-black text-indigo-950 block max-w-[150px] truncate">{currentUser.name}</span>
                <span className="text-[9px] font-bold text-indigo-500 uppercase tracking-widest block">{currentUser.role === "admin" ? "Dietitian Admin" : "User Profile"}</span>
              </div>
              <div className="h-8 w-8 rounded-full bg-indigo-950 text-white flex items-center justify-center font-black text-xs font-sans select-none shrink-0">
                {currentUser.name.split(" ").map(n => n[0]).join("").substring(0, 2).toUpperCase()}
              </div>
              <button
                onClick={onLogout}
                title={currentUser.role === "admin" ? "Switch to User Workspace" : "Switch to Admin Workspace"}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider bg-indigo-50 hover:bg-indigo-100 text-indigo-700 hover:text-indigo-900 transition-colors cursor-pointer shrink-0"
              >
                <RefreshCw className="h-3 w-3 text-indigo-600 animate-spin" style={{ animationDuration: '6s' }} />
                <span>{currentUser.role === "admin" ? "To User" : "To Admin"}</span>
              </button>
            </div>
          </div>
        )}

      </div>
    </header>
  );
}
