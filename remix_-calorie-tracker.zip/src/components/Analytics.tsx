import React from "react";
import { LogEntry, UserProfile, WeightLog, WaterLog, CustomNutrient } from "../types";
import { TrendingUp, Award, Calendar, Activity, Info, Sparkles } from "lucide-react";

interface AnalyticsProps {
  logs: LogEntry[];
  profile: UserProfile;
  weightLogs: WeightLog[];
  waterLogs: WaterLog[];
  customNutrients: CustomNutrient[];
}

export default function Analytics({ logs, profile, weightLogs, waterLogs, customNutrients }: AnalyticsProps) {
  const daysOfWeek = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const todayStr = new Date().toISOString().split("T")[0];

  // Sum up logged custom nutrient values
  const getConsumedAmount = (nutrientId: string) => {
    return logs.reduce((sum, entry) => {
      if (entry.foodItem.nutrients && entry.foodItem.nutrients[nutrientId] !== undefined) {
        return sum + (entry.foodItem.nutrients[nutrientId] || 0) * entry.quantity;
      }
      
      const nutrient = customNutrients.find(n => n.id === nutrientId);
      if (!nutrient) return sum;
      
      const lowerName = nutrient.name.toLowerCase();
      let fallbackVal = 0;
      if (lowerName.includes("calorie") || lowerName === "kcal" || lowerName === "energy") {
        fallbackVal = entry.foodItem.calories || 0;
      } else if (lowerName.includes("protein")) {
        fallbackVal = entry.foodItem.protein || 0;
      } else if (lowerName.includes("carb")) {
        fallbackVal = entry.foodItem.carbs || 0;
      } else if (lowerName.includes("fat")) {
        fallbackVal = entry.foodItem.fat || 0;
      } else if (lowerName.includes("fiber")) {
        fallbackVal = (entry.foodItem as any).fiber || 0;
      } else if (lowerName.includes("sugar")) {
        fallbackVal = (entry.foodItem as any).sugar || 0;
      } else if (lowerName.includes("sodium")) {
        fallbackVal = (entry.foodItem as any).sodium || 0;
      } else if (lowerName.includes("water")) {
        fallbackVal = (entry.foodItem as any).water || 0;
      }
      return sum + fallbackVal * entry.quantity;
    }, 0);
  };

  // Weight tracking trend logic
  const todayWeight = weightLogs.find((w) => w.date === todayStr)?.weight || profile.weight;
  const weightTrendData = daysOfWeek.map((day, idx) => {
    const defaultOffset = [0.4, 0.2, 0.3, 0.1, 0, -0.2, -0.3][idx];
    const baseWeight = todayWeight + defaultOffset;
    return { day, weight: Number(baseWeight.toFixed(1)) };
  });

  const weights = weightTrendData.map((d) => d.weight);
  const minWeight = Math.min(...weights) - 1;
  const maxWeight = Math.max(...weights) + 1;

  // Water tracking trend
  const todayWater = waterLogs.find((w) => w.date === todayStr)?.amount || 0;
  const waterTrendData = daysOfWeek.map((day, idx) => {
    const defaultVal = [1500, 2000, 1750, 2250, 2500, 1200, todayWater][idx];
    return { day, amount: defaultVal };
  });
  const maxWaterVal = Math.max(...waterTrendData.map(d => d.amount), 2000) * 1.1;

  return (
    <div className="space-y-10 pb-16">
      {/* Page Header */}
      <div>
        <h2 className="font-sans text-5xl font-black text-indigo-950 tracking-tight">
          Performance Analytics
        </h2>
        <p className="mt-2 text-lg text-indigo-600 font-bold opacity-80">
          Visualize your customized nutrition velocity, daily consistencies, hydration indices, and weight deltas.
        </p>
      </div>

      {customNutrients.length === 0 ? (
        <div className="rounded-[36px] border-4 border-dashed border-indigo-100 bg-white p-12 text-center max-w-3xl mx-auto space-y-6 shadow-xl">
          <div className="h-16 w-16 bg-indigo-50 text-indigo-600 flex items-center justify-center rounded-2xl mx-auto">
            <Activity className="h-8 w-8" />
          </div>
          <div className="space-y-2">
            <h4 className="font-sans text-2xl font-black text-indigo-950 uppercase tracking-tight">
              Zero Metric Goals Configured
            </h4>
            <p className="text-sm text-indigo-500 font-bold max-w-md mx-auto leading-relaxed">
              No daily tracking parameters are currently set. Add your custom nutrients (like Calories, Protein, Carbs, or Water) in Goals & Settings to unlock detailed chart overlays!
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-12">
          
          {/* Bento boxes summary grids */}
          <div className="grid gap-6 grid-cols-2 lg:grid-cols-4">
            {customNutrients.slice(0, 4).map((cn) => {
              const consumed = getConsumedAmount(cn.id);
              const pct = cn.target > 0 ? Math.round((consumed / cn.target) * 100) : 0;
              const isOver = consumed > cn.target;
              
              return (
                <div 
                  key={cn.id} 
                  className={`rounded-[32px] border-4 p-6 shadow-xl bg-white flex flex-col justify-between ${
                    isOver ? "border-amber-400" : "border-indigo-100"
                  }`}
                >
                  <div>
                    <p className="text-xs font-black text-indigo-400 uppercase tracking-widest truncate">{cn.name}</p>
                    <div className="mt-2 flex items-baseline gap-1">
                      <span className="font-sans text-3xl font-black text-indigo-950">
                        {consumed.toLocaleString(undefined, { maximumFractionDigits: 1 })}
                      </span>
                      <span className="text-[10px] text-indigo-400 font-bold uppercase font-mono">/{cn.unit}</span>
                    </div>
                  </div>
                  <span className={`mt-4 text-[10px] font-black uppercase tracking-wider text-center py-1.5 px-3 rounded-full ${
                    isOver ? "bg-amber-100 text-amber-900" : "bg-emerald-50 text-emerald-950"
                  }`}>
                    {pct}% of {cn.target} {cn.unit} Goal
                  </span>
                </div>
              );
            })}

            {/* Standard Weight overview card */}
            <div className="rounded-[32px] border-4 border-indigo-100 bg-white p-6 shadow-xl flex flex-col justify-between">
              <div>
                <p className="text-xs font-black text-indigo-400 uppercase tracking-widest">Weight Delta</p>
                <div className="mt-2 flex items-baseline gap-1">
                  <span className="font-sans text-3xl font-black text-indigo-950">{todayWeight}</span>
                  <span className="text-[10px] text-indigo-400 font-bold uppercase font-mono">kg</span>
                </div>
              </div>
              <span className="mt-4 text-[10px] font-black text-indigo-950 bg-green-400/20 px-3 py-1.5 rounded-full text-center uppercase tracking-wider">
                Target: {profile.weightGoal} kg
              </span>
            </div>
          </div>

          {/* Graphical section charts */}
          <div className="grid gap-8 md:grid-cols-2">
            
            {/* Custom Nutrients Aggregated Goal Charts */}
            <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-2xl space-y-6">
              <h3 className="font-sans text-lg font-black text-indigo-950 uppercase flex items-center gap-2">
                <Award className="h-5 w-5 text-indigo-600" />
                Active Custom Nutrients Logging Levels
              </h3>
              
              <div className="space-y-4 pt-2">
                {customNutrients.map((cn) => {
                  const consumed = getConsumedAmount(cn.id);
                  const pct = cn.target > 0 ? Math.min(100, Math.round((consumed / cn.target) * 100)) : 0;
                  
                  return (
                    <div key={cn.id} className="space-y-1.5">
                      <div className="flex justify-between items-baseline">
                        <span className="text-xs font-black text-indigo-950 uppercase tracking-wide">
                          {cn.name}
                        </span>
                        <span className="text-xs font-mono font-bold text-indigo-500">
                          {consumed.toLocaleString(undefined, { maximumFractionDigits: 1 })} / {cn.target} {cn.unit} ({pct}%)
                        </span>
                      </div>
                      <div className="w-full h-3.5 bg-indigo-50 rounded-full overflow-hidden border border-indigo-100">
                        <div 
                          className="h-full bg-indigo-600 rounded-full" 
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Weight Fluctuations Chart */}
            <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-2xl space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="font-sans text-lg font-black text-indigo-950 uppercase flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-indigo-600" />
                  Biometric Weight Grid (7-Day Trend)
                </h3>
                <span className="text-xs font-black text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full">Target: {profile.weightGoal} kg</span>
              </div>

              <div className="h-52 w-full relative">
                <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                  <defs>
                    <linearGradient id="weight-gradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#4f46e5" stopOpacity="0.4" />
                      <stop offset="100%" stopColor="#4f46e5" stopOpacity="0.0" />
                    </linearGradient>
                  </defs>
                  
                  {/* Target line */}
                  {(() => {
                    const targetY = 100 - ((profile.weightGoal - minWeight) / (maxWeight - minWeight)) * 100;
                    return (
                      <line 
                        x1="0" 
                        y1={targetY} 
                        x2="100" 
                        y2={targetY} 
                        stroke="#4f46e5" 
                        strokeWidth="1" 
                        strokeDasharray="4,4"
                      />
                    );
                  })()}

                  {/* Line graph path */}
                  {(() => {
                    const points = weightTrendData.map((d, i) => {
                      const x = (i / (weightTrendData.length - 1)) * 100;
                      const y = 100 - ((d.weight - minWeight) / (maxWeight - minWeight)) * 100;
                      return `${x},${y}`;
                    }).join(" ");

                    return (
                      <>
                        <path
                          d={`M 0,100 L ${points} L 100,100 Z`}
                          fill="url(#weight-gradient)"
                        />
                        <polyline
                          fill="none"
                          stroke="#7c3aed"
                          strokeWidth="2.5"
                          points={points}
                        />
                      </>
                    );
                  })()}
                </svg>

                <div className="absolute inset-x-0 bottom-0 flex justify-between px-1 text-[10px] font-black text-indigo-400">
                  {weightTrendData.map((d, idx) => (
                    <span key={idx}>{d.day}</span>
                  ))}
                </div>
              </div>
            </div>

            {/* Water Levels trends chart */}
            <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-2xl space-y-6 md:col-span-2">
              <h3 className="font-sans text-lg font-black text-indigo-950 uppercase flex items-center gap-2">
                <Calendar className="h-5 w-5 text-indigo-600" />
                Hydration Trends (7-Day History)
              </h3>

              <div className="h-44 w-full flex items-end gap-3 px-2 pt-6">
                {waterTrendData.map((d, idx) => {
                  const hPct = (d.amount / maxWaterVal) * 100;
                  return (
                    <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end group relative">
                      <div className="absolute bottom-full mb-1 opacity-0 group-hover:opacity-100 bg-indigo-950 text-white font-mono text-[9px] px-2 py-1 rounded-lg pointer-events-none transition-opacity">
                        {d.amount}ml
                      </div>
                      <div 
                        className="w-full bg-blue-500 rounded-t-xl hover:bg-blue-600 transition-all border border-blue-950"
                        style={{ height: `${hPct}%` }}
                      />
                      <span className="text-[10px] font-black text-indigo-400 uppercase mt-2">{d.day}</span>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>

        </div>
      )}
    </div>
  );
}
