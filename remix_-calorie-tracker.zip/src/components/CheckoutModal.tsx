import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  CreditCard, ShieldCheck, AlertCircle, RefreshCw, Sparkles, CheckCircle2, Lock, ArrowRight, HelpCircle
} from "lucide-react";
import { SubscriptionTier, UserAccount, Invoice } from "../types";
import { logEmail } from "../mockDatabase";

interface CheckoutModalProps {
  planId: SubscriptionTier;
  currentUser: UserAccount;
  onClose: () => void;
  onSuccess: (updatedUser: UserAccount) => void;
}

export default function CheckoutModal({ planId, currentUser, onClose, onSuccess }: CheckoutModalProps) {
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [name, setName] = useState(currentUser.name);

  // States
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [success, setSuccess] = useState(false);

  // Get plan specific descriptors
  const getPlanDetails = () => {
    switch (planId) {
      case "basic":
        return { name: "Basic Plan", price: 5, description: "All core tracking tools & Standard AI Coach Chat" };
      case "pro":
        return { name: "Pro Plan", price: 15, description: "Priority support, double AI limits, advanced trends" };
      case "expert":
        return { name: "Expert Plan", price: 50, description: "Unlimited AI interactions, dietitian collaboration features" };
      default:
        return { name: "Free Trial", price: 0, description: "14-day fully featured sandbox trial" };
    }
  };

  const plan = getPlanDetails();

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    if (!cardNumber || !expiry || !cvv) {
      setErrorMsg("Please fill out your billing card details.");
      return;
    }

    setLoading(true);

    setTimeout(() => {
      // Simulate Stripe API transaction response
      if (cvv === "000") {
        setErrorMsg("Stripe decline (Code: card_declined). The bank has rejected the transaction request. Try CVV: 999 or 123 for success!");
        setLoading(false);

        // Send a failed payment notification email
        logEmail(
          currentUser.email,
          "Transaction failure alert: Payment declined ⚠️",
          `Hi ${currentUser.name},\n\nWe were unable to process your recurring payment of $${plan.price}.00 for the Track & Fuel ${plan.name}.\n\nError details: Card Declined by Issuer (Code: card_declined).\n\nYour account remains in its active status for 3 days to allow you to retry billing or connect a different card in your dashboard setting.`,
          "payment_failed"
        );
        return;
      }

      // Successful payments
      setLoading(false);
      setSuccess(true);

      setTimeout(() => {
        const nextDate = new Date();
        nextDate.setMonth(nextDate.getMonth() + 1);
        const nextBillingStr = nextDate.toISOString().split("T")[0];

        // Create a real new invoice record
        const invoiceId = "inv_str_" + Math.random().toString(36).substring(2, 9);
        const newInvoice: Invoice = {
          id: invoiceId,
          date: new Date().toISOString().split("T")[0],
          amount: plan.price,
          status: "paid",
          plan: plan.name
        };

        const updatedUser: UserAccount = {
          ...currentUser,
          tier: planId,
          status: "active",
          isAutoRenew: true,
          nextBillingDate: nextBillingStr,
          invoices: [newInvoice, ...currentUser.invoices]
        };

        // Notify client via Resend SMTP
        logEmail(
          currentUser.email,
          `Invoice receipt for ${plan.name} subscription 🧾`,
          `Hi ${currentUser.name},\n\nThank you for choosing Track & Fuel!\n\nYour transaction has processed successfully:\n- Plan Tier: ${plan.name}\n- Price: $${plan.price}.00/month\n- Invoice reference ID: ${invoiceId}\n- Payment gateway: Stripe Secure Tokens\n\nYour subscription renewal date is: ${nextBillingStr}.\n\nYou can retrieve and print your full PDF invoices anytime from your account settings.`,
          "payment_receipt"
        );

        onSuccess(updatedUser);
      }, 1500);
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-indigo-950/40 backdrop-blur-sm p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="w-full max-w-xl rounded-[40px] bg-white border-4 border-indigo-950 p-8 shadow-2xl overflow-hidden relative"
      >
        <AnimatePresence mode="wait">
          {!success ? (
            <motion.div
              key="checkout_form"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              {/* Checkout header */}
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="h-8 w-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-black">
                    S
                  </div>
                  <span className="font-sans text-xs font-black tracking-widest text-indigo-400 uppercase">Stripe Checkout</span>
                </div>
                <button
                  onClick={onClose}
                  className="text-xs font-black uppercase text-indigo-400 hover:text-indigo-950"
                >
                  Cancel
                </button>
              </div>

              {/* Order summary card */}
              <div className="rounded-[28px] border-2 border-indigo-50 bg-indigo-50/25 p-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div className="space-y-1">
                  <span className="text-[9px] font-black text-indigo-400 uppercase tracking-widest">Order Details</span>
                  <h4 className="font-sans text-lg font-black text-indigo-950">{plan.name} License</h4>
                  <p className="text-[11px] text-indigo-500 font-bold">{plan.description}</p>
                </div>
                <div className="text-right">
                  <span className="block text-2xl font-black text-indigo-950 font-mono">${plan.price}.00</span>
                  <span className="block text-[10px] text-indigo-400 font-bold uppercase tracking-wider">Billed Monthly</span>
                </div>
              </div>

              {/* Action responses */}
              {errorMsg && (
                <div className="flex items-start gap-2.5 rounded-2xl bg-rose-50 border-2 border-rose-100 p-4 text-xs text-rose-800 font-bold">
                  <AlertCircle className="h-4 w-4 shrink-0 text-rose-500 mt-0.5" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Form card details */}
              <form onSubmit={handleCheckoutSubmit} className="space-y-4 text-xs">
                <div>
                  <label className="block text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-1.5">Cardholder Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3 text-xs font-bold text-indigo-950 outline-none focus:border-indigo-400 transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-1.5">Credit Card Number</label>
                  <div className="relative">
                    <CreditCard className="absolute left-4 top-3.5 h-4.5 w-4.5 text-indigo-300" />
                    <input
                      type="text"
                      required
                      placeholder="4242 4242 4242 4242"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value.replace(/\D/g, "").replace(/(.{4})/g, "$1 ").trim())}
                      className="w-full rounded-2xl border-4 border-indigo-50 pl-11 pr-4 py-3.5 text-xs font-bold text-indigo-950 outline-none focus:border-indigo-400 transition-colors font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-1.5">Expiration Date</label>
                    <input
                      type="text"
                      required
                      placeholder="MM/YY"
                      maxLength={5}
                      value={expiry}
                      onChange={(e) => setExpiry(e.target.value)}
                      className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3.5 text-xs font-bold text-indigo-950 outline-none focus:border-indigo-400 transition-colors font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-1.5 flex items-center justify-between">
                      <span>CVV Code</span>
                      <span className="text-[8px] text-indigo-400 lowercase normal-case">(Type 000 for declined failure)</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="999"
                      maxLength={3}
                      value={cvv}
                      onChange={(e) => setCvv(e.target.value.replace(/\D/g, ""))}
                      className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3.5 text-xs font-bold text-indigo-950 outline-none focus:border-indigo-400 transition-colors font-mono"
                    />
                  </div>
                </div>

                {/* Secure Trust Indicators */}
                <div className="flex items-center gap-2 text-[10px] text-indigo-400 font-bold">
                  <Lock className="h-3.5 w-3.5 text-indigo-300" />
                  <span>256-Bit SSL Encrypted Credit Card Information. No actual logs stored.</span>
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full rounded-3xl bg-indigo-600 hover:bg-indigo-700 py-4 text-xs font-black text-white active:scale-98 transition-all shadow-xl shadow-indigo-600/25 flex items-center justify-center gap-2 cursor-pointer"
                >
                  {loading ? (
                    <RefreshCw className="h-4.5 w-4.5 text-white animate-spin" />
                  ) : (
                    <>
                      <span>COMPLETE SECURE ENROLLMENT</span>
                      <ArrowRight className="h-4.5 w-4.5 text-white" />
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          ) : (
            <motion.div
              key="checkout_success"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-center py-10 space-y-6"
            >
              <div className="mx-auto h-16 w-16 rounded-[24px] bg-emerald-50 text-emerald-500 flex items-center justify-center shadow-lg shadow-emerald-500/15">
                <ShieldCheck className="h-8 w-8 stroke-[2.5px]" />
              </div>

              <div className="space-y-2">
                <h3 className="font-sans text-3xl font-black text-indigo-950">License Issued Successfully!</h3>
                <p className="text-xs text-indigo-500 font-bold">
                  Stripe Payment Complete. Your premium coaching capabilities have unlocked instantly.
                </p>
              </div>

              <div className="bg-slate-50 border border-indigo-50 rounded-2xl p-4 text-[10px] font-bold text-indigo-400 uppercase tracking-wider">
                Resend email confirmation dispatch confirmed
              </div>

              <div className="flex justify-center items-center gap-2 text-xs text-indigo-600 font-bold animate-pulse">
                <RefreshCw className="h-3 w-3 animate-spin" />
                <span>Redirecting back to your biological dashboard...</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}

// Small helper border decoration wrapper
function YellowGlowIndicator({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative group">
      <div className="absolute -inset-1 rounded-[44px] bg-gradient-to-r from-indigo-500 via-amber-400 to-emerald-500 opacity-20 blur-lg" />
      <div className="relative">{children}</div>
    </div>
  );
}
