import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  CreditCard, Calendar, FileText, CheckCircle2, AlertCircle, RefreshCw, XCircle, Play, 
  Sparkles, Download, ShieldCheck, ArrowUpRight, HelpCircle, Heart, Key
} from "lucide-react";
import { UserAccount, Invoice, SubscriptionTier } from "../types";
import { logEmail } from "../mockDatabase";

interface BillingDashboardProps {
  currentUser: UserAccount;
  onUpdateUser: (updated: UserAccount) => void;
  onNavigateToTab: (tab: string) => void;
}

export default function BillingDashboard({ currentUser, onUpdateUser, onNavigateToTab }: BillingDashboardProps) {
  // Modal for individual Invoice printable PDF
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  // States for updating payment card
  const [showCardModal, setShowCardModal] = useState(false);
  const [cardNumber, setCardNumber] = useState("•••• •••• •••• 4242");
  const [cardName, setCardName] = useState(currentUser.name);
  const [cardExpiry, setCardExpiry] = useState("12/29");
  const [cardCvv, setCardCvv] = useState("•••");
  const [isSavingCard, setIsSavingCard] = useState(false);
  const [cardSuccess, setCardSuccess] = useState("");

  // Cancel subscription logic
  const handleCancelSubscription = () => {
    if (confirm("Are you sure you want to cancel your recurring Track & Fuel plan? You will retain access until the end of your billing cycle.")) {
      const updatedUser: UserAccount = {
        ...currentUser,
        status: "canceled",
        isAutoRenew: false
      };
      onUpdateUser(updatedUser);
      
      logEmail(
        currentUser.email,
        "Subscription cancelation confirmed 🛑",
        `Hi ${currentUser.name},\n\nWe have received your cancellation request for the Track & Fuel ${currentUser.tier.toUpperCase()} subscription.\n\nYour premium access remains valid until: ${currentUser.nextBillingDate}.\n\nYou can reactivate auto-renewal anytime in your billing cockpit.`,
        "subscription_canceled"
      );
    }
  };

  // Reactivate subscription logic
  const handleReactivateSubscription = () => {
    const updatedUser: UserAccount = {
      ...currentUser,
      status: "active",
      isAutoRenew: true
    };
    onUpdateUser(updatedUser);

    logEmail(
      currentUser.email,
      "Subscription reactivated! 🎉 [Renewal Restored]",
      `Hi ${currentUser.name},\n\nYour Track & Fuel ${currentUser.tier.toUpperCase()} subscription has been reactivated successfully.\n\nYour next recurring invoice will process on: ${currentUser.nextBillingDate}.\n\nThank you for fueling with us!`,
      "subscription_renewed"
    );
  };

  // Saved Payment Card Submission
  const handleSaveCard = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingCard(true);
    setTimeout(() => {
      setIsSavingCard(false);
      setCardSuccess("Credit card tokens securely updated via Stripe proxy! ✓");
      setTimeout(() => {
        setCardSuccess("");
        setShowCardModal(false);
      }, 2000);
    }, 1500);
  };

  // Helper: Get Trial countdown days
  const getTrialDaysRemaining = () => {
    if (currentUser.tier !== "free_trial" || !currentUser.trialEnd) return 0;
    return Math.max(0, Math.ceil((currentUser.trialEnd - Date.now()) / (1000 * 60 * 60 * 24)));
  };

  const trialDaysRemaining = getTrialDaysRemaining();

  return (
    <div className="space-y-10 pb-16">
      {/* Header Visual Hub */}
      <div>
        <h2 className="font-sans text-5xl font-black text-indigo-950 tracking-tight flex items-center gap-3">
          SaaS Billing Cockpit
          <span className="inline-block rounded-full bg-indigo-100 px-3.5 py-1 text-xs font-black text-indigo-700 uppercase tracking-widest">
            SUBSCRIBER ACTIVE
          </span>
        </h2>
        <p className="mt-2 text-md text-indigo-600 font-bold opacity-80">
          Control your recurring plans, review invoices, adjust saved payment credentials, or download receipts securely.
        </p>
      </div>

      <div className="grid gap-8 lg:grid-cols-12">
        {/* Core subscription details panel */}
        <div className="lg:col-span-8 space-y-6">
          {/* Main Account details banner card */}
          <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 h-40 w-40 rounded-full bg-indigo-50/50 -mr-16 -mt-16 -z-10 blur-xl" />

            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              {/* Left detail */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest block">Active License level</span>
                  <span className={`inline-block px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-wider ${
                    currentUser.tier === "expert" ? "bg-indigo-950 text-indigo-100" :
                    currentUser.tier === "pro" ? "bg-indigo-100 text-indigo-800" :
                    currentUser.tier === "basic" ? "bg-indigo-50 text-indigo-700" : "bg-blue-50 text-blue-800"
                  }`}>
                    {currentUser.tier === "free_trial" ? "14-Day Free Trial" : `${currentUser.tier.toUpperCase()} Plan`}
                  </span>
                </div>

                <h3 className="font-sans text-4xl font-black text-indigo-950 tracking-tight leading-none">
                  {currentUser.tier === "free_trial" 
                    ? `${trialDaysRemaining} Days Remaining` 
                    : currentUser.status === "canceled" 
                    ? "Canceled (Pending Expiry)" 
                    : "Recurring Subscription Active"}
                </h3>

                <p className="text-xs text-indigo-500 font-bold max-w-md">
                  {currentUser.tier === "free_trial" 
                    ? "Your sandbox remains fully active with standard logging utilities. Connect a premium plan before expiry to retain AI coaches!"
                    : currentUser.status === "canceled"
                    ? `Your benefits remain fully valid until your cycle concludes on ${currentUser.nextBillingDate}. Auto-renewal has been paused.`
                    : `Your subscription is operating smoothly. Next automatic renewal transaction of $${currentUser.tier === "basic" ? 5 : currentUser.tier === "pro" ? 15 : 50}.00 will process on ${currentUser.nextBillingDate}.`}
                </p>
              </div>

              {/* Right context actions */}
              <div className="flex flex-col sm:flex-row md:flex-col gap-3">
                {currentUser.tier === "free_trial" ? (
                  <button
                    onClick={() => onNavigateToTab("pricing")}
                    className="rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-4 text-xs font-black uppercase tracking-widest shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <ArrowUpRight className="h-4 w-4" />
                    CHOOSE PREMIUM PLAN
                  </button>
                ) : currentUser.status === "canceled" ? (
                  <button
                    onClick={handleReactivateSubscription}
                    className="rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-4 text-xs font-black uppercase tracking-widest shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer animate-pulse"
                  >
                    <Play className="h-4 w-4 fill-white" />
                    REACTIVATE RENEWAL
                  </button>
                ) : (
                  <>
                    <button
                      onClick={() => onNavigateToTab("pricing")}
                      className="rounded-2xl border-4 border-indigo-50 hover:border-indigo-400 text-indigo-950 px-6 py-3 text-xs font-black uppercase tracking-widest transition-all cursor-pointer"
                    >
                      UPGRADE / CHANGE TIER
                    </button>
                    <button
                      onClick={handleCancelSubscription}
                      className="rounded-2xl bg-red-50 hover:bg-red-100 text-red-700 px-6 py-3 text-xs font-black uppercase tracking-widest transition-all cursor-pointer"
                    >
                      CANCEL PLAN
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Ledger Invoices section */}
          <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-8 shadow-2xl space-y-6">
            <h3 className="font-sans text-xl font-black text-indigo-950 uppercase tracking-wide flex items-center gap-2">
              <FileText className="h-5 w-5 text-indigo-600" />
              Invoice History & Ledger
            </h3>

            {currentUser.invoices.length === 0 ? (
              <div className="text-center py-12 bg-indigo-50/20 rounded-3xl border-2 border-indigo-50/50 space-y-2">
                <FileText className="h-10 w-10 text-indigo-300 mx-auto" />
                <h4 className="font-sans text-sm font-black text-indigo-950">No Paid Invoices Logged</h4>
                <p className="text-xs text-indigo-500 font-bold">You are currently operating on a free trial tier. No charges have been processed.</p>
              </div>
            ) : (
              <div className="overflow-x-auto rounded-2xl border-2 border-indigo-50">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-indigo-50/50 border-b border-indigo-50 text-indigo-500 font-black uppercase tracking-wider">
                      <th className="px-6 py-4">Invoice Reference</th>
                      <th className="px-6 py-4">Transaction Date</th>
                      <th className="px-6 py-4">Plan Name</th>
                      <th className="px-6 py-4">Amount</th>
                      <th className="px-6 py-4">Status</th>
                      <th className="px-6 py-4 text-right">Receipt</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-indigo-50 font-semibold text-indigo-950">
                    {currentUser.invoices.map((inv) => (
                      <tr key={inv.id} className="hover:bg-indigo-50/10">
                        <td className="px-6 py-4 font-mono font-bold text-indigo-600">{inv.id}</td>
                        <td className="px-6 py-4">{inv.date}</td>
                        <td className="px-6 py-4 font-bold">{inv.plan}</td>
                        <td className="px-6 py-4 font-mono font-bold">${inv.amount}.00</td>
                        <td className="px-6 py-4">
                          <span className={`inline-block px-2.5 py-0.5 rounded text-[9px] font-black uppercase tracking-wider ${
                            inv.status === "paid" ? "bg-emerald-100 text-emerald-800" :
                            inv.status === "refunded" ? "bg-amber-100 text-amber-800" : "bg-rose-100 text-rose-800"
                          }`}>
                            {inv.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button
                            onClick={() => setSelectedInvoice(inv)}
                            className="p-2 text-indigo-600 hover:text-indigo-900 bg-indigo-50 hover:bg-indigo-100 rounded-xl transition-colors cursor-pointer"
                            title="Download PDF Invoice"
                          >
                            <Download className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Sidebar details (saved cards, guides) */}
        <div className="lg:col-span-4 space-y-6">
          {/* Card visualizer */}
          <div className="rounded-[40px] border-4 border-indigo-100 bg-white p-6 shadow-2xl space-y-6">
            <h4 className="font-sans text-xs font-black text-indigo-500 uppercase tracking-widest flex items-center justify-between">
              <span>Saved Payment Method</span>
              <button 
                onClick={() => setShowCardModal(true)}
                className="text-indigo-600 hover:text-indigo-900 text-[10px] font-black uppercase"
              >
                Change Card
              </button>
            </h4>

            {currentUser.tier === "free_trial" ? (
              <div className="bg-slate-50 border-2 border-dashed border-indigo-100 rounded-3xl p-6 text-center space-y-1">
                <CreditCard className="h-8 w-8 text-indigo-300 mx-auto" />
                <h5 className="font-sans text-xs font-black text-indigo-950">No Card on File</h5>
                <p className="text-[10px] text-indigo-400 font-bold">Free trial does not require cards to test.</p>
              </div>
            ) : (
              /* Saved Card visual display */
              <div className="rounded-2xl border border-indigo-50 bg-indigo-50/30 p-4.5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="h-9 w-12 rounded bg-indigo-950 flex items-center justify-center text-white shrink-0 font-bold italic text-xs shadow-md">
                    VISA
                  </div>
                  <div>
                    <span className="block text-xs font-mono font-bold text-indigo-950">{cardNumber}</span>
                    <span className="block text-[9px] text-indigo-400 uppercase font-black tracking-wider mt-0.5">Expires {cardExpiry}</span>
                  </div>
                </div>
                <div className="h-4.5 w-4.5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                </div>
              </div>
            )}

            <hr className="border-indigo-50 border-2" />

            {/* Help block */}
            <div className="space-y-3 text-xs">
              <div className="flex items-center gap-2 text-indigo-950">
                <HelpCircle className="h-4.5 w-4.5 text-indigo-600 stroke-[2.5px]" />
                <h4 className="font-sans text-xs font-black uppercase tracking-wider">
                  Billing Compliance Guide
                </h4>
              </div>
              <p className="text-indigo-500 font-bold leading-normal">
                Need details on tax invoices, direct bank wiring, or dietetic enterprise licenses? Reach out directly using the Admin supervisor channels for prioritized support ticketing.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Invoice Detail Printable Modal */}
      <AnimatePresence>
        {selectedInvoice && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-indigo-950/45 backdrop-blur-sm p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-lg rounded-[36px] bg-white border-4 border-indigo-950 p-8 shadow-2xl space-y-6"
            >
              {/* Header printable block */}
              <div className="flex justify-between items-start border-b-2 border-indigo-50 pb-4">
                <div>
                  <h3 className="font-sans text-xl font-black text-indigo-950 uppercase tracking-tight">TRACK & FUEL LTD</h3>
                  <p className="text-[10px] text-indigo-400 font-bold">148 Athletic Row, Silicon Valley, CA</p>
                </div>
                <div className="text-right">
                  <span className="block text-xs font-mono font-bold text-indigo-600">INVOICE #{selectedInvoice.id}</span>
                  <span className="block text-[9px] text-indigo-400 font-bold uppercase mt-0.5">Status: {selectedInvoice.status}</span>
                </div>
              </div>

              {/* Bill to */}
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="block text-[9px] text-indigo-400 font-black uppercase tracking-wider">Billed To</span>
                  <span className="block font-black text-indigo-950 mt-1">{currentUser.name}</span>
                  <span className="block text-indigo-500 font-bold mt-0.5">{currentUser.email}</span>
                </div>
                <div className="text-right">
                  <span className="block text-[9px] text-indigo-400 font-black uppercase tracking-wider">Date Dispatched</span>
                  <span className="block font-bold text-indigo-950 mt-1">{selectedInvoice.date}</span>
                </div>
              </div>

              {/* Line item */}
              <div className="border-t border-b border-indigo-50 py-4 text-xs space-y-3">
                <div className="flex justify-between text-[9px] text-indigo-400 font-black uppercase tracking-widest">
                  <span>Description</span>
                  <span>Amount</span>
                </div>
                <div className="flex justify-between font-bold text-indigo-950">
                  <span>{selectedInvoice.plan} (Monthly recurring license)</span>
                  <span className="font-mono">${selectedInvoice.amount}.00</span>
                </div>
              </div>

              {/* Total */}
              <div className="flex justify-between items-center text-indigo-950 font-sans">
                <span className="text-xs font-black uppercase tracking-wider">Total Charge</span>
                <span className="text-2xl font-black font-mono">${selectedInvoice.amount}.00 USD</span>
              </div>

              {/* Trust badges footer */}
              <div className="bg-indigo-50/50 rounded-2xl p-4 text-center border border-indigo-100 flex items-center justify-center gap-2 text-[10px] font-bold text-indigo-600">
                <ShieldCheck className="h-4.5 w-4.5 text-emerald-500" />
                <span>Verified Stripe Recurrence Hash Payload Transmitted Successfully</span>
              </div>

              {/* Controls */}
              <div className="flex gap-3">
                <button
                  onClick={() => window.print()}
                  className="flex-1 rounded-2xl border-2 border-indigo-950 hover:bg-indigo-50 text-indigo-950 font-black text-xs uppercase tracking-wider py-3.5 transition-colors"
                >
                  Print Invoice Receipt
                </button>
                <button
                  onClick={() => setSelectedInvoice(null)}
                  className="flex-1 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase tracking-wider py-3.5 transition-colors"
                >
                  Close Receipt View
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Update Card payment method modal */}
      <AnimatePresence>
        {showCardModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-indigo-950/40 backdrop-blur-sm p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-md rounded-[36px] bg-white border-4 border-indigo-100 p-8 shadow-2xl space-y-6"
            >
              <div className="text-center space-y-1">
                <h3 className="font-sans text-xl font-black text-indigo-950 uppercase tracking-tight flex items-center justify-center gap-1.5">
                  <CreditCard className="h-5 w-5 text-indigo-600" />
                  Update Payment Method
                </h3>
                <p className="text-xs text-indigo-500 font-bold">Securely tokenize new credit card parameters via Stripe</p>
              </div>

              {cardSuccess && (
                <div className="flex items-start gap-2.5 rounded-2xl bg-emerald-50 border-2 border-emerald-100 p-4 text-xs text-emerald-800 font-bold">
                  <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-500 mt-0.5" />
                  <span>{cardSuccess}</span>
                </div>
              )}

              <form onSubmit={handleSaveCard} className="space-y-4 text-xs">
                <div>
                  <label className="block text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-1.5">Cardholder Name</label>
                  <input
                    type="text"
                    required
                    value={cardName}
                    onChange={(e) => setCardName(e.target.value.toUpperCase())}
                    className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3 text-xs font-black text-indigo-950 outline-none focus:border-indigo-400 transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-1.5">Card Number</label>
                  <input
                    type="text"
                    required
                    placeholder="4000 1234 5678 9010"
                    onChange={(e) => setCardNumber(e.target.value)}
                    className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3 text-xs font-bold text-indigo-950 outline-none focus:border-indigo-400 transition-colors font-mono"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-1.5">Expiration Date</label>
                    <input
                      type="text"
                      required
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3 text-xs font-bold text-indigo-950 outline-none focus:border-indigo-400 transition-colors font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-1.5">CVV Code</label>
                    <input
                      type="password"
                      required
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value)}
                      className="w-full rounded-2xl border-4 border-indigo-50 px-4 py-3 text-xs font-bold text-indigo-950 outline-none focus:border-indigo-400 transition-colors font-mono"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSavingCard}
                  className="w-full rounded-2xl bg-indigo-600 text-white font-black text-xs uppercase tracking-widest py-3.5 shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-1.5 transition-all"
                >
                  {isSavingCard ? (
                    <RefreshCw className="h-4.5 w-4.5 animate-spin" />
                  ) : (
                    <>
                      <ShieldCheck className="h-4.5 w-4.5" />
                      SAVE CREDIT CARD
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
