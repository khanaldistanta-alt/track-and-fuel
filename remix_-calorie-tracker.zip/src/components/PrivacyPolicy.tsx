import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { Shield, Lock, Eye, CheckCircle2, Server, Globe, Trash2, X, AlertTriangle } from "lucide-react";

interface PrivacyPolicyProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function PrivacyPolicy({ isOpen, onClose }: PrivacyPolicyProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          {/* Backdrop blur & overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-indigo-950/45 backdrop-blur-md"
          />

          {/* Modal Content */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className="relative w-full max-w-3xl bg-white border-4 border-indigo-150 rounded-[40px] shadow-2xl overflow-hidden flex flex-col max-h-[85vh]"
          >
            {/* Header section */}
            <div className="bg-indigo-950 text-white px-8 py-6 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-600">
                  <Shield className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="font-sans text-xl font-black tracking-tight leading-none">
                    Privacy Policy & App Rules
                  </h3>
                  <p className="text-[10px] font-bold text-indigo-300 uppercase tracking-widest mt-1">
                    Track & Fuel Core Compliance Guidelines
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 bg-indigo-900 hover:bg-indigo-850 rounded-xl transition-colors text-white cursor-pointer"
                title="Close Portal"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Scrolling Body */}
            <div className="overflow-y-auto p-8 space-y-8 text-indigo-950">
              
              {/* Core summary */}
              <div className="rounded-3xl bg-indigo-50/40 border-2 border-indigo-100 p-6 space-y-2">
                <h4 className="text-sm font-black uppercase tracking-widest text-indigo-700 flex items-center gap-2">
                  <Eye className="h-4.5 w-4.5 text-indigo-600" />
                  Your Privacy & Data Rights First
                </h4>
                <p className="text-xs text-indigo-900 leading-relaxed font-semibold">
                  Track & Fuel (Calorie Tracker) is designed with high privacy integrity. No fitness datasets, biological factors, or dietary logs are sold, traded, or distributed to advertising networks. All metabolic parameters exist exclusively to optimize your personal sports nutrition profile.
                </p>
              </div>

              {/* Sections of Rules */}
              <div className="space-y-6">
                
                {/* 1. Account & Subscription Profile */}
                <div className="space-y-2.5">
                  <h5 className="font-sans text-sm font-black uppercase tracking-wider text-indigo-950 flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-indigo-100 text-indigo-700 text-xs font-mono font-black">1</span>
                    User Authentication & Account Management
                  </h5>
                  <div className="text-xs text-indigo-900 leading-relaxed font-semibold space-y-2 pl-8">
                    <p>
                      • <strong className="text-indigo-950">Authentication Parameters:</strong> When registering, your name, active email, and encrypted password metrics are written to our secure mock database registry. This keeps session logins authorized.
                    </p>
                    <p>
                      • <strong className="text-indigo-950">Subscription Status:</strong> User roles ("admin" or "user") and license levels ("free_trial", "basic", "pro", "expert") determine your application permission scope. Trial sandbox accounts expire automatically after 14 days. Connect any active billing plan inside the application to restore expired access.
                    </p>
                  </div>
                </div>

                {/* 2. Calorie & Metabolic Logs Processing */}
                <div className="space-y-2.5">
                  <h5 className="font-sans text-sm font-black uppercase tracking-wider text-indigo-950 flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-indigo-100 text-indigo-700 text-xs font-mono font-black">2</span>
                    Daily Dietary Logs & Biometric Logs
                  </h5>
                  <div className="text-xs text-indigo-900 leading-relaxed font-semibold space-y-2 pl-8">
                    <p>
                      • <strong className="text-indigo-950">Logged Meals:</strong> Track & Fuel parses and aggregates meal properties (Breakfast, Lunch, Dinner, Snacks), calories, and macronutrient components (Protein, Carbohydrates, Fats) logged by users.
                    </p>
                    <p>
                      • <strong className="text-indigo-950">Water & Weight:</strong> Body weight charts and water intake records are calculated dynamically and recorded continuously inside the application state structure.
                    </p>
                    <p>
                      • <strong className="text-indigo-950">Custom Nutrient Variables:</strong> Users may freely custom-declare specific trace nutrients (e.g., Sugar, Iron, Sodium, Vitamin D) and specify their custom daily goal thresholds.
                    </p>
                  </div>
                </div>

                {/* 3. Gemini Sports AI Compliance Rules */}
                <div className="space-y-2.5">
                  <h5 className="font-sans text-sm font-black uppercase tracking-wider text-indigo-950 flex items-center gap-2 text-indigo-600 animate-pulse">
                    <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-indigo-600 text-white text-xs font-mono font-black">3</span>
                    Gemini AI Sports Nutrition Coach (FuelBot)
                  </h5>
                  <div className="text-xs text-indigo-900 leading-relaxed font-semibold space-y-2 pl-8">
                    <p>
                      • <strong className="text-indigo-950">Intelligent Parser & Photo Scanning:</strong> Natural language meal descriptions and nutritional queries entered in the AI Search bar are routed securely through our server-side Express backend proxy to official Google Gemini models.
                    </p>
                    <p>
                      • <strong className="text-indigo-950">Conversational AI Chat (FuelBot):</strong> Chats initiated inside the AI Premium Guide are completely transient. Your message feeds are evaluated in real-time by the Gemini engine to provide tailored scientific suggestions. The original API key is stored safely on the server side to protect secrets.
                    </p>
                    <p>
                      • <strong className="text-indigo-950">Non-Persisted AI Logs:</strong> AI Coach query arrays are kept in transient React states during your session, meaning no permanent model training logs are retained under your personal identity.
                    </p>
                  </div>
                </div>

                {/* 4. Payment & Invoice Sandbox Isolation */}
                <div className="space-y-2.5">
                  <h5 className="font-sans text-sm font-black uppercase tracking-wider text-indigo-950 flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-indigo-100 text-indigo-700 text-xs font-mono font-black">4</span>
                    Transaction Security & Billing Isolation
                  </h5>
                  <div className="text-xs text-indigo-900 leading-relaxed font-semibold space-y-2 pl-8">
                    <p>
                      • <strong className="text-indigo-950">Mock Card Transactions:</strong> While billing and upgrades utilize standard Stripe Checkout mock schemas (checking numbers, card inputs, zip validation, declined states), all payment attempts are simulated inside a local secure environment. No actual money is processed.
                    </p>
                    <p>
                      • <strong className="text-indigo-950">Invoice Generation:</strong> Track & Fuel logs invoices with mock references in your billing portal. You can view or simulate plan cancellations and auto-renewal reactivations safely.
                    </p>
                  </div>
                </div>

                {/* 5. Storage Location & Wiping Capabilities */}
                <div className="space-y-2.5">
                  <h5 className="font-sans text-sm font-black uppercase tracking-wider text-indigo-950 flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-indigo-100 text-indigo-700 text-xs font-mono font-black">5</span>
                    LocalStorage & Deletion Policies
                  </h5>
                  <div className="text-xs text-indigo-900 leading-relaxed font-semibold space-y-2 pl-8">
                    <p>
                      • <strong className="text-indigo-950">Browser LocalStorage:</strong> Personal parameters including profiles (age, height, weight), meal lists, water history, and custom nutrient arrays reside on your local client machine via the web browser’s standard storage system.
                    </p>
                    <p>
                      • <strong className="text-indigo-950">Wipe Data Feature:</strong> You have an absolute "Right to be Forgotten". You can purge your entire personal dataset (logs, weight history, and parameters) instantly by accessing the <strong className="text-indigo-950">"Goals & Profile Settings"</strong> menu and clicking the <strong className="text-indigo-950">"Reset My Personal Workspace"</strong> red button. This operates instantly and is completely irreversible.
                    </p>
                  </div>
                </div>

              </div>

              {/* Alert Footer disclaimer */}
              <div className="rounded-3xl bg-amber-50 border-2 border-amber-100 p-5 flex items-start gap-3.5">
                <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h6 className="text-xs font-black text-amber-950 uppercase tracking-wider leading-none">
                    Mock Compliance Environment Disclaimer
                  </h6>
                  <p className="text-[11px] text-amber-900 font-bold leading-relaxed">
                    This compliance panel outlines rules and data procedures matching the Track & Fuel standard code. All mock email simulation logs have been disabled as per user instruction. All administrative overrides are accessible to Admin accounts for audit purposes.
                  </p>
                </div>
              </div>

            </div>

            {/* Footer with Affirmation Button */}
            <div className="bg-slate-50 border-t border-indigo-50 px-8 py-5 flex justify-end shrink-0">
              <button
                onClick={onClose}
                className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest transition-transform active:scale-95 flex items-center gap-1.5 cursor-pointer"
              >
                <CheckCircle2 className="h-4 w-4" />
                I Understand & Accept
              </button>
            </div>

          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
