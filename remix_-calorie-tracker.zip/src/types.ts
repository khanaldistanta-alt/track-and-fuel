export type MealType = "breakfast" | "lunch" | "dinner" | "snack";

export interface FoodItem {
  id: string;
  name: string;
  calories: number; // kcal
  protein: number;  // g
  carbs: number;    // g
  fat: number;      // g
  servingSize: number;
  servingUnit: string;
  isGeminiVerified?: boolean;
  nutrients?: Record<string, number>; // Maps custom nutrient ID or lowercased name to logged amount
}

export interface CustomNutrient {
  id: string;
  name: string;
  unit: string;
  target: number;
  order: number;
}

export interface LogEntry {
  id: string;
  foodItem: FoodItem;
  quantity: number; // Multiplier (e.g., 1 for 1 serving, 1.5 for 1.5 servings)
  mealType: MealType;
  timestamp: number; // ms since epoch
}

export interface UserProfile {
  age: number;
  gender: "male" | "female" | "other";
  height: number; // cm
  weight: number; // kg
  activityLevel: "sedentary" | "light" | "moderate" | "active" | "very_active";
  calorieGoal: number; // kcal
  proteinGoal: number; // g
  carbsGoal: number;   // g
  fatGoal: number;     // g
  weightGoal: number;  // kg
}

export interface WeightLog {
  date: string; // YYYY-MM-DD
  weight: number; // kg
}

export interface WaterLog {
  date: string; // YYYY-MM-DD
  amount: number; // ml
}

export interface DailySummary {
  consumed: number;
  target: number;
  protein: { consumed: number; target: number };
  carbs: { consumed: number; target: number };
  fat: { consumed: number; target: number };
}

// === NEW SAAS SUBSCRIPTION BILLING TYPES ===

export type SubscriptionTier = "free_trial" | "basic" | "pro" | "expert";
export type SubscriptionStatus = "active" | "trialing" | "expired" | "canceled";

export interface Invoice {
  id: string;
  date: string; // YYYY-MM-DD
  amount: number;
  status: "paid" | "failed" | "refunded";
  plan: string;
  pdfUrl?: string;
}

export interface UserAccount {
  id: string;
  email: string;
  name: string;
  role: "user" | "admin";
  createdAt: string; // YYYY-MM-DD
  isDisabled?: boolean;
  trialStart?: number; // timestamp
  trialEnd?: number; // timestamp
  tier: SubscriptionTier;
  status: SubscriptionStatus;
  isAutoRenew: boolean;
  nextBillingDate: string; // YYYY-MM-DD
  invoices: Invoice[];
}

export interface SimulatedEmail {
  id: string;
  to: string;
  subject: string;
  body: string;
  sentAt: string; // Date string
  type: string;
}
